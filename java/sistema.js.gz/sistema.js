(() => {
  "use strict";
  if(window.__sepriguaBooted)return;window.__sepriguaBooted=true;

  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const content = $("#appContent");
  const nav = $("#systemNav");
  const roleChip = $("#roleChip");
  const title = $("#pageTitle");
  const subtitle = $("#pageSubtitle");
  const eyebrow = $("#pageEyebrow");
  const breadcrumb = $("#pageBreadcrumb");
  const dbBadge = $("#dbBadge");
  const dbBadgeText = $("#dbBadgeText");
  const topDate = $("#topDate");
  const topUser = $("#topUser");
  const topRole = $("#topRole");
  const moduleHeroIcon = $("#moduleHeroIcon");
  const notificationButton = $("#notificationButton");
  const notificationDot = $("#notificationDot");
  const notificationCount = $("#notificationCount");
  const notificationPopover = $("#notificationPopover");
  const notificationPreview = $("#notificationPreview");
  const userMenuButton = $("#userMenuButton");
  const userPopover = $("#userPopover");
  const userPopoverName = $("#userPopoverName");
  const userPopoverEmail = $("#userPopoverEmail");
  const userPopoverRole = $("#userPopoverRole");
  const modalBackdrop = $("#modalBackdrop");
  const modalBody = $("#modalBody");
  const modalTitle = $("#modalTitle");
  const toast = $("#toast");
  const shell = $("#systemShell");
  const sidebar = $("#sidebar");
  const sidebarScrim = $("#sidebarScrim");
  const sidebarCollapseButton = $("#sidebarCollapseButton");
  const menuButton = $("#menuButton");
  const sidebarUserName = $("#sidebarUserName");
  const sidebarUserRole = $("#sidebarUserRole");
  const notificationPopoverHome = notificationPopover?.parentElement || null;
  const userPopoverHome = userPopover?.parentElement || null;

  function syncPopoverPortal() {
    const mobile = window.matchMedia("(max-width: 820px)").matches;
    [[notificationPopover, notificationPopoverHome], [userPopover, userPopoverHome]].forEach(([popover, home]) => {
      if (!popover || !home) return;
      if (mobile) {
        if (popover.parentElement !== document.body) document.body.appendChild(popover);
      } else if (popover.parentElement !== home) {
        home.appendChild(popover);
      }
    });
  }

  const state = { user: null, role: "", roleName: "", allowedModules: new Set(), isMasterCoordinator: false, catalogs: {}, current: "dashboard", openOrderId: null, orderDetail: null, orderStep: "resumen", notifications: [], notificationFilter: "TODAS", unreadNotifications: 0, account: null, masterCatalog: [], catalogFilter: { q: "", categoria: "TODAS" }, equipmentFilter: { q: "", estado: "TODOS", categoria: "TODAS" }, userAdmin: { q: "", rol_id: "", estado: "", fecha_desde: "", fecha_hasta: "", pagina: 1, tamano: 10, orden: "FECHA", direccion: "DESC", total: 0, paginas: 1, catalogos: null }, clientAdmin: { pagina: 1, tamano: 10, total: 0, paginas: 1 }, clientSites: [], warranties: [], warrantyRequests: [], warrantyTimer: null, rolesAccess: { data: null } };
  state.quickReportPeriod = "semana";
  state.documentos = { tab: "laboral", empleadoId: "" };
  state.smartLists = {};
  state.smartListDefaults = {};
  state.listCache = {};
  state.apiCache = new Map();
  state.apiInflight = new Map();
  state.mutationInflight = new Map();
  state.listInflight = new Map();
  state.viewCache = new Map();
  state.dirtyModules = new Set();
  state.prefetchStarted = false;
  // Estado requerido por los renderizadores visuales de Gabi. Se mantiene separado
  // de la lógica funcional original para no alterar los contratos del backend.
  state.peopleCounts = { clientes: null, personal: null, usuarios: null };
  state.peopleCountsLoadedAt = 0;
  state.peopleCountsInflight = null;
  state.orderListDetailCache = new Map();
  state.agenda = { fecha: "", data: null, draft: new Map(), dirty: false, selectedOrderId: null, technicianFilter: "TODOS", onlyEmergencies: false, showAllStaff: false };
  window.addEventListener("beforeunload", event => { if(state.agenda?.dirty){ event.preventDefault(); event.returnValue=""; } });
  let smartSearchTimer = null;
  let filterRevision = 0;

  const rolePaths = { COORDINADOR: "/sistema/coordinador", TECNICO: "/sistema/tecnico", CLIENTE: "/sistema/cliente" };
  const modules = {
    COORDINADOR: [
      ["dashboard", "layout-dashboard", "Panel"], ["solicitudes", "inbox", "Solicitudes"], ["ordenes", "clipboard-list", "Órdenes"], ["agenda", "calendar-range", "Agenda operativa"],
      ["clientes", "building-2", "Clientes"], ["personal", "users", "Personal"], ["usuarios", "users-round-cog", "Usuarios"], ["equipos", "wrench", "Equipo"],
      ["vacaciones","calendar-days","Horarios y vacaciones"],["produccion","chart-column","Producción"],["cancelaciones","circle-x","Cancelaciones"],
      ["mantenimientos", "settings", "Mantenimiento"], ["catalogo", "book-open-check", "Catálogo maestro"], ["cotizaciones", "file-text", "Cotizaciones"], ["documentos", "files", "Documentos"], ["garantia", "shield-check", "Garantías"],
      ["notificaciones", "bell", "Notificaciones"], ["roles", "shield-user", "Roles y accesos"], ["cuenta", "user-cog", "Mi cuenta"], ["auditoria", "shield-check", "Auditoría"]
    ],
    TECNICO: [
      ["dashboard", "layout-dashboard", "Mi panel"], ["ordenes", "clipboard-check", "Mis órdenes"], ["agenda", "route", "Mi agenda"], ["equipos", "wrench", "Equipo"],
      ["mantenimientos", "settings", "Mantenimiento"], ["vacaciones", "calendar-days", "Horarios y vacaciones"], ["documentos", "files", "Mis documentos"], ["notificaciones", "bell", "Notificaciones"], ["cuenta", "user-cog", "Mi cuenta"]
    ],
    CLIENTE: [
      ["dashboard", "layout-dashboard", "Mi panel"], ["solicitudes", "circle-plus", "Solicitudes"], ["sedes", "map-pinned", "Mis sedes"], ["ordenes", "clipboard-list", "Mis servicios"],
      ["cancelaciones","circle-x","Cancelaciones"],
      ["cotizaciones", "file-text", "Cotizaciones"], ["documentos", "files", "Documentos"], ["garantia", "shield-check", "Garantía"],
      ["notificaciones", "bell", "Notificaciones"], ["cuenta", "user-cog", "Mi cuenta"]
    ]
  };

  // Navegación simplificada: los módulos siguen existiendo internamente, pero se
  // agrupan en el sidebar para que la interfaz sea más fácil de entender.
  const moduleGroups = {
    COORDINADOR: {
      personas: {
        icon: "contact-round", label: "Clientes y personal",
        members: [
          ["clientes", "building-2", "Clientes"],
          ["personal", "users", "Empleados"],
          ["usuarios", "key-round", "Usuarios del sistema"],["vacaciones","calendar-days","Horarios y vacaciones"],["produccion","chart-column","Resumen semanal"]
        ]
      },
      equipo_mantenimiento: {
        icon: "wrench", label: "Equipo y mantenimiento",
        members: [
          ["equipos", "package-search", "Equipo"],
          ["mantenimientos", "settings", "Mantenimiento"]
        ]
      },
      cotizaciones_comercial: {
        icon: "file-text", label: "Cotizaciones",
        members: [
          ["cotizaciones", "file-text", "Cotizaciones"],
          ["catalogo", "book-open-check", "Catálogo y precios"]
        ]
      }
    },
    TECNICO: {
      equipo_mantenimiento: {
        icon: "wrench", label: "Equipo y mantenimiento",
        members: [
          ["equipos", "package-search", "Equipo"],
          ["mantenimientos", "settings", "Mantenimiento"]
        ]
      }
    },
    CLIENTE: {}
  };

  const navigationModules = {
    COORDINADOR: [
      ["dashboard", "layout-dashboard", "Panel"],
      ["solicitudes", "inbox", "Solicitudes"],
      ["ordenes", "clipboard-list", "Órdenes"],
      ["agenda", "calendar-range", "Agenda operativa"],
      ["cotizaciones_comercial", "file-text", "Cotizaciones"],
      ["personas", "contact-round", "Clientes y personal"],
      ["equipo_mantenimiento", "wrench", "Equipo y mantenimiento"],
      ["documentos", "files", "Documentos"],
      ["garantia", "shield-check", "Garantías"],
      ["roles", "shield-user", "Roles y accesos"],
      ["cuenta", "user-cog", "Mi cuenta"]
    ],
    TECNICO: [
      ["dashboard", "layout-dashboard", "Mi panel"],
      ["ordenes", "clipboard-check", "Mis órdenes"],
      ["agenda", "route", "Mi agenda"],
      ["equipo_mantenimiento", "wrench", "Equipo y mantenimiento"],
      ["vacaciones", "calendar-days", "Horarios y vacaciones"],
      ["documentos", "files", "Mis documentos"],
      ["cuenta", "user-cog", "Mi cuenta"]
    ],
    CLIENTE: modules.CLIENTE.filter(([key])=>key!=="cancelaciones"&&key!=="notificaciones")
  };

  const modulePermissionParent = {
    clientes:"personas", personal:"personas", usuarios:"personas", produccion:"personas",cancelaciones:"solicitudes",
    equipos:"equipo_mantenimiento", mantenimientos:"equipo_mantenimiento",
    cotizaciones:"cotizaciones_comercial", catalogo:"cotizaciones_comercial"
  };

  function permissionKeyForModule(module){ return modulePermissionParent[module] || module; }
  function moduleAllowed(module){
    if(module==="vacaciones"&&state.role==="COORDINADOR"&&state.allowedModules.has("personas"))return true;
    const key=permissionKeyForModule(module);
    if(key==="roles") return state.isMasterCoordinator;
    if(key==="cuenta") return true;
    if(state.isMasterCoordinator) return true;
    return state.allowedModules.has(key);
  }
  function navigationEntries(){
    return (navigationModules[state.role] || modules[state.role] || []).filter(([key])=>moduleAllowed(key));
  }
  function firstAllowedModule(){
    const first=navigationEntries()[0]?.[0] || "cuenta";
    return resolveGroupedModule(first);
  }

  function groupForModule(module, role = state.role) {
    const groups = moduleGroups[role] || {};
    return Object.entries(groups).find(([, group]) => group.members.some(([key]) => key === module)) || null;
  }

  function groupByKey(key, role = state.role) {
    const group = (moduleGroups[role] || {})[key];
    return group ? [key, group] : null;
  }

  function resolveGroupedModule(module) {
    const found = groupByKey(module);
    if (!found) return module;
    const [groupKey, group] = found;

    // El acceso principal "Cotizaciones" del sidebar siempre abre la bandeja
    // de cotizaciones. El catálogo sigue disponible desde el enlace discreto
    // "Catálogo y precios" dentro de esa misma vista. Esto evita que una
    // selección recordada del catálogo haga parecer que el rediseño no cargó.
    if (state.role === "COORDINADOR" && groupKey === "cotizaciones_comercial") {
      return "cotizaciones";
    }

    const storageKey = `seprigua_grupo_${state.role}_${groupKey}`;
    const remembered = sessionStorage.getItem(storageKey);
    return group.members.some(([key]) => key === remembered) ? remembered : group.members[0][0];
  }

  const contextDescriptions = {
    clientes: "Empresas, sedes y contactos",
    personal: "Empleados y disponibilidad",
    usuarios: "Accesos, estados y permisos",
    equipos: "Inventario y asignación",
    mantenimientos: "Preventivo y correctivo",
    cotizaciones: "Crear y dar seguimiento",
    catalogo: "Servicios, conceptos y precios"
  };

  function renderContextTabs() {
    if (state.role === "COORDINADOR" && (state.current === "cotizaciones" || ["clientes","personal","usuarios"].includes(state.current))) return;
    const found = groupForModule(state.current);
    if (!found) return;
    const [groupKey, group] = found;
    if (groupKey === "equipo_mantenimiento") return;
    const tabs = group.members.map(([key, icon, label]) => `
      <button class="context-tab ${key === state.current ? "active" : ""}" type="button" data-context-module="${esc(key)}" aria-current="${key === state.current ? "page" : "false"}">
        <span class="context-tab-icon"><i data-lucide="${esc(icon)}"></i></span>
        <span class="context-tab-copy"><strong>${esc(label)}</strong><small>${esc(contextDescriptions[key] || "Abrir módulo")}</small></span>
        <span class="context-tab-chevron" aria-hidden="true"><i data-lucide="chevron-right"></i></span>
      </button>`).join("");
    content.insertAdjacentHTML("afterbegin", `
      <section class="module-context-switcher" data-group="${esc(groupKey)}" aria-label="${esc(group.label)}">
        <div class="module-context-copy">
          <span class="module-context-kicker">Acceso rápido</span>
          <strong>${esc(group.label)}</strong>
          <small>Elegí lo que querés administrar.</small>
        </div>
        <div class="module-context-tabs" style="--context-columns:${group.members.length}">${tabs}</div>
      </section>`);
    window.lucide?.createIcons();
  }

  function esc(v) { return String(v ?? "").replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c])); }
  function fmt(v) { if (!v) return "—"; const d = new Date(v); return Number.isNaN(d.getTime()) ? esc(v) : d.toLocaleString("es-GT", { dateStyle: "medium", timeStyle: "short" }); }
  function toLocalInput(v) { if (!v) return ""; const d=new Date(v); if(Number.isNaN(d.getTime())) return ""; const z=n=>String(n).padStart(2,"0"); return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}`; }
  function money(v, cur = "GTQ") { const n = Number(v || 0); return new Intl.NumberFormat("es-GT", { style: "currency", currency: cur || "GTQ" }).format(n); }
  function normalizeNumber(v) { return v === null || v === undefined || Number.isNaN(Number(v)) ? 0 : Number(v); }
  const displayEnumWords = new Set([
      "PENDIENTE", "EN PROCESO", "PROGRAMADA", "FINALIZADA", "APROBADA", "RECHAZADA", "CANCELADA", "COMPLETADA",
      "ACTIVO", "ACTIVA", "INACTIVO", "INACTIVA", "BLOQUEADO", "DISPONIBLE", "ASIGNADO", "RETIRADO", "ARCHIVADO",
      "BORRADOR", "OBSERVADA", "CONFIRMADA", "ENVIADA", "ACEPTADA", "ANULADA", "POR CONFIRMAR", "EN REVISIÓN",
      "REGISTRADA", "SOLICITUD REGISTRADA", "OT CREADA", "SIN ESTADO", "SIN PRIORIDAD", "SIN CLASE", "FUERA DE USO",
      "CRITICA", "CRÍTICA", "ALTA", "MEDIA", "BAJA", "EMERGENCIA", "PROGRAMADO", "FINALIZADO", "CANCELADO",
      "OPERARIO", "SUPERVISOR", "COORDINADOR", "ENCARGADO", "TECNICO", "TECNICO RESPONSABLE", "CLIENTE", "DURANTE", "DESPUES",
      "ANTES", "LLAMADA", "MENSAJE", "CORREO", "OTRO", "OTRA", "ACCESO", "RETRASO", "SEGURIDAD", "EQUIPO",
      "PERSONAL", "SERVICIO", "DOCUMENTO", "AUTORIZADO", "RECHAZADO", "ALTERNATIVA", "EN VERIFICACION",
      "PENDIENTE AUTORIZACION", "CORRECCION", "DIAGNOSTICO", "REPORTADA", "CORREGIDA", "FUNCIONA",
      "CON OBSERVACIONES", "FALLA CONTINUA", "POR REVISAR", "EN MANTENIMIENTO", "SOLICITUD PENDIENTE", "GARANTIA APROBADA"
  ]);
  const displayEnumAccents = {
    CRITICA: "Crítica", TECNICO: "Técnico", DESPUES: "Después", DIAGNOSTICO: "Diagnóstico",
    CORRECCION: "Corrección", "EN VERIFICACION": "En verificación", "PENDIENTE AUTORIZACION": "Pendiente de autorización",
    "GARANTIA APROBADA": "Garantía aprobada"
  };
  function displayEnumText(value) {
    const source = String(value ?? "").trim();
    const raw = source.replaceAll("_", " ");
    if (!raw || !/^[A-ZÁÉÍÓÚÜÑ0-9 /.-]+$/.test(raw)) return raw;
    if (/^(SEPRIGUA|OT|OC|PDF|NIT|IVA|IP|GTQ|DPI)$/.test(raw) || /\b[A-Z]{2,}-\d/.test(raw)) return raw;
    if (!displayEnumWords.has(raw) && !source.includes("_")) return raw;
    if (displayEnumAccents[raw]) return displayEnumAccents[raw];
    return raw.toLocaleLowerCase("es-GT").replace(/^\p{L}/u, initial => initial.toLocaleUpperCase("es-GT"))
      .replace(/\b(ot|oc|pdf|nit|iva|ip|gtq|dpi)\b/gi, acronym => acronym.toLocaleUpperCase("es-GT"));
  }
  function displayDetailValue(value) {
    return String(value ?? "—").trim().replaceAll("_", " ").toLocaleLowerCase("es-GT")
      .replace(/^\p{L}/u, initial => initial.toLocaleUpperCase("es-GT"))
      .replace(/\b(ot|oc|pdf|nit|iva|ip|gtq|dpi)\b/gi, acronym => acronym.toLocaleUpperCase("es-GT"));
  }
  function badge(v) {
    const x = String(v ?? "—").toUpperCase();
    const cls = /COMPLET|FINAL|ACEPT|DISPONIBLE|CONFORME|ACTIVO|LEID/.test(x) ? "green" : /CANCEL|RECHAZ|FALLA|NO_CONFORME|CRITICA/.test(x) ? "red" : /PEND|PROCESO|MANTEN|ALTA|EMERGEN/.test(x) ? "orange" : "";
    const label = x === "COMPLETADA" ? "Finalizada" : (x === "POR_CONFIRMAR" ? "Lista para finalizar" : displayEnumText(v ?? "—"));
    return `<span class="badge ${cls}">${esc(label)}</span>`;
  }
  function managementBadge(value) {
    const code=String(value||"").toUpperCase();
    const tone=/VENCID|RECHAZ|FUERA_DE_USO|ANULAD|ELIMINAD/.test(code)?"red":/PEND|MANTEN|PROCESO|CONFIGUR|REVISION|AUTORIZACION|ASIGNAD/.test(code)?"orange":/^(ACTIVO|ACTIVA|DISPONIBLE|GARANTIA_APROBADA|APROBADA|FINALIZADA|COMPLETADA|VERIFICADO)$/.test(code)?"green":"muted";
    const label=({PENDIENTE_CONFIGURACION:"Por configurar",GARANTIA_APROBADA:"Garantía aprobada",EN_REVISION:"En revisión",PENDIENTE_AUTORIZACION:"Pendiente de autorización"})[code]||displayEnumText(value||"—");
    return `<span class="badge management-status ${tone}">${esc(label)}</span>`;
  }
  function button(label, action, id = "", cls = "") { return `<button class="btn small ${cls}" type="button" data-action="${esc(action)}" ${id ? `data-id="${esc(id)}"` : ""}>${esc(label)}</button>`; }
  function iconButton(icon, action, id = "", label = "", cls = "") { return `<button class="${cls}" type="button" data-action="${esc(action)}" ${id ? `data-id="${esc(id)}"` : ""} ${label ? `aria-label="${esc(label)}" title="${esc(label)}"` : ""}><i data-lucide="${esc(icon)}"></i><span class="sr-only">${esc(label || action)}</span></button>`; }
  function table(headers, rows, empty = "No hay registros.") {
    if (!rows.length) return `<div class="empty-state">${esc(empty)}</div>`;
    const labelled = rows.map(row => {
      let index = 0;
      return String(row).replace(/<td([^>]*)>/g, (match, attrs) => {
        const label = headers[index++] || "";
        return `<td${attrs} data-label="${esc(label)}">`;
      });
    });
    const wideActions = !window.matchMedia("(max-width: 600px)").matches;
    const compactActions = labelled.map(row => row.replace(
      /(<td[^>]*data-label="Acci(?:ón|ones)"[^>]*>)([\s\S]*?)(<\/td>)/g,
      (_match, open, body, close) => `${open}<details class="mobile-row-actions" ${wideActions ? "open" : ""}><summary>Acciones</summary><div class="mobile-row-actions-body">${body}</div></details>${close}`
    ));
    return `<div class="table-wrap se-table-responsive-scope"><table class="data-table ${headers.length > 5 ? "se-wide-table" : ""}"><thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${compactActions.join("")}</tbody></table></div>`;
  }
  const mobileActionQuery = window.matchMedia("(max-width: 600px)");
  const syncRowActionDisclosure = () => {
    document.querySelectorAll(".mobile-row-actions").forEach(details => {
      details.open = !mobileActionQuery.matches;
    });
  };
  if (mobileActionQuery.addEventListener) mobileActionQuery.addEventListener("change", syncRowActionDisclosure);
  else mobileActionQuery.addListener(syncRowActionDisclosure);

  function optionList(items, valueKey = "id", text = x => x.nombre || x.name || x.codigo || x.id, selected = "") {
    return items.map(x => `<option value="${esc(x[valueKey])}" ${String(x[valueKey]) === String(selected) ? "selected" : ""}>${esc(text(x))}</option>`).join("");
  }
  function showToast(message, type = "success") {
    toast.textContent = message; toast.className = `toast ${type}`; toast.hidden = false;
    clearTimeout(showToast.t); showToast.t = setTimeout(() => { toast.hidden = true; }, 3500);
  }
  let modalProtection = { locked: false, reason: "" };
  let modalReturnFocus = null;

  function modalVisualIcon(name) {
    const title = String(name || "").toLowerCase();
    if (title === "nueva solicitud") return "file-plus-2";
    if (/solicitud|cancelaci[oó]n/.test(title)) return "inbox";
    if (/orden|\bot\b|trabajo/.test(title)) return "clipboard-list";
    if (/cotizaci[oó]n|precio/.test(title)) return "file-text";
    if (/cliente|sede|empresa/.test(title)) return "building-2";
    if (/personal|t[eé]cnico|usuario|perfil|contrase[nñ]a|correo/.test(title)) return "user-round";
    if (/equipo|mantenimiento|falla|inspecci[oó]n|repuesto/.test(title)) return "wrench";
    if (/garant[ií]a/.test(title)) return "shield-check";
    if (/documento|archivo|evidencia/.test(title)) return "file-check-2";
    if (/rol|acceso|permiso/.test(title)) return "shield-user";
    if (/auditor[ií]a/.test(title)) return "scan-search";
    return currentModuleIcon();
  }

  function modalFieldIcon(label, control) {
    const text = String(label || "").toLowerCase();
    if (/urgencia|emergencia|critic/.test(text)) return "triangle-alert";
    if (/cliente|persona|colaborador|empleado/.test(text)) return "users-round";
    if (/sede|ubicaci[oó]n|direcci[oó]n|municipio|departamento/.test(text)) return "map-pin";
    if (/servicio|mantenimiento|equipo|trabajo|repuesto/.test(text)) return "wrench";
    if (/clasificaci[oó]n|categor[ií]a|tipo|estado|prioridad/.test(text)) return "tag";
    if (/canal|contacto|tel[eé]fono|correo/.test(text)) return "headset";
    if (/fecha|hora|programaci[oó]n|vigencia/.test(text)) return "calendar-days";
    if (/descripci[oó]n|observaci[oó]n|detalle|motivo|nota/.test(text)) return "file-text";
    if (/archivo|imagen|foto|evidencia|documento|pdf/.test(text)) return "paperclip";
    if (/precio|costo|monto|total|pago/.test(text)) return "badge-dollar-sign";
    if (/nombre|usuario/.test(text)) return "user-round";
    if (control?.type === "date" || control?.type === "datetime-local") return "calendar-days";
    if (control?.tagName === "TEXTAREA") return "file-text";
    if (control?.tagName === "SELECT") return "list-filter";
    return "text-cursor-input";
  }

  function decorateModalVisuals(name) {
    const shell = modalBackdrop.querySelector(".modal-seprigua");
    if (!shell) return;
    const icon = $("#modalIcon");
    icon.innerHTML = `<i data-lucide="${modalVisualIcon(name)}"></i>`;
    const subtitle = $("#modalSubtitle");
    subtitle.textContent = name === "Nueva solicitud" ? "Registra una nueva solicitud de servicio, mantenimiento o soporte." : "";
    subtitle.hidden = !subtitle.textContent;
    const form = modalBody.querySelector("form");
    const hasTables = !!modalBody.querySelector("table, .table-wrap, .modal-list-shell");
    const controls = modalBody.querySelectorAll("input:not([type=hidden]), select, textarea").length;
    const isConfirm = !!modalBody.querySelector(".confirm-state-card") ||
      (!form && !hasTables && /^(eliminar|desactivar|activar|cerrar sesi[oó]n|confirmar|retirar|archivar)/i.test(name));
    const size = isConfirm ? "sm" : hasTables ? "xl" : form && controls >= 5 ? "lg" : "md";
    shell.dataset.modalSize = size;
    shell.dataset.modalKind = isConfirm ? "confirm" : form ? "form" : "detail";
    modalBody.querySelectorAll(".field").forEach(field => {
      const label = field.querySelector(":scope > label");
      const control = field.querySelector(":scope > input, :scope > select, :scope > textarea");
      if (!label || !control || control.type === "checkbox" || control.type === "radio") return;
      field.classList.add("modal-seprigua__field");
      if (/urgencia|emergencia|critic/i.test(label.textContent)) field.classList.add("modal-seprigua__field--urgent");
      field.insertAdjacentHTML("afterbegin", `<span class="modal-seprigua__field-icon" aria-hidden="true"><i data-lucide="${modalFieldIcon(label.textContent, control)}"></i></span>`);
    });
    modalBody.querySelectorAll("form").forEach(item => {
      const actionItems = [...item.querySelectorAll(".form-actions")];
      const actions = actionItems[actionItems.length - 1];
      if (!actions) return;
      let footer = actions;
      while (footer.parentElement && footer.parentElement !== item) footer = footer.parentElement;
      if (footer.parentElement === item && footer === item.lastElementChild) {
        footer.classList.add("modal-seprigua__footer");
      }
    });
  }

  function openModal(name, html, options = {}) {
    if (modalBackdrop.hidden) modalReturnFocus = document.activeElement;
    modalTitle.textContent = name;
    modalBody.innerHTML = html;
    modalBackdrop.classList.toggle("user-editor-open", !!modalBody.querySelector("#userAdminForm"));
    modalBackdrop.classList.toggle("document-share-open", !!modalBody.querySelector("#documentShareForm"));
    modalBody.scrollTop = 0;
    decorateModalVisuals(name);
    const detailHeader = options.detailHeader;
    const shell = modalBackdrop.querySelector('.modal-seprigua');
    shell.classList.toggle('se-detail-modal', !!detailHeader);
    const oldKicker = shell.querySelector('.se-detail-modal-kicker');
    const oldStatus = shell.querySelector('.se-detail-modal-status');
    oldKicker?.remove(); oldStatus?.remove();
    if (detailHeader) {
      modalTitle.textContent = detailHeader.title || name;
      const kicker = document.createElement('span');
      kicker.className = 'se-detail-modal-kicker';
      kicker.textContent = detailHeader.kicker || name;
      modalTitle.before(kicker);
      const subtitle = $('#modalSubtitle');
      subtitle.textContent = detailHeader.meta || '';
      subtitle.hidden = !subtitle.textContent;
      if (detailHeader.status) {
        const status = document.createElement('span');
        status.className = 'se-detail-modal-status';
        status.textContent = String(detailHeader.status).replaceAll('_', ' ').toLocaleLowerCase('es').replace(/^./, letter => letter.toLocaleUpperCase('es'));
        if (/cancel|rechaz|vencid|inactiv|falla/i.test(status.textContent)) status.classList.add('is-danger');
        else if (/pend|proceso|media|alta|emergen/i.test(status.textContent)) status.classList.add('is-warning');
        const statusIcon = document.createElement('i');
        statusIcon.dataset.lucide = status.classList.contains('is-danger') ? 'circle-x' : status.classList.contains('is-warning') ? 'circle-alert' : 'circle-check';
        status.prepend(statusIcon);
        $('#modalClose').before(status);
      }
      if (detailHeader.icon) $('#modalIcon').innerHTML = `<i data-lucide="${esc(detailHeader.icon)}"></i>`;
      const hasLongContent = modalBody.querySelectorAll('.se-detail-row').length > 6 || !!modalBody.querySelector('table, form, .se-detail-timeline');
      shell.dataset.modalSize = detailHeader.size || (hasLongContent ? 'lg' : 'md');
    }

    // Los modales con formularios se consideran principales por defecto.
    // No se cierran por clic accidental fuera ni con Escape.
    const containsForm = /<form\b/i.test(String(html || ""));
    modalProtection.locked = options.lockBackdrop ?? containsForm;
    modalProtection.reason = options.reason || (modalProtection.locked ? "formulario" : "");
    modalBackdrop.dataset.protected = modalProtection.locked ? "true" : "false";

    modalBackdrop.hidden = false;
    window.lucide?.createIcons();
    requestAnimationFrame(() => {
      if (modalBackdrop.hidden) return;
      const firstField = modalBody.querySelector('input:not([type="hidden"]):not(:disabled), select:not(:disabled), textarea:not(:disabled)');
      (firstField && firstField.getClientRects().length ? firstField : $("#modalClose")).focus({preventScroll:true});
    });
  }

  function closeModal() {
    modalBackdrop.hidden = true;
    modalBody.innerHTML = "";
    modalBackdrop.classList.remove("user-editor-open");
    modalBackdrop.classList.remove("document-share-open");
    modalProtection = { locked: false, reason: "" };
    delete modalBackdrop.dataset.protected;
    if (modalReturnFocus?.isConnected) modalReturnFocus.focus({preventScroll:true});
    modalReturnFocus = null;
  }

  function warnProtectedModal() {
    const modal = modalBackdrop.querySelector(".modal");
    modal?.classList.remove("modal-attention");
    // Reinicia la animación si el usuario vuelve a tocar el fondo.
    void modal?.offsetWidth;
    modal?.classList.add("modal-attention");
    setTimeout(() => modal?.classList.remove("modal-attention"), 420);
    showToast("Este formulario sigue abierto. Usa Cancelar o × para cerrarlo.", "info");
  }
  function currentModuleIcon(module = state.current) {
    const grouped = groupForModule(module);
    if (grouped) return grouped[1].icon || "layout-dashboard";
    const item = navigationEntries().find(([key]) => key === module);
    return item?.[1] || "layout-dashboard";
  }
  function syncPrototypeChrome() {
    if (topDate || document.getElementById("topDayName")) {
      const now = new Date();
      const dateFormatter = new Intl.DateTimeFormat("es-GT", {
        timeZone: "America/Guatemala",
        day: "numeric",
        month: "long",
        year: "numeric"
      });
      const weekdayFormatter = new Intl.DateTimeFormat("es-GT", {
        timeZone: "America/Guatemala",
        weekday: "long"
      });
      const dayName = document.getElementById("topDayName");
      const weekday = weekdayFormatter.format(now);
      if (topDate) topDate.textContent = dateFormatter.format(now);
      if (dayName) dayName.textContent = weekday.charAt(0).toUpperCase() + weekday.slice(1);
    }
    if (topUser) topUser.textContent = state.user?.nombre || state.user?.usuario || "Usuario SEPRIGUA";
    if (topRole) topRole.textContent = displayEnumText(state.roleName || state.role || "Portal operativo");
    if (userPopoverName) userPopoverName.textContent = state.user?.nombre || state.user?.usuario || "Usuario SEPRIGUA";
    if (userPopoverEmail) userPopoverEmail.textContent = state.user?.correo || "Cuenta del sistema";
    if (userPopoverRole) userPopoverRole.textContent = displayEnumText(state.roleName || state.role || "Portal operativo");
    if (sidebarUserName) sidebarUserName.textContent = state.user?.nombre || state.user?.usuario || "Usuario SEPRIGUA";
    if (sidebarUserRole) sidebarUserRole.textContent = displayEnumText(state.roleName || state.role || "Portal operativo");
    const photoUrl = state.user?.foto_url || "";
    [document.querySelector(".sidebar-user-avatar"), ...document.querySelectorAll(".prototype-avatar")].filter(Boolean).forEach(node => {
      let image = node.querySelector("img.profile-avatar-photo");
      if (!photoUrl) { image?.remove(); node.classList.remove("has-profile-photo"); return; }
      if (!image) { image = document.createElement("img"); image.className = "profile-avatar-photo"; image.alt = ""; image.onerror = () => { image.remove(); node.classList.remove("has-profile-photo"); }; node.append(image); }
      image.src = photoUrl;
      node.classList.add("has-profile-photo");
    });
    if (moduleHeroIcon) moduleHeroIcon.innerHTML = `<i data-lucide="${esc(currentModuleIcon())}"></i>`;
    window.lucide?.createIcons();
  }
  const moduleRootHeadings = new Map();
  let captureModuleRoot = false;
  let breadcrumbParent = null;
  let contentNavigationSource = null;
  function updateBreadcrumb(name = title?.textContent || "") {
    if (!breadcrumb || !state.role) return;
    const module = state.current;
    const rootName = moduleRootHeadings.get(module) || (modules[state.role] || []).find(([key]) => key === module)?.[2] || name;
    const parts = [];
    const orderSteps = { documento:"Ticket y respaldo", evidencia:"Evidencias", descripcion:"Descripción", finalizar:"Finalización" };
    const orderStep = /^Orden\s/i.test(name) && state.openOrderId ? orderSteps[state.orderStep] : null;
    const isDetail = name !== rootName || Boolean(orderStep);
    if (!isDetail && !breadcrumbParent) {
      breadcrumb.replaceChildren();
      breadcrumb.hidden = true;
      return;
    }
    if (breadcrumbParent && breadcrumbParent.module !== module) parts.push(`<button type="button" data-breadcrumb-module="${esc(breadcrumbParent.module)}">${esc(breadcrumbParent.label)}</button>`);
    if (isDetail) parts.push(`<button type="button" data-breadcrumb-module="${esc(module)}">${esc(rootName)}</button>`);
    else parts.push(`<span aria-current="page">${esc(rootName)}</span>`);
    if (name !== rootName) parts.push(orderStep ? `<button type="button" data-breadcrumb-order-id="${esc(state.openOrderId)}">${esc(name)}</button>` : `<span aria-current="page">${esc(name)}</span>`);
    if (orderStep) parts.push(`<span aria-current="page">${esc(orderStep)}</span>`);
    breadcrumb.innerHTML = parts.join('<span class="breadcrumb-separator" aria-hidden="true">/</span>');
    breadcrumb.hidden = false;
  }
  function setHeading(name, description) {
    if (captureModuleRoot) { moduleRootHeadings.set(state.current, name); captureModuleRoot = false; }
    eyebrow.textContent = `SEPRIGUA · ${state.role}`;
    title.textContent = name;
    subtitle.textContent = description;
    updateBreadcrumb(name);
    syncPrototypeChrome();
  }

  function portalDaypart(date = new Date()) {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/Guatemala",
      hour: "2-digit",
      hourCycle: "h23"
    }).formatToParts(date);
    const hour = Number(parts.find(part => part.type === "hour")?.value || 0);

    if (hour >= 6 && hour < 14) {
      return {
        key: "dia",
        greeting: "Buenos días",
        label: "JORNADA DE DÍA",
        detail: "Operación en marcha",
        icon: "sun-medium",
        image: "/assets/img/tuky-dia.webp?v=2"
      };
    }
    if (hour >= 14 && hour < 18) {
      return {
        key: "tarde",
        greeting: "Buenas tardes",
        label: "JORNADA DE TARDE",
        detail: "Seguimiento operativo",
        icon: "sunset",
        image: "/assets/img/tuky-tarde.webp?v=2"
      };
    }
    return {
      key: "noche",
      greeting: "Buenas noches",
      label: "JORNADA NOCTURNA",
      detail: "Cierre y continuidad",
      icon: "moon-star",
      image: "/assets/img/tuky-noche.webp?v=2"
    };
  }

  window.SEPRIGUADaypart = { get: portalDaypart };

  function portalGreeting() {
    return portalDaypart().greeting;
  }

  function portalRoleIcon() {
    return state.role === "CLIENTE" ? "building-2" : state.role === "TECNICO" ? "hard-hat" : currentModuleIcon();
  }

  function renderRoleModuleHero() {
    if (state.role === "COORDINADOR" || state.current === "dashboard") return;
    if (!["solicitudes","ordenes","sedes","equipos","mantenimientos","vacaciones","cotizaciones","garantia"].includes(state.current)) return;
    if (content.querySelector(":scope > .role-module-hero")) return;
    const roleName = state.role === "CLIENTE" ? (state.user?.cliente || state.user?.nombre || "Cliente SEPRIGUA") : (state.user?.nombre || "Técnico SEPRIGUA");
    content.insertAdjacentHTML("afterbegin", `<header class="role-module-hero role-module-hero-${state.role.toLowerCase()}">
      <div class="role-module-hero-icon"><i data-lucide="${esc(currentModuleIcon())}"></i></div>
      <div class="role-module-hero-copy"><h2>${esc(title?.textContent || "SEPRIGUA")}</h2><p>${esc(subtitle?.textContent || "Información actualizada del portal.")}</p></div>
      <div class="role-module-hero-status"><i data-lucide="circle-check-big"></i><span>${esc(roleName)}</span></div>
    </header>`);
    window.lucide?.createIcons();
  }
  function moduleHeaderTarget(module = state.current) {
    if (module === "dashboard") {
      return state.role === "COORDINADOR" ? null : content.querySelector(".role-dashboard-hero");
    }
    if (state.role !== "COORDINADOR") {
      const roleHero = content.querySelector(":scope > .role-module-hero");
      if (roleHero) return roleHero;
    }
    const selectors = {
      solicitudes: ".solicitudes-hero",
      ordenes: ".orders-page-header",
      agenda: ".agenda-command",
      cotizaciones: ".quotes-page-header",
      clientes: ".people-page-title-row",
      personal: ".people-page-title-row",
      usuarios: ".people-page-title-row",
      documentos: ".document-hub",
      roles: ".roles-access-hero",
      cuenta: ".account-hero-card"
    };
    const selector = selectors[module];
    return selector ? content.querySelector(selector) : null;
  }

  function moduleHeaderCopyTarget(host) {
    if (!host) return null;
    return host.querySelector([
      ".solicitudes-hero-copy",
      ".orders-page-copy",
      ".quotes-page-copy",
      ".people-page-copy",
      ".agenda-command-copy > div",
      ".document-hub-copy > div",
      ".roles-access-hero-main > div",
      ".role-module-hero-copy",
      ".role-dashboard-hero-copy",
      ".account-hero-copy"
    ].join(",")) || host;
  }

  function moduleTimeHeroArt(meta) {
    return `<span class="se-module-time-overlay" aria-hidden="true"></span><img class="se-module-time-art" src="${esc(meta.image)}" alt="" aria-hidden="true" loading="eager" decoding="async">`;
  }

  function updateModuleTimeHero(host, meta) {
    if (!host) return;
    host.classList.add("se-module-time-hero");
    host.dataset.daypart = meta.key;
    host.dataset.module = state.current;
    host.dataset.role = String(state.role || "").toLowerCase();

    let art = host.querySelector(":scope > .se-module-time-art");
    if (!art) {
      host.insertAdjacentHTML("afterbegin", moduleTimeHeroArt(meta));
      art = host.querySelector(":scope > .se-module-time-art");
    } else if (art.getAttribute("src") !== meta.image) {
      art.setAttribute("src", meta.image);
    }

    let overlay = host.querySelector(":scope > .se-module-time-overlay");
    if (!overlay) host.insertAdjacentHTML("afterbegin", `<span class="se-module-time-overlay" aria-hidden="true"></span>`);

    const copy = moduleHeaderCopyTarget(host);
    if (copy && !copy.querySelector(":scope > .se-module-time-shift")) {
      copy.insertAdjacentHTML("afterbegin", `<span class="se-module-time-shift"><i data-lucide="${esc(meta.icon)}"></i>${esc(meta.label)}</span>`);
    } else if (copy) {
      const shift = copy.querySelector(":scope > .se-module-time-shift");
      if (shift) shift.innerHTML = `<i data-lucide="${esc(meta.icon)}"></i>${esc(meta.label)}`;
    }
  }

  function clearModuleTimeDecoration(host) {
    if (!host) return;
    host.classList.remove("se-module-time-hero");
    host.removeAttribute("data-daypart");
    host.querySelectorAll(":scope > .se-module-time-art, :scope > .se-module-time-overlay").forEach(el => el.remove());
    host.querySelectorAll(".se-module-time-shift").forEach(el => el.remove());
  }

  function decorateStaticModuleHeader(host) {
    if (!host) return;
    clearModuleTimeDecoration(host);
    host.classList.add("se-module-static-hero");
    host.dataset.module = state.current;
    host.dataset.role = String(state.role || "").toLowerCase();
    const bannerIcons = {agenda:"calendar-range",equipos:"wrench",mantenimientos:"settings-2",documentos:"folders",garantia:"shield-check",notificaciones:"bell-ring",roles:"shield-user"};
    const bannerIcon = bannerIcons[state.current];
    if (bannerIcon && !host.querySelector(":scope > .se-banner-art")) {
      host.insertAdjacentHTML("beforeend", `<span class="se-banner-art" aria-hidden="true"><i data-lucide="${bannerIcon}"></i></span>`);
    }
  }

  function decorateModuleHeader() {
    // Tuky y el cambio por horario viven EXCLUSIVAMENTE en los tres Centros de control.
    if (state.current === "dashboard") {
      if (state.role === "COORDINADOR") return; // El Coordinador ya renderiza su banner horario propio.
      const dashboardHero = moduleHeaderTarget("dashboard");
      if (dashboardHero) {
        dashboardHero.classList.remove("se-module-static-hero");
        updateModuleTimeHero(dashboardHero, portalDaypart());
        window.lucide?.createIcons();
      }
      return;
    }

    // Cualquier encabezado horario genérico de una versión anterior se elimina al renderizar.
    content.querySelectorAll(":scope > .se-module-time-generic").forEach(el => el.remove());

    if (state.current === "cuenta") return;

    const host = moduleHeaderTarget(state.current);
    if (host) {
      decorateStaticModuleHeader(host);
      window.lucide?.createIcons();
      return;
    }

    // Los módulos sin encabezado propio reciben una cabecera SEPRIGUA estática, sin horario ni Tuky.
    let generic = content.querySelector(":scope > .se-module-static-generic");
    if (!generic) {
      const moduleName = String(title?.textContent || "SEPRIGUA");
      const description = String(subtitle?.textContent || "Información actualizada del portal.");
      const moduleActions = state.current === "cancelaciones" ? `<div class="se-module-static-actions"><button class="btn" type="button" data-context-module="ordenes"><i data-lucide="arrow-left"></i><span>${state.role === "CLIENTE" ? "Regresar a mis servicios" : "Regresar a órdenes"}</span></button></div>` : "";
      content.insertAdjacentHTML("afterbegin", `<header class="se-module-static-hero se-module-static-generic" data-module="${esc(state.current)}" data-role="${esc(String(state.role || "").toLowerCase())}">
        <div class="se-module-static-icon"><i data-lucide="${esc(currentModuleIcon())}"></i></div>
        <div class="se-module-static-copy">
          <h2>${esc(moduleName)}</h2>
          <p>${esc(description)}</p>
        </div>
        ${moduleActions}
      </header>`);
      generic = content.querySelector(":scope > .se-module-static-generic");
    }
    decorateStaticModuleHeader(generic);
    window.lucide?.createIcons();
  }

  function loading(module = state.current) {
    if (window.SEPRIGUALoader?.start) {
      return window.SEPRIGUALoader.start({
        container: content,
        module,
        user: state.user,
        role: state.role,
        retry: () => navigate(module)
      });
    }
    content.innerHTML = `<div class="loading-card">Cargando ${esc(module || "módulo")}...</div>`;
    return null;
  }
  function renderAvatarIdentity(name, options = {}) {
    if (window.SEPRIGUAAvatar?.render) return window.SEPRIGUAAvatar.render(name, options);
    return `<strong>${esc(name || options.fallbackName || "Sin nombre")}</strong>`;
  }

  function entityDetailButton(label, action, id, className = "") {
    if (id === null || id === undefined || String(id) === "") return `<strong>${esc(label || "Sin nombre")}</strong>`;
    return `<button class="se-entity-link ${className}" type="button" data-action="${esc(action)}" data-id="${esc(id)}" aria-label="Ver información de ${esc(label || "registro")}">${esc(label || "Sin nombre")}</button>`;
  }

  function entityAvatarLink(name, options, action, id) {
    const identity = renderAvatarIdentity(name, options);
    if (id === null || id === undefined || String(id) === "") return identity;
    return `<button class="se-entity-avatar-link" type="button" data-action="${esc(action)}" data-id="${esc(id)}" aria-label="Ver información de ${esc(name)}">${identity}</button>`;
  }

  function vacationPeriod(value, end, days) {
    const shortDate = date => {
      if (!date) return "—";
      const parsed = new Date(date);
      return Number.isNaN(parsed.getTime()) ? String(date) : parsed.toLocaleDateString("es-GT", {day:"2-digit", month:"2-digit", year:"numeric"});
    };
    return `<div class="vacation-period" title="${esc(`${fmt(value)} – ${fmt(end)}`)}"><span><small>Desde</small><strong>${esc(shortDate(value))}</strong></span><i data-lucide="arrow-right" aria-hidden="true"></i><span><small>Hasta</small><strong>${esc(shortDate(end))}</strong></span><em>${esc(days)} ${Number(days) === 1 ? "día" : "días"}</em></div>`;
  }

  function formatDisplayLabel(value) {
    const normalized = displayEnumText(value);
    if (/^[A-ZÁÉÍÓÚÜÑ][A-ZÁÉÍÓÚÜÑ ]+$/.test(normalized)) {
      return normalized.toLocaleLowerCase("es-GT").replace(/^\p{L}/u, letter => letter.toLocaleUpperCase("es-GT"));
    }
    return normalized;
  }
  function formatGTTime(value = new Date()) {
    const d = value instanceof Date ? value : new Date(value);
    return new Intl.DateTimeFormat("es-GT", { timeZone: "America/Guatemala", hour: "numeric", minute: "2-digit" }).format(d);
  }


  function gtDateKey(value) {
    if (!value) return "";
    const d = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(d.getTime())) return "";
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone:"America/Guatemala", year:"numeric", month:"2-digit", day:"2-digit" }).formatToParts(d);
    const map = Object.fromEntries(parts.map(part => [part.type, part.value]));
    return `${map.year}-${map.month}-${map.day}`;
  }


  // Consulta por fecha: se filtran registros con fecha disponible. Los KPI de
  // capacidad/estado actual no se reinterpretan como instantáneas históricas.
  function historicalDate() { return window.SEPRIGUASelectedDate || ""; }
  function recordDateKey(value) {
    if (!value) return "";
    const raw = String(value);
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
    return gtDateKey(value);
  }
  function filterSelectedDate(module, source) {
    const selected = historicalDate();
    if (!selected || !Array.isArray(source)) return source;
    const resolvers = {
      solicitudes: x => x.creada || x.fecha || x.fecha_registro,
      ordenes: x => orderDateForList(x) || x.programada || x.creada || x.fecha,
      cotizaciones: x => x.emision || x.creada || x.fecha,
      documentos: x => x.generado || x.entregado || x.creada || x.fecha || x.fecha_documento,
      auditoria: x => x.fecha,
      notificaciones: x => x.creada,
      mantenimientos: x => x.programada || x.fecha_programada || x.fecha
    };
    const resolve = resolvers[module];
    return resolve ? source.filter(item => recordDateKey(resolve(item)) === selected) : source;
  }
  function historicalDateNotice() {
    const selected = historicalDate();
    if (!selected) return "";
    const text = new Date(`${selected}T12:00:00Z`).toLocaleDateString("es-GT",{day:"numeric",month:"long",year:"numeric",timeZone:"UTC"});
    return `<div class="se-date-view-note" role="status"><i data-lucide="calendar-check-2"></i><span>Consulta del <strong>${esc(text)}</strong>. Los registros y conteos disponibles corresponden al día seleccionado; disponibilidad y otros indicadores de operación siguen mostrando valores actuales.</span><button type="button" class="se-date-view-clear" data-action="se-clear-date"><i data-lucide="x"></i><span>Ver actualidad</span></button></div>`;
  }

  function dashboardFirstName() {
    const full = String(state.user?.nombre || state.user?.usuario || "Usuario").trim();
    return full.split(/\s+/)[0] || "Usuario";
  }


  function dashboardMonthLabel(value) {
    const raw = String(value ?? "").trim();
    const match = raw.match(/(?:^|[-\/])(\d{1,2})$/);
    const monthIndex = match ? Number(match[1]) - 1 : -1;
    const months = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];
    if (monthIndex >= 0 && monthIndex < 12) return months[monthIndex];
    return raw ? raw.slice(0, 3) : "—";
  }

  function dashboardReadableLabel(value) {
    const raw = String(value ?? "").replaceAll("_", " ").replace(/\s+/g, " ").trim();
    return raw ? raw.toLocaleLowerCase("es").replace(/(^|\s|·)(\p{L})/gu, (_match, prefix, letter) => `${prefix}${letter.toLocaleUpperCase("es")}`) : "";
  }


  function dashboardOptionalNumber(...values) {
    for (const value of values) {
      if (value === null || value === undefined || value === "") continue;
      const numeric = Number(String(value).replace("%", "").trim());
      if (Number.isFinite(numeric)) return numeric;
    }
    return null;
  }


  function dashboardTrendMarkup(value) {
    const numeric = dashboardOptionalNumber(value);
    if (numeric === null) return "";

    const rounded = Math.round(numeric * 10) / 10;
    if (rounded > 0) {
      return `<small class="cc-trend cc-trend-up"><span aria-hidden="true">↑</span> +${esc(rounded)}% vs mes anterior</small>`;
    }
    if (rounded < 0) {
      return `<small class="cc-trend cc-trend-down"><span aria-hidden="true">↓</span> ${esc(rounded)}% vs mes anterior</small>`;
    }
    return `<small class="cc-trend cc-trend-flat"><span aria-hidden="true">→</span> 0% vs mes anterior</small>`;
  }


  function dashboardStaffCapacity() {
    const people = Array.isArray(state.catalogs?.tecnicos) ? state.catalogs.tecnicos : [];
    const normalized = people.map(person => {
      const roleText = [person?.puesto, person?.rol, person?.tipo].filter(Boolean).join(" ").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
      const availability = String(person?.estado_operativo || person?.disponibilidad || "").toUpperCase();
      const status = String(person?.estado || "ACTIVO").toUpperCase();
      const active = !/INACTIVO|BAJA|DESHABILIT/.test(status);
      const available = active && availability === "DISPONIBLE";
      const supervisor = /SUPERVISOR/.test(roleText);
      const operator = !supervisor && /OPERARIO|TECNIC/.test(roleText);
      return { supervisor, operator, available };
    });
    const summarize = predicate => {
      const rows = normalized.filter(predicate);
      return { total: rows.length, available: rows.filter(row => row.available).length };
    };
    return {
      operarios: summarize(row => row.operator),
      supervisores: summarize(row => row.supervisor)
    };
  }


  function dashboardStatusBadge(value) {
    const raw = String(value ?? "—").trim();
    const stateName = raw.toUpperCase().replaceAll("_", " ");
    const normalized = stateName.replace(/\s+/g, " ");

    const config = {
      "PROGRAMADA": ["programada", "●"],
      "FINALIZADA": ["finalizada", "✓"],
      "COMPLETADA": ["finalizada", "✓"],
      "EN PROCESO": ["proceso", "↻"],
      "EN CURSO": ["proceso", "↻"],
      "CANCELADA": ["cancelada", "×"]
    };

    const [tone, icon] = config[normalized] || ["neutral", ""];
    const label = dashboardReadableLabel(normalized === "COMPLETADA" ? "FINALIZADA" : normalized);

    return `<span class="cc-status cc-status-${tone}">${icon ? `<span class="cc-status-symbol" aria-hidden="true">${icon}</span>` : ""}${esc(label)}</span>`;
  }


  function dashboardCapacityProgress(value, total, tone = "blue") {
    const numericValue = Math.max(0, normalizeNumber(value));
    const numericTotal = dashboardOptionalNumber(total);

    if (numericTotal !== null && numericTotal > 0) {
      const percent = Math.max(0, Math.min(100, (numericValue / numericTotal) * 100));
      const percentCss = `${percent.toFixed(4)}%`;

      return `<div class="cc-capacity-progress cc-capacity-progress-${esc(tone)}" aria-label="${numericValue} de ${numericTotal} disponibles">
        <div class="cc-progress-track"
             role="progressbar"
             aria-valuemin="0"
             aria-valuemax="${numericTotal}"
             aria-valuenow="${numericValue}"
             style="--cc-progress-target:${percentCss}">
          <span class="cc-progress-fill" aria-hidden="true"></span>
        </div>
        <small>${numericValue} de ${numericTotal} disponibles</small>
      </div>`;
    }

    if (numericValue === 0) {
      return `<div class="cc-capacity-progress cc-capacity-progress-red cc-capacity-progress-zero" aria-label="0 disponibles">
        <div class="cc-progress-track"
             role="progressbar"
             aria-valuemin="0"
             aria-valuemax="0"
             aria-valuenow="0"
             style="--cc-progress-target:0%">
          <span class="cc-progress-fill" aria-hidden="true"></span>
        </div>
        <small>0 disponibles</small>
      </div>`;
    }

    return `<div class="cc-capacity-progress cc-capacity-progress-${esc(tone)} cc-capacity-progress-no-total" aria-label="${numericValue} disponibles">
      <div class="cc-progress-track" style="--cc-progress-target:0%">
        <span class="cc-progress-fill" aria-hidden="true"></span>
      </div>
      <small>${numericValue} disponibles</small>
    </div>`;
  }


  function animateDashboardCapacityBars() {
    // Consolidado final: la barra se anima mediante CSS con --cc-progress-target.
  }


  function normalizeQuickFilters(value) {
    if (Array.isArray(value)) {
      const items = value.map(v => String(v || "").toUpperCase()).filter(Boolean);
      const clean = [...new Set(items.filter(v => v !== "TODAS"))];
      return clean.length ? clean : ["TODAS"];
    }
    const single = String(value || "TODAS").toUpperCase();
    return single && single !== "TODAS" ? [single] : ["TODAS"];
  }



  function requestDisplayText(value, fallback = "—") {
    const raw = String(value ?? "").trim();
    return raw ? displayEnumText(raw) : fallback;
  }


  function requestStateValue(item) {
    return String(item?.Estado || item?.estado || "").trim().toUpperCase();
  }


  function requestUrgencyValue(item) {
    return String(item?.urgencia || "").trim().toUpperCase();
  }


  function requestOrderStateValue(item) {
    return String(item?.orden_estado_codigo || item?.orden_estado || "").trim().toUpperCase().replaceAll("_", " ");
  }


  function requestIsEmergency(item) {
    return requestClassValue(item) === "EMERGENCIA";
  }


  function requestIsCritical(item) {
    return /CRIT/.test(requestUrgencyValue(item));
  }


  function requestIsFinalized(item) {
    const orderState = requestOrderStateValue(item);
    const baseState = requestStateValue(item);
    return /(FINAL|COMPLET)/.test(orderState) || /(FINAL|COMPLET)/.test(baseState);
  }


  function requestIsInProcess(item) {
    if (requestIsFinalized(item)) return false;
    const orderState = requestOrderStateValue(item);
    const baseState = requestStateValue(item);
    if (item?.orden_id) return !/(CANCEL)/.test(orderState);
    return /(PROCESO|PROGRAM|REVISION|EVALUADA)/.test(orderState) || /(PROCESO|PROGRAM|EVALUADA)/.test(baseState);
  }


  function requestIsPending(item) {
    if (requestIsFinalized(item)) return false;
    if (item?.orden_id) return false;
    const baseState = requestStateValue(item);
    return !/(CANCEL|CONVERT)/.test(baseState);
  }


  function requestClassValue(item) {
    return String(item?.Clasificacion || item?.clasificacion || "").trim().toUpperCase();
  }


  function requestClassBadge(value) {
    const normalized = String(value || "").trim().toUpperCase();
    const label = requestDisplayText(normalized, "Sin clase");
    const emergency = normalized === "EMERGENCIA";
    return `<span class="request-class-pill ${emergency ? "emergency" : "scheduled"}">${emergency ? `<i data-lucide="zap"></i>` : `<i data-lucide="calendar-range"></i>`}<span>${esc(label)}</span></span>`;
  }


  function requestUrgencyBadge(value) {
    const normalized = String(value || "").trim().toUpperCase();
    const key = /CRIT/.test(normalized) ? "critical" : /ALTA/.test(normalized) ? "high" : /MEDIA/.test(normalized) ? "medium" : /BAJA/.test(normalized) ? "low" : "neutral";
    const label = requestDisplayText(normalized, "No aplica");
    return `<span class="request-priority-pill ${key}">${esc(label)}</span>`;
  }


  function requestStateBadge(item) {
    const baseState = requestStateValue(item);
    const orderState = requestOrderStateValue(item);
    let tone = "pending";
    let label = "Pendiente";
    if (requestIsFinalized(item)) {
      tone = "finalized";
      label = "Finalizada";
    } else if (/(CANCEL)/.test(baseState) || /(CANCEL)/.test(orderState)) {
      tone = "cancelled";
      label = "Cancelada";
    } else if (item?.orden_id && /(PROGRAM)/.test(orderState)) {
      tone = "scheduled";
      label = "Programada";
    } else if (item?.orden_id || /(PROCESO|PROGRAM|EVALUADA|REVISION)/.test(baseState) || /(PROCESO|REVISION)/.test(orderState)) {
      tone = "progress";
      label = item?.orden_id && /(PROGRAM)/.test(orderState) ? "Programada" : "En proceso";
    } else if (/(PROGRAM)/.test(baseState)) {
      tone = "scheduled";
      label = "Programada";
    }
    return `<span class="request-state-pill ${tone}"><span class="request-state-dot" aria-hidden="true"></span><span>${esc(label)}</span></span>`;
  }


  function requestFollowupLabel(item) {
    const orderState = requestOrderStateValue(item);
    const baseState = requestStateValue(item);
    if (requestIsFinalized(item)) return "FINALIZADA";
    if (/REVISION/.test(orderState)) return "EN REVISIÓN";
    if (/PROCESO|CURSO|ASIGN|INICIAD/.test(orderState)) return "EN PROCESO";
    if (/PROGRAM/.test(orderState)) return "PROGRAMADA";
    if (item?.orden_id) return "OT CREADA";
    if (/PROGRAM/.test(baseState)) return "PROGRAMADA";
    return requestDisplayText(baseState || "REGISTRADA", "REGISTRADA").toUpperCase();
  }


  function requestFollowupTone(label) {
    const value = String(label || "").toUpperCase();
    if (/FINAL/.test(value)) return "finalized";
    if (/PROCESO/.test(value)) return "progress";
    if (/REVISION/.test(value)) return "review";
    if (/PROGRAM/.test(value)) return "scheduled";
    if (/OT CREADA/.test(value)) return "created";
    return "neutral";
  }


  function requestFollowupMarkup(item) {
    const label = requestFollowupLabel(item);
    const tone = requestFollowupTone(label);
    const primary = item?.orden_id ? (item.orden_numero || `OT #${item.orden_id}`) : "Pendiente de coordinación";
    const secondarySource = item?.orden_id
      ? requestDisplayText(item.orden_estado || item.orden_estado_codigo || "Orden generada correctamente", "Orden generada correctamente")
      : requestDisplayText(item.Estado || item.estado || "Solicitud registrada", "Solicitud registrada");
    const normalized = value => String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replaceAll("_", " ").trim().toUpperCase();
    const summary = normalized(displayEnumText(label));
    const detail = normalized(secondarySource);
    const repeated = summary === detail || (/FINALIZ|COMPLET/.test(summary) && /FINALIZ|COMPLET/.test(detail));
    return `<div class="request-followup"><span class="request-followup-badge ${tone}">${esc(displayEnumText(label))}</span><strong class="mono">${esc(primary)}</strong>${repeated ? "" : `<span>${esc(secondarySource)}</span>`}</div>`;
  }


  function requestDateMarkup(value) {
    if (!value) return `<div class="request-date-cell"><strong>—</strong><span>Sin fecha</span></div>`;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return `<div class="request-date-cell"><strong>${esc(value)}</strong></div>`;
    return `<div class="request-date-cell"><strong class="mono">${esc(date.toLocaleDateString("es-GT", { day:"2-digit", month:"2-digit", year:"numeric" }))}</strong><span>${esc(date.toLocaleTimeString("es-GT", { hour:"numeric", minute:"2-digit" }))}</span></div>`;
  }


  function requestDescriptionPreview(text) {
    const raw = String(text ?? "").replace(/\s+/g, " ").trim();
    return raw || "Sin descripción registrada.";
  }


  function requestQuickLabel(key) {
    return ({
      TODAS: "Todas",
      PENDIENTES: "Pendientes",
      EMERGENCIAS: "Emergencias",
      CRITICAS: "Críticas",
      EN_PROCESO: "En proceso",
      FINALIZADAS: "Finalizadas"
    })[String(key || "").toUpperCase()] || requestDisplayText(key, "Filtro rápido");
  }


  function requestQuickDefinitions(items = []) {
    const defs = [
      ["TODAS", "Todas", "all"],
      ["PENDIENTES", "Pendientes", "pending"],
      ["EMERGENCIAS", "Emergencias", "emergency"],
      ["CRITICAS", "Críticas", "critical"],
      ["EN_PROCESO", "En proceso", "process"],
      ["FINALIZADAS", "Finalizadas", "finalized"]
    ].map(([key, label, tone]) => ({
      key,
      label,
      tone,
      count: (items || []).filter(item => requestQuickMatches(item, key)).length
    }));
    return defs.filter(def => def.key === "TODAS" || def.count > 0);
  }


  function requestQuickMatches(item, key) {
    switch (String(key || "TODAS").toUpperCase()) {
      case "PENDIENTES": return requestIsPending(item);
      case "EMERGENCIAS": return requestIsEmergency(item);
      case "CRITICAS": return requestIsCritical(item);
      case "EN_PROCESO": return requestIsInProcess(item);
      case "FINALIZADAS": return requestIsFinalized(item);
      default: return true;
    }
  }


  function requestActiveFilterChips(prefs) {
    const chips = [];
    const filters = prefs?.filtros || {};
    const labels = { estado: "Estado", clase: "Clase", urgencia: "Urgencia", sede: "Sede", rapido: "Filtro" };
    Object.entries(filters).forEach(([key, value]) => {
      if (key === "rapidos") {
        normalizeQuickFilters(value).filter(v => v !== "TODAS").forEach(filterKey => {
          const label = `Filtro: ${requestQuickLabel(filterKey)}`;
          chips.push(`<button class="request-active-chip" type="button" data-action="request-remove-quick-filter" data-list-key="solicitudes" data-quick-key="${esc(filterKey)}" aria-label="Quitar filtro ${esc(label)}"><span>${esc(label)}</span><i data-lucide="x"></i></button>`);
        });
        return;
      }
      if (key === "rapido") return;
      if (!value || value === "TODOS" || value === "TODAS") return;
      const label = `${labels[key] || key}: ${requestDisplayText(value)}`;
      chips.push(`<button class="request-active-chip" type="button" data-action="request-remove-filter" data-list-key="solicitudes" data-filter-name="${esc(key)}" aria-label="Quitar filtro ${esc(label)}"><span>${esc(label)}</span><i data-lucide="x"></i></button>`);
    });
    if (!chips.length) return "";
    return `<div class="request-active-filters"><span class="request-active-count">${chips.length} filtro${chips.length === 1 ? "" : "s"} activo${chips.length === 1 ? "" : "s"}</span><div class="request-active-chip-row">${chips.join("")}</div></div>`;
  }


  function requestPager(key, meta) {
    const page = Number(meta?.pagina || 1);
    const pages = Math.max(1, Number(meta?.paginas || 1));
    const total = Number(meta?.total || 0);
    const size = Number(meta?.tamano || 10);
    const start = total ? (page - 1) * size + 1 : 0;
    const end = Math.min(total, page * size);
    const nums = [];
    for (let n = Math.max(1, page - 2); n <= Math.min(pages, page + 2); n++) nums.push(n);
    return `<div class="smart-pagination request-pagination"><div class="smart-pagination-copy">Mostrando <strong>${start}</strong> a <strong>${end}</strong> de <strong>${total}</strong> resultados</div><div class="pager-buttons"><button type="button" class="pager-button" data-action="smart-page" data-list-key="${esc(key)}" data-page="${Math.max(1, page - 1)}" ${page <= 1 ? "disabled" : ""} aria-label="Página anterior"><i data-lucide="chevron-left"></i></button>${nums.map(n => `<button type="button" class="pager-button ${n === page ? "active" : ""}" data-action="smart-page" data-list-key="${esc(key)}" data-page="${n}">${n}</button>`).join("")}<button type="button" class="pager-button" data-action="smart-page" data-list-key="${esc(key)}" data-page="${Math.min(pages, page + 1)}" ${page >= pages ? "disabled" : ""} aria-label="Página siguiente"><i data-lucide="chevron-right"></i></button></div></div>`;
  }

  function dashboardRecentPager(meta) {
    const page = Number(meta?.pagina || 1);
    const pages = Math.max(1, Number(meta?.paginas || 1));
    const total = Number(meta?.total || 0);
    const size = Number(meta?.tamano || 4);
    const start = total ? (page - 1) * size + 1 : 0;
    const end = Math.min(total, page * size);
    const nums = [];
    for (let n = Math.max(1, page - 1); n <= Math.min(pages, page + 1); n++) nums.push(n);
    if (total <= size && pages <= 1) return `<div class="cc-recent-pagination"><div class="smart-pagination-copy">Mostrando <strong>${start}</strong> a <strong>${end}</strong> de <strong>${total}</strong> registros</div></div>`;
    return `<div class="cc-recent-pagination"><div class="smart-pagination-copy">Mostrando <strong>${start}</strong>–<strong>${end}</strong> de <strong>${total}</strong> registros</div><div class="pager-buttons"><button type="button" class="pager-button" data-action="dashboard-recent-page" data-page="${Math.max(1, page - 1)}" ${page <= 1 ? "disabled" : ""} aria-label="Página anterior"><i data-lucide="chevron-left"></i></button>${nums.map(n => `<button type="button" class="pager-button ${n === page ? "active" : ""}" data-action="dashboard-recent-page" data-page="${n}">${n}</button>`).join("")}<button type="button" class="pager-button" data-action="dashboard-recent-page" data-page="${Math.min(pages, page + 1)}" ${page >= pages ? "disabled" : ""} aria-label="Página siguiente"><i data-lucide="chevron-right"></i></button></div></div>`;
  }


  function normalizeOrderQuickFilters(value) {
    if (Array.isArray(value)) {
      const clean = [...new Set(value.map(v => String(v || "").toUpperCase()).filter(v => v && v !== "TODAS"))];
      return clean.length ? clean : ["TODAS"];
    }
    const single = String(value || "TODAS").toUpperCase();
    return single && single !== "TODAS" ? [single] : ["TODAS"];
  }


  function orderStateKey(value) {
    const raw = String(value || "").trim().toUpperCase().replace(/\s+/g, "_");
    if (/CANCEL/.test(raw)) return "CANCELADA";
    if (/FINAL|COMPLET|CERRAD/.test(raw)) return "FINALIZADA";
    if (/PROCESO|SERVICIO|EJECUC/.test(raw)) return "EN_PROCESO";
    if (/PROGRAM/.test(raw)) return "PROGRAMADA";
    return raw || "SIN_ESTADO";
  }


  function orderPriorityKey(value) {
    const raw = String(value || "").trim().toUpperCase();
    if (/CRIT/.test(raw)) return "CRITICA";
    if (/ALTA/.test(raw)) return "ALTA";
    if (/MEDIA/.test(raw)) return "MEDIA";
    if (/BAJA/.test(raw)) return "BAJA";
    return raw || "SIN_PRIORIDAD";
  }


  function orderDateForList(item) { return item?.creada || item?.programada || item?.iniciada || item?.finalizada || null; }


  function orderGtDateKey(value) {
    if (!value) return "";
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: "America/Guatemala", year: "numeric", month: "2-digit", day: "2-digit"
    }).formatToParts(date).reduce((acc, part) => { acc[part.type] = part.value; return acc; }, {});
    return `${parts.year}-${parts.month}-${parts.day}`;
  }


  function orderIsToday(item) { return orderGtDateKey(orderDateForList(item)) === orderGtDateKey(new Date()); }


  function orderDateFilterMatches(item, filter, prefs) {
    const selected = String(filter || "TODAS").toUpperCase();
    if (!selected || selected === "TODAS") return true;
    const key = orderGtDateKey(orderDateForList(item));
    if (!key) return false;
    const today = orderGtDateKey(new Date());
    if (selected === "HOY") return key === today;
    if (selected === "MES") return key.slice(0,7) === today.slice(0,7);
    if (selected === "SEMANA") {
      const d = new Date(`${today}T12:00:00Z`);
      const day = d.getUTCDay();
      const offset = (day + 6) % 7;
      const monday = new Date(d); monday.setUTCDate(d.getUTCDate() - offset);
      const sunday = new Date(monday); sunday.setUTCDate(monday.getUTCDate() + 6);
      const iso = value => value.toISOString().slice(0,10);
      return key >= iso(monday) && key <= iso(sunday);
    }
    if (selected === "PERSONALIZADO") {
      const from = String(prefs?.fechaDesde || "");
      const to = String(prefs?.fechaHasta || "");
      if (from && key < from) return false;
      if (to && key > to) return false;
      return true;
    }
    return true;
  }


  function orderQuickMatches(item, detail, key) {
    const quick = String(key || "TODAS").toUpperCase();
    if (quick === "EN_PROCESO") return orderStateKey(item.estado) === "EN_PROCESO";
    if (quick === "SIN_ASIGNAR") return !detail?._loadError && orderCrewRows(detail).length === 0;
    if (quick === "CRITICAS") return orderPriorityKey(item.Prioridad || item.prioridad) === "CRITICA";
    if (quick === "FINALIZADAS") return orderStateKey(item.estado) === "FINALIZADA";
    if (quick === "HOY") return orderIsToday(item);
    return true;
  }


  function orderStatePill(value) {
    const key = orderStateKey(value);
    const config = {
      PROGRAMADA: ["circle", "Programada", "info"],
      EN_PROCESO: ["refresh-cw", "En proceso", "warning"],
      FINALIZADA: ["check", "Finalizada", "success"],
      CANCELADA: ["x", "Cancelada", "danger"]
    }[key] || ["circle", requestDisplayText(value, "Sin estado"), "neutral"];
    return `<span class="order-status-pill ${config[2]}"><i data-lucide="${config[0]}"></i><span>${esc(config[1])}</span></span>`;
  }


  function orderPriorityPill(value) {
    const key = orderPriorityKey(value);
    const config = {
      CRITICA: ["triangle-alert", "Crítica", "critical"],
      ALTA: ["chevron-up", "Alta", "high"],
      MEDIA: ["circle", "Media", "medium"],
      BAJA: ["circle", "Baja", "low"]
    }[key] || ["circle", requestDisplayText(value, "Sin prioridad"), "neutral"];
    return `<span class="order-priority-pill ${config[2]}"><i data-lucide="${config[0]}"></i><span>${esc(config[1])}</span></span>`;
  }


  function orderDateMarkup(value) {
    if (!value) return `<div class="order-date-cell"><strong>—</strong><span>Sin fecha</span></div>`;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return `<div class="order-date-cell"><strong>${esc(value)}</strong></div>`;
    const date = new Intl.DateTimeFormat("es-GT", { timeZone:"America/Guatemala", day:"2-digit", month:"2-digit", year:"numeric" }).format(d);
    const time = new Intl.DateTimeFormat("es-GT", { timeZone:"America/Guatemala", hour:"numeric", minute:"2-digit" }).format(d);
    return `<div class="order-date-cell"><strong class="mono">${esc(date)}</strong><span>${esc(time)}</span></div>`;
  }


  async function loadOrderListDetails(items = []) {
    const pending = (items || []).filter(item => item?.id && !state.orderListDetailCache.has(String(item.id))).slice();
    const concurrency = Math.min(6, pending.length || 1);
    const workers = Array.from({ length: concurrency }, async () => {
      while (pending.length) {
        const item = pending.shift();
        const key = String(item.id);
        try {
          const detail = await api(`/api/ordenes/${encodeURIComponent(item.id)}`);
          state.orderListDetailCache.set(key, detail || { tecnicos:[], cotizaciones:[] });
        } catch (error) {
          state.orderListDetailCache.set(key, { tecnicos:[], cotizaciones:[], _loadError:true });
        }
      }
    });
    await Promise.all(workers);
    return new Map((items || []).map(item => [String(item.id), state.orderListDetailCache.get(String(item.id)) || { tecnicos:[], cotizaciones:[] }]));
  }


  function orderCrewRows(detail) {
    return (detail?.tecnicos || []).filter(t => ["ASIGNADO","CONFIRMADO","FINALIZADO"].includes(String(t.estado || t.Estado || "").toUpperCase()));
  }


  function orderCrewCell(detail) {
    if (detail?._loadError) return `<span class="order-tech-unavailable"><i data-lucide="circle-help"></i> No disponible</span>`;
    const crew = orderCrewRows(detail);
    if (!crew.length) return `<span class="order-unassigned-pill"><i data-lucide="triangle-alert"></i><span>Sin asignar</span></span>`;
    const first = crew[0];
    const subtitle = crew.length > 1 ? `+${crew.length - 1} técnico${crew.length - 1 === 1 ? "" : "s"}` : requestDisplayText(first.funcion, "Técnico");
    return entityAvatarLink(first.nombre || "Técnico asignado", { entity:first, subtitle, className:"order-tech-identity" }, "detalle-personal", state.role === "COORDINADOR" ? first.empleado_id : null);
  }


  function orderSupervisorCell(detail) {
    const supervisor = orderCrewRows(detail).find(t => String(t.funcion || "").toUpperCase().includes("SUPERV"));
    return supervisor ? `<span class="order-secondary-value">${entityDetailButton(supervisor.nombre,"detalle-personal",state.role === "COORDINADOR" ? supervisor.empleado_id : null)}</span>` : `<span class="order-secondary-value muted">—</span>`;
  }


  function orderQuoteCell(detail) {
    const quote = (detail?.cotizaciones || [])[0];
    return quote ? `<span class="order-secondary-value mono">${esc(quote.numero || `Cotización #${quote.id}`)}</span>` : `<span class="order-secondary-value muted">—</span>`;
  }


  function orderPager(meta) {
    const page = Number(meta.pagina || 1), pages = Math.max(1, Number(meta.paginas || 1)), total = Number(meta.total || 0), size = Number(meta.tamano || 20);
    const start = total ? (page - 1) * size + 1 : 0, end = Math.min(total, page * size);
    const nums=[]; for(let n=Math.max(1,page-2); n<=Math.min(pages,page+2); n++) nums.push(n);
    return `<div class="order-pagination">
      <div class="order-pagination-copy">Mostrando <strong>${start}–${end}</strong> de <strong>${total}</strong> órdenes</div>
      <div class="order-pagination-actions">
        <label class="order-page-size"><span>Mostrar</span><select data-smart-size data-smart-key="ordenes">${[10,20,50].map(n=>`<option value="${n}" ${size===n?"selected":""}>${n} por página</option>`).join("")}</select></label>
        <button type="button" class="order-page-button wide" data-action="smart-page" data-list-key="ordenes" data-page="${page-1}" ${page<=1?"disabled":""}><i data-lucide="chevron-left"></i><span>Anterior</span></button>
        ${nums.map(n=>`<button type="button" class="order-page-button ${n===page?"active":""}" data-action="smart-page" data-list-key="ordenes" data-page="${n}">${n}</button>`).join("")}
        <button type="button" class="order-page-button wide" data-action="smart-page" data-list-key="ordenes" data-page="${page+1}" ${page>=pages?"disabled":""}><span>Siguiente</span><i data-lucide="chevron-right"></i></button>
      </div>
    </div>`;
  }



  function hasPeopleCount(value){
    return value!==null && value!==undefined && Number.isFinite(Number(value));
  }


  function peopleCountBadge(key){
    const raw=state.peopleCounts?.[key];
    return hasPeopleCount(raw) ? `<span class="people-tab-count">${normalizeNumber(raw)}</span>` : "";
  }


  async function ensurePeopleCounts(currentKey="") {
    if(state.role!=="COORDINADOR") return;
    const keys=["clientes","personal","usuarios"];
    const fresh=Date.now()-Number(state.peopleCountsLoadedAt||0)<60000;
    if(fresh && keys.every(key=>hasPeopleCount(state.peopleCounts[key]))) return;
    if(state.peopleCountsInflight){ await state.peopleCountsInflight; return; }

    state.peopleCountsInflight=(async()=>{
      const jobs=[];
      if(currentKey!=="clientes" || !hasPeopleCount(state.peopleCounts.clientes)){
        jobs.push(api("/api/clientes?pagina=1&tamano=5").then(d=>{state.peopleCounts.clientes=normalizeNumber(d.total);}));
      }
      if(currentKey!=="personal" || !hasPeopleCount(state.peopleCounts.personal)){
        jobs.push(api("/api/personal?pagina=1&tamano=5&resumen=1").then(d=>{state.peopleCounts.personal=normalizeNumber(d.resumen?.total??d.total);}));
      }
      if(currentKey!=="usuarios" || !hasPeopleCount(state.peopleCounts.usuarios)){
        jobs.push(api("/api/usuarios?pagina=1&tamano=5").then(d=>{state.peopleCounts.usuarios=normalizeNumber(d.summary?.total??d.pagination?.total);}));
      }
      await Promise.all(jobs);
      state.peopleCountsLoadedAt=Date.now();
    })().catch(()=>{}).finally(()=>{state.peopleCountsInflight=null;});
    await state.peopleCountsInflight;
  }


  function peopleMetric(label,value,detail=""){
    const visual = ({
      "Clientes activos": ["building-2", "blue"],
      "Sedes registradas": ["map-pin", "cyan"],
      "Clientes inactivos": ["building-2", "amber"],
      "Personal activo": ["hard-hat", "blue"],
      "Disponibles": ["circle-check", "green"],
      "Asignados": ["briefcase-business", "cyan"],
      "Usuarios activos": ["users-round", "blue"],
      "Bloqueados": ["shield-alert", "red"],
      "Acceso reciente": ["clock-3", "cyan"]
    })[label] || ["chart-no-axes-column-increasing", "blue"];
    return `<article class="people-metric people-metric-${visual[1]}"><span class="people-metric-icon"><i data-lucide="${visual[0]}"></i></span><div class="people-metric-copy"><span>${esc(label)}</span><strong>${normalizeNumber(value)}</strong>${detail?`<small>${esc(detail)}</small>`:""}</div></article>`;
  }


  function peopleStatusBadge(value){
    const raw=String(value||"INACTIVO").toUpperCase().replaceAll("_"," ");
    const key=/BLOQUE/.test(raw)?"blocked":/ACTIVO/.test(raw)&&!/INACTIVO/.test(raw)?"active":/DISPONIBLE/.test(raw)?"available":/ASIGNADO/.test(raw)?"assigned":/VACACION/.test(raw)?"vacation":"inactive";
    const icon={active:"circle-check",inactive:"circle-minus",blocked:"lock-keyhole",available:"circle-check",assigned:"briefcase-business",vacation:"palmtree"}[key];
    return `<span class="people-status people-status-${key}"><i data-lucide="${icon}"></i>${esc(raw.charAt(0)+raw.slice(1).toLowerCase())}</span>`;
  }


  function peopleQuickButton(key,value,label,count,active){
    return `<button class="people-quick ${active?"active":""}" type="button" data-action="people-quick-filter" data-list-key="${esc(key)}" data-value="${esc(value)}"><span>${esc(label)}</span>${Number.isFinite(Number(count))?`<b>${normalizeNumber(count)}</b>`:""}</button>`;
  }


  function peopleActionMenu(items){
    const html=(items||[]).filter(Boolean).map(item=>item.separator?`<span class="people-action-separator" aria-hidden="true"></span>`:`<button type="button" class="people-action-item ${item.danger?"danger":""}" ${item.action?`data-action="${esc(item.action)}"`:""} ${item.module?`data-context-module="${esc(item.module)}"`:""} ${item.id?`data-id="${esc(item.id)}"`:""} ${item.attrs||""}><i data-lucide="${esc(item.icon||"circle")}"></i><span>${esc(item.label)}</span></button>`).join("");
    return `<details class="people-action-menu"><summary aria-label="Más acciones"><i data-lucide="ellipsis"></i></summary><div class="people-action-popover">${html}</div></details>`;
  }


  function peopleWorkspaceHeader(active){
    const actionMap={
      clientes:{label:"Nuevo cliente",action:"nuevo-cliente",icon:"building-2"},
      personal:{label:"Nuevo empleado",action:"nuevo-empleado",icon:"user-round-plus"},
      usuarios:{label:"Nuevo usuario",action:"nuevo-usuario",icon:"user-round-plus"}
    };
    const action=actionMap[active]||actionMap.clientes;
    const tabs=[
      ["clientes","Clientes y sedes"],
      ["personal","Personal"],
      ["usuarios","Usuarios del sistema"],["vacaciones","Horarios y vacaciones"],["produccion","Resumen semanal"]
    ].map(([key,label])=>`<button class="people-tab ${active===key?"active":""}" type="button" data-context-module="${key}" aria-current="${active===key?"page":"false"}"><span>${label}</span>${peopleCountBadge(key)}</button>`).join("");
    return `<header class="people-page-header">
      <div class="people-page-title-row">
        <div class="people-page-copy"><h1>Clientes y personal</h1><p>Administra clientes, sedes, colaboradores y accesos del sistema.</p></div>
        <button class="people-primary-action" type="button" data-action="${action.action}"><i data-lucide="${action.icon}"></i><span>${action.label}</span></button>
      </div>
      <nav class="people-tabs" aria-label="Secciones de Clientes y personal">${tabs}</nav>
    </header>`;
  }


  function peopleTableShell(title,result,headers,rows,pager,key){
    const body=rows.length?`<div class="people-table-scroll se-table-responsive-scope"><table class="people-table ${headers.length > 5 ? "se-wide-table" : ""}"><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`:`<div class="people-empty"><i data-lucide="search-x"></i><h3>No encontramos registros con estos filtros.</h3><p>Prueba cambiando los filtros o limpia la búsqueda.</p><button class="btn small" type="button" data-action="smart-reset" data-list-key="${esc(key)}"><i data-lucide="rotate-ccw"></i><span>Limpiar filtros</span></button></div>`;
    return `<section class="people-table-section"><div class="people-table-toolbar"><div><h3>${esc(title)}</h3><span>${normalizeNumber(result.total)} resultados</span></div></div>${body}${pager}</section>`;
  }


  function equipmentMaintenanceTabs(active) {
    return `<section class="module-context-switcher coord-equipment-tabs" aria-label="Equipo y mantenimiento"><div class="module-context-tabs"><button class="context-tab ${active==="equipos"?"active":""}" type="button" data-context-module="equipos" aria-current="${active==="equipos"?"page":"false"}"><span class="context-tab-icon"><i data-lucide="package-search"></i></span><span class="context-tab-copy"><strong>Equipo</strong></span></button><button class="context-tab" type="button" data-action="ver-vehiculos"><span class="context-tab-icon"><i data-lucide="truck"></i></span><span class="context-tab-copy"><strong>Vehículos</strong></span></button><button class="context-tab ${active==="mantenimientos"?"active":""}" type="button" data-context-module="mantenimientos" aria-current="${active==="mantenimientos"?"page":"false"}"><span class="context-tab-icon"><i data-lucide="settings"></i></span><span class="context-tab-copy"><strong>Mantenimiento</strong></span></button></div></section>`;
  }


  function coordinatorCompactMetrics(items = [], extraClass = "") {
    return `<section class="coord-compact-metrics ${esc(extraClass)}">${items.map(item => `<article class="coord-compact-metric ${esc(item.tone || "blue")}"><span class="coord-compact-icon"><i data-lucide="${esc(item.icon || "activity")}"></i></span><div><strong>${normalizeNumber(item.value)}</strong><small>${esc(item.label || "Dato")}</small>${item.note ? `<span>${esc(item.note)}</span>` : ""}</div></article>`).join("")}</section>`;
  }


  function quoteStateKey(value) {
    return String(value || "BORRADOR").trim().toUpperCase().replaceAll(" ", "_");
  }


  function quoteStateTone(value) {
    const key = quoteStateKey(value);
    if (["ACEPTADA","APROBADA"].includes(key)) return "success";
    if (["RECHAZADA","ANULADA"].includes(key)) return "danger";
    if (key === "ENVIADA") return "info";
    if (["OBSERVADA","CONFIRMADA","PENDIENTE"].includes(key)) return "warning";
    return "neutral";
  }


  function quoteStateLabel(value) {
    const key = quoteStateKey(value);
    const labels = {
      BORRADOR: "Borrador",
      PENDIENTE: "Pendiente",
      OBSERVADA: "Observada",
      CONFIRMADA: "Confirmada",
      ENVIADA: "Enviada",
      ACEPTADA: "Aprobada",
      APROBADA: "Aprobada",
      RECHAZADA: "Rechazada",
      ANULADA: "Anulada"
    };
    return labels[key] || key.replaceAll("_", " ").replace(/\b\w/g, c => c.toUpperCase());
  }


  function quoteStateIcon(value) {
    const key = quoteStateKey(value);
    if (["ACEPTADA","APROBADA"].includes(key)) return "check";
    if (["RECHAZADA","ANULADA"].includes(key)) return "x";
    if (key === "ENVIADA") return "send";
    if (["OBSERVADA","CONFIRMADA","PENDIENTE"].includes(key)) return "clock-3";
    return "circle";
  }


  function quoteStatusBadge(value) {
    return `<span class="quote-status quote-status-${quoteStateTone(value)}"><i data-lucide="${quoteStateIcon(value)}"></i><span>${esc(quoteStateLabel(value))}</span></span>`;
  }


  function quoteGTDateKey(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: "America/Guatemala", year: "numeric", month: "2-digit", day: "2-digit"
    }).formatToParts(date).reduce((acc, part) => { acc[part.type] = part.value; return acc; }, {});
    return `${parts.year}-${parts.month}-${parts.day}`;
  }


  function quoteDateFilterMatches(item, filter) {
    const selected = String(filter || "TODAS").toUpperCase();
    if (selected === "TODAS") return true;
    const itemKey = quoteGTDateKey(item.emision || item.creada);
    const todayKey = quoteGTDateKey(new Date());
    if (!itemKey || !todayKey) return true;
    if (selected === "HOY") return itemKey === todayKey;
    if (selected === "MES") return itemKey.slice(0, 7) === todayKey.slice(0, 7);
    if (selected === "SEMANA") {
      const current = new Date(`${todayKey}T12:00:00-06:00`);
      const currentDay = current.getUTCDay() || 7;
      const monday = new Date(current);
      monday.setUTCDate(current.getUTCDate() - currentDay + 1);
      const sunday = new Date(monday);
      sunday.setUTCDate(monday.getUTCDate() + 6);
      const target = new Date(`${itemKey}T12:00:00-06:00`);
      return target >= monday && target <= sunday;
    }
    return true;
  }


  function quoteDateShort(value) {
    if (!value) return "—";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return esc(value);
    return new Intl.DateTimeFormat("es-GT", {
      timeZone: "America/Guatemala", day: "2-digit", month: "2-digit", year: "numeric"
    }).format(date);
  }


  function quoteTabGroup(value) {
    const key = quoteStateKey(value);
    if (key === "BORRADOR") return "BORRADORES";
    if (["OBSERVADA","CONFIRMADA","PENDIENTE"].includes(key)) return "PENDIENTES";
    if (key === "ENVIADA") return "ENVIADAS";
    if (["ACEPTADA","APROBADA"].includes(key)) return "APROBADAS";
    if (["RECHAZADA","ANULADA"].includes(key)) return "RECHAZADAS";
    return "OTRAS";
  }


  function quotePager(meta) {
    const page = Number(meta.pagina || 1), pages = Math.max(1, Number(meta.paginas || 1)), total = Number(meta.total || 0), size = Number(meta.tamano || 15);
    const start = total ? (page - 1) * size + 1 : 0;
    const end = Math.min(total, page * size);
    const nums = [];
    for (let n = Math.max(1, page - 2); n <= Math.min(pages, page + 2); n++) nums.push(n);
    return `<footer class="quote-pagination"><span>Mostrando <strong>${start}–${end}</strong> de <strong>${total}</strong></span><div class="quote-page-buttons"><button type="button" data-action="smart-page" data-list-key="cotizaciones" data-page="${page-1}" ${page<=1?"disabled":""} aria-label="Página anterior"><i data-lucide="chevron-left"></i></button>${nums.map(n=>`<button type="button" class="${n===page?"active":""}" data-action="smart-page" data-list-key="cotizaciones" data-page="${n}">${n}</button>`).join("")}<button type="button" data-action="smart-page" data-list-key="cotizaciones" data-page="${page+1}" ${page>=pages?"disabled":""} aria-label="Página siguiente"><i data-lucide="chevron-right"></i></button></div></footer>`;
  }


  async function withContextualLoader(task, label = "Actualizando...", successText = "Actualizado") {
    const token = window.SEPRIGUALoader?.startContextual?.({ label, delay: 80 });
    try {
      return await task();
    } finally {
      if (token) await window.SEPRIGUALoader?.finishContextual?.(token, { successText });
    }
  }


  function confirmLogout() {
    closeTopPopovers();
    openModal("Cerrar sesión", `
      <div class="logout-confirmation">
        <span class="logout-confirm-icon" aria-hidden="true"><i data-lucide="log-out"></i></span>
        <div class="logout-confirm-copy">
          <strong>¿Deseas cerrar sesión?</strong>
          <p>Tu sesión actual se cerrará y volverás a la pantalla de acceso.</p>
        </div>
        <div class="logout-confirm-actions">
          <button class="btn logout-confirm-no" type="button" data-action="cancelar-logout">No</button>
          <button class="btn logout-confirm-yes" type="button" data-action="confirmar-logout">Sí</button>
        </div>
      </div>
    `, { lockBackdrop: false });
  }


  async function api(url, opts = {}) {
    const { seCache = "default", ...fetchOptions } = opts || {};
    const options = { credentials: "same-origin", ...fetchOptions };
    const method = String(options.method || "GET").toUpperCase();
    const cacheable = method === "GET";
    const cacheKey = String(url);

    if (cacheable && seCache !== "reload" && seCache !== "no-store") {
      const cached = getApiCache(url);
      if (cached !== null) return cached;
      const inflight = state.apiInflight.get(cacheKey);
      if (inflight) return cloneApiValue(await inflight);
    }

    const execute = async () => {
      if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
        options.headers = { ...(options.headers || {}), "X-SEPRIGUA-Request": "1" };
      }
      if (options.body && !(options.body instanceof FormData) && typeof options.body !== "string") {
        options.headers = { "Content-Type": "application/json", ...(options.headers || {}) };
        options.body = JSON.stringify(options.body);
      }
      let r;
      try {
        r = await fetch(url, options);
      } catch (cause) {
        const fallo = new Error(cause?.name === "AbortError"
          ? "La petición tardó demasiado en responder."
          : "No se pudo establecer comunicación con el servidor.");
        fallo.connectionError = true;
        throw fallo;
      }
      let data = {};
      try { data = await r.json(); } catch (_) { data = { ok: false }; }
      if (r.status === 401) { location.replace("/login"); throw new Error("Sesión vencida"); }
      if (!r.ok || data.ok === false) {
        const mensajePorCodigo = {
          400: "Revisa los datos enviados.", 403: "Tu cuenta no tiene permiso para acceder.",
          404: "No encontramos el recurso solicitado.", 409: "La operación entra en conflicto con los datos actuales.",
          413: "El archivo supera el tamaño permitido.", 429: "Demasiados intentos. Espera un momento.",
          500: "Ocurrió un problema en el servidor.", 502: "No se pudo conectar con el servicio.",
          503: "El servicio no está disponible temporalmente.", 504: "El servidor tardó demasiado en responder."
        };
        const texto = typeof data.message === "string" && data.message.trim() && r.status < 500
          ? data.message : (mensajePorCodigo[r.status] || "No fue posible completar la operación.");
        const fallo = new Error(texto);
        fallo.httpStatus = Number(r.status) || null;
        fallo.requestPath = String(url).split("?")[0];
        throw fallo;
      }
      if (cacheable && seCache !== "no-store") setApiCache(url, data);
      if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
        invalidateListsForMutation(url);
        document.dispatchEvent(new CustomEvent("seprigua:tour-change", {detail:{path:String(url).split("?")[0],method}}));
      }
      return cloneApiValue(data);
    };

    if(!cacheable){
      if(options.body instanceof FormData)return execute();
      const key=method+url+JSON.stringify(options.body||null);
      if(state.mutationInflight.has(key))return state.mutationInflight.get(key);
      const task=execute();state.mutationInflight.set(key,task);
      try{return await task;}finally{state.mutationInflight.delete(key);}
    }
    if(seCache==="reload")return execute();

    const promise = execute();
    state.apiInflight.set(cacheKey, promise);
    try { return cloneApiValue(await promise); }
    finally {
      if (state.apiInflight.get(cacheKey) === promise) state.apiInflight.delete(cacheKey);
    }
  }

  let liveBackendCheck = null;
  async function verifyLiveBackend() {
    if (liveBackendCheck) return liveBackendCheck;
    liveBackendCheck = (async () => {
      const controller = new AbortController();
      const timeout = window.setTimeout(() => controller.abort(), 12000);
      try {
        const response = await fetch("/api/db/health", {
          credentials: "same-origin", cache: "no-store", signal: controller.signal,
          headers: { Accept: "application/json" }
        });
        if (!response.ok) {
          const fallo = new Error(response.status === 503
            ? "El servicio de datos no está disponible temporalmente."
            : "El sistema no pudo completar la verificación de conexión.");
          fallo.httpStatus = response.status;
          throw fallo;
        }
        const health = await response.json();
        dbBadge.classList.toggle("error", !health.system_migration);
        dbBadgeText.textContent = health.system_migration ? "Sistema conectado" : "Configuración pendiente";
      } catch (error) {
        if (error instanceof TypeError || error?.name === "AbortError") {
          const fallo = new Error(error?.name === "AbortError"
            ? "El servidor tardó demasiado en responder. Comprueba la conexión e inténtalo de nuevo."
            : "No se pudo establecer comunicación con el servidor. Comprueba la conexión e inténtalo de nuevo.");
          fallo.connectionError = true;
          throw fallo;
        }
        throw error;
      } finally {
        window.clearTimeout(timeout);
      }
    })();
    try { return await liveBackendCheck; }
    finally { liveBackendCheck = null; }
  }

  // Presentación de fallos de módulos: HTTP real cuando existe respuesta,
  // mensaje de conexión independiente cuando nunca se recibió una respuesta.
  function sepriguaModuleError(module, error) {
    const status = Number(error?.httpStatus) || 0;
    const conexion = Boolean(error?.connectionError) || !status;
    const codigo = conexion ? "SIN CONEXIÓN" : `HTTP ${status}`;
    const titulo = conexion ? "No pudimos conectar con SEPRIGUA"
      : status === 403 ? "Acceso restringido"
      : status === 404 ? "Contenido no encontrado"
      : status === 429 ? "Demasiados intentos"
      : status >= 500 ? "El servicio está temporalmente indisponible"
      : "No fue posible cargar esta sección";
    const descripcion = String(error?.message || (conexion
      ? "Comprueba tu conexión y que el servidor de pruebas esté encendido."
      : "Vuelve a intentarlo dentro de unos momentos.")).slice(0, 350);
    const ruta = state.role === "CLIENTE" ? "/sistema/cliente"
      : state.role === "TECNICO" ? "/sistema/tecnico" : "/sistema/coordinador";
    return `<section class="se-http-module" role="alert" aria-live="polite">
      <div class="se-http-module__art" aria-hidden="true"><span class="se-http-module__ring"></span><span class="se-http-module__symbol">${conexion ? "⌁" : status === 403 ? "🔒" : "!"}</span></div>
      <div class="se-http-module__content">
        <div class="se-http-module__eyebrow"><span></span> SEPRIGUA / ESTADO DEL SISTEMA</div>
        <div class="se-http-module__code">${esc(codigo)}</div>
        <h2>${esc(titulo)}</h2><p>${esc(descripcion)}</p>
        <div class="se-http-module__actions"><button class="btn primary" type="button" data-action="reintentar-modulo" data-module="${esc(module)}"><i data-lucide="refresh-cw"></i> Reintentar</button>
        <a class="btn" href="${ruta}"><i data-lucide="house"></i> Ir al inicio</a></div>
        <div class="se-http-module__help">${conexion
          ? "No se recibió una respuesta HTTP. Revisa Waitress, el túnel SSH y la conexión de red."
          : "Se recibió una respuesta del servidor. Si el fallo persiste, informa este código al administrador."}</div>
      </div></section>`;
  }

  function showUnavailableModule(module, error) {
    state.current = module;
    state.apiCache.clear();
    state.listCache = {};
    state.viewCache.clear();
    state.dirtyModules.add(module);
    dbBadge.classList.add("error");
    dbBadgeText.textContent = "Sin conexión";
    applyModuleVisualMode(module);
    renderNav();
    content.removeAttribute("data-rendered-module");
    content.dataset.offline = "1";
    content.innerHTML = sepriguaModuleError(module, error);
    window.lucide?.createIcons();
  }

  const pushClient = { registration: null, config: null, inFlight: null, lastError: "" };

  function pushBrowserSupported() {
    return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
  }

  function isIosDevice() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  }

  function isStandalonePwa() {
    return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  }

  function urlBase64ToUint8Array(value) {
    const padding = "=".repeat((4 - value.length % 4) % 4);
    const base64 = (value + padding).replace(/-/g, "+").replace(/_/g, "/");
    const raw = atob(base64);
    return Uint8Array.from([...raw].map(ch => ch.charCodeAt(0)));
  }

  function currentPushDeviceName() {
    const ua = navigator.userAgent || "";
    const os = /Android/i.test(ua) ? "Android" : /iPhone|iPad|iPod/i.test(ua) ? "iPhone / iPad" : /Windows/i.test(ua) ? "Windows" : /Macintosh/i.test(ua) ? "macOS" : "Dispositivo";
    const browser = /Edg\//.test(ua) ? "Edge" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "Navegador";
    return `${os} · ${browser}`;
  }

  async function getPushConfig() {
    if (pushClient.config) return pushClient.config;
    pushClient.config = await api("/api/push/config");
    return pushClient.config;
  }

  async function getPushRegistration() {
    if (!pushBrowserSupported()) return null;
    if (pushClient.registration) return pushClient.registration;
    pushClient.registration = await navigator.serviceWorker.register("/service-worker.js", { scope: "/" });
    await navigator.serviceWorker.ready;
    return pushClient.registration;
  }

  async function savePushSubscription(subscription) {
    return api("/api/push/suscribir", { method:"POST", body:{ subscription: subscription.toJSON(), nombre_dispositivo: currentPushDeviceName() } });
  }

  async function currentPushEndpointHash() {
    if (!pushBrowserSupported() || !window.isSecureContext || !window.crypto?.subtle) return "";
    const registration = await navigator.serviceWorker.getRegistration("/");
    const subscription = await registration?.pushManager.getSubscription();
    if (!subscription) return "";
    const digest = await window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(subscription.endpoint));
    return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, "0")).join("");
  }

  async function syncPushSubscription({ prompt=false } = {}) {
    if (pushClient.inFlight) return pushClient.inFlight;
    pushClient.inFlight = (async () => {
    try {
      if (isIosDevice() && !isStandalonePwa()) throw new Error("En iPhone/iPad, primero agrega SEPRIGUA a la pantalla de inicio y ábrela desde su icono.");
      if (!pushBrowserSupported()) throw new Error("Este navegador no admite notificaciones Web Push.");
      if (!window.isSecureContext) throw new Error("Las notificaciones requieren HTTPS. En la PC local también funcionan usando localhost.");
      if (pushClient.config && (!pushClient.config.enabled || !pushClient.config.public_key)) throw new Error("Las notificaciones todavía no están configuradas en el servidor.");
      let permission = Notification.permission;
      if (permission === "default" && prompt) permission = await Notification.requestPermission();
      if (permission === "denied") throw new Error("Las notificaciones están bloqueadas para SEPRIGUA en este navegador.");
      if (permission !== "granted") throw new Error("Debes permitir las notificaciones en el navegador para activarlas.");
      const config = await getPushConfig();
      if (!config.enabled || !config.public_key) throw new Error("Las notificaciones todavía no están configuradas en el servidor.");
      const registration = await getPushRegistration();
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) {
        const options = { userVisibleOnly:true, applicationServerKey:urlBase64ToUint8Array(config.public_key) };
        try {
          subscription = await registration.pushManager.subscribe(options);
        } catch (error) {
          if (!/push service error/i.test(String(error?.message || ""))) throw error;
          await new Promise(resolve => setTimeout(resolve, 800));
          subscription = await registration.pushManager.getSubscription();
          if (!subscription) {
            try { subscription = await registration.pushManager.subscribe(options); }
            catch (retryError) {
              if (!/push service error/i.test(String(retryError?.message || ""))) throw retryError;
              throw new Error("El navegador no pudo registrarse en su servicio push. Cierra y vuelve a abrir el navegador; si persiste, prueba con Edge u otra red. El permiso concedido todavía no activa los avisos.");
            }
          }
        }
      }
      await savePushSubscription(subscription);
      pushClient.lastError = "";
      return subscription;
    } catch (error) {
      pushClient.lastError = String(error?.message || "No fue posible activar las notificaciones.");
      throw error;
    }
    })();
    try { return await pushClient.inFlight; }
    finally { pushClient.inFlight = null; }
  }

  async function disablePushOnThisDevice() {
    const registration = await getPushRegistration();
    const subscription = registration ? await registration.pushManager.getSubscription() : null;
    if (!subscription) return;
    try { await api("/api/push/desuscribir", { method:"POST", body:{ subscription:subscription.toJSON() } }); }
    finally { await subscription.unsubscribe().catch(()=>{}); }
  }

  async function initializePushSilently() {
    if (!pushBrowserSupported() || !window.isSecureContext || Notification.permission !== "granted") return;
    if (isIosDevice() && !isStandalonePwa()) return;
    try { await syncPushSubscription({prompt:false}); } catch (_) {}
  }

  function pushStatusMarkup(devices = [], serverConfig = {}) {
    const supported = pushBrowserSupported();
    const secure = window.isSecureContext;
    const iosNeedsInstall = isIosDevice() && !isStandalonePwa();
    const permission = supported ? Notification.permission : "unsupported";
    const activeHere = permission === "granted" && secure && !iosNeedsInstall && devices.some(device => device.actual);
    let statusTitle = "Listas para activar";
    let statusText = "Activa los avisos importantes en este dispositivo.";
    let statusClass = "pending";
    if (iosNeedsInstall) { statusTitle="Agrega SEPRIGUA al inicio"; statusText="En Safari, toca Compartir → Agregar a pantalla de inicio. Si aparece Abrir como app web, actívalo. Luego abre SEPRIGUA desde su icono."; }
    else if (!supported) { statusTitle="No disponible"; statusText="Este navegador no admite Web Push. En iPhone y iPad necesitas la versión 16.4 o posterior."; statusClass="off"; }
    else if (!secure) { statusTitle="Requiere HTTPS"; statusText="Abre SEPRIGUA mediante HTTPS para activar los avisos."; statusClass="off"; }
    else if (permission === "denied") { statusTitle="Bloqueadas en el navegador"; statusText="Debes volver a permitir notificaciones desde la configuración del navegador."; statusClass="off"; }
    else if (!serverConfig.enabled) { statusTitle="Configuración pendiente"; statusText="El servidor todavía no tiene Web Push disponible."; statusClass="off"; }
    else if (activeHere) { statusTitle="Activadas en este dispositivo"; statusText="Recibirás únicamente avisos importantes cuando SEPRIGUA no esté al frente."; statusClass="on"; }
    else if (permission === "granted") { statusTitle="Registro pendiente"; statusText=pushClient.lastError || "El permiso está concedido, pero este dispositivo aún no figura registrado para recibir avisos."; }
    const actions = supported && secure && !iosNeedsInstall && serverConfig.enabled
      ? (activeHere
          ? `<button class="btn small" type="button" data-action="probar-push"><i data-lucide="bell-ring"></i> Probar</button><button class="btn small danger" type="button" data-action="desactivar-push"><i data-lucide="bell-off"></i> Desactivar aquí</button>`
          : `<button class="btn primary" type="button" data-action="activar-push"><i data-lucide="bell-ring"></i> Activar notificaciones</button>`)
      : "";
    const deviceCards = devices.length ? devices.map(x=>`<article class="push-device-row"><span class="push-device-icon"><i data-lucide="smartphone"></i></span><div><strong>${esc(x.nombre||"Dispositivo")}</strong><small>${x.ultimo_uso?`Registrado ${fmt(x.ultimo_uso)}`:"Registrado para avisos"}</small></div><button class="icon-button" type="button" data-action="eliminar-dispositivo-push" data-id="${esc(x.id)}" aria-label="Desactivar dispositivo" title="Desactivar"><i data-lucide="x"></i></button></article>`).join("") : `<div class="push-empty">Aún no hay dispositivos registrados.</div>`;
    const headerStatus = activeHere ? "Activo" : statusClass === "off" ? "No disponible" : "Pendiente";
    const explainerTitle = activeHere ? "Notificaciones activas en este dispositivo" : statusTitle;
    return `<section class="panel account-panel push-panel"><div class="panel-header push-panel-header"><div><h2>Notificaciones en celular y PC</h2><p class="muted">Recibe avisos importantes aunque el portal esté cerrado o en segundo plano.</p></div><span class="push-state ${statusClass}"><i data-lucide="${activeHere?'bell-ring':'bell'}"></i><span>${esc(headerStatus)}</span></span></div><div class="panel-body push-panel-body"><div class="push-explainer"><span class="push-hero-icon"><i data-lucide="smartphone-nfc"></i></span><div class="push-explainer-copy"><strong>${esc(explainerTitle)}</strong><p>${esc(statusText)}</p><small>Solo enviamos avisos importantes: solicitudes, asignaciones, inicio o finalización, cotizaciones y cambios relevantes.</small></div></div><div class="push-actions">${actions}</div><div class="push-device-list"><div class="push-device-heading"><div><strong>Dispositivos registrados</strong><small>Administra dónde quieres recibir los avisos.</small></div><span>Celular y computadora</span></div>${deviceCards}</div></div></section>`;
  }

  async function handlePushDeepLink() {
    const params = new URLSearchParams(location.search);
    const entity = params.get("push_entity");
    const id = params.get("push_id");
    if (!entity) return;
    try { await openNotificationTarget(entity, id); }
    catch (err) { showToast(err.message || "No fue posible abrir el aviso.", "error"); }
    const clean = rolePaths[state.role] || location.pathname;
    history.replaceState(null, "", clean);
  }

  function cloneApiValue(value) {
    try { return typeof structuredClone === "function" ? structuredClone(value) : JSON.parse(JSON.stringify(value)); }
    catch (_) { return value; }
  }

  function apiCacheTtl(url) {
    const path = String(url || "").split("?")[0];
    if (/\/api\/notificaciones/.test(path)) return 8000;
    if (/\/api\/auditoria/.test(path)) return 12000;
    if (/\/api\/dashboard/.test(path)) return 18000;
    if (/\/api\/agenda-operativa/.test(path)) return 15000;
    if (/\/api\/cuenta|\/api\/sesiones/.test(path)) return 15000;
    return 45000;
  }

  function getApiCache(url) {
    const hit = state.apiCache.get(String(url));
    if (!hit) return null;
    if (Date.now() - hit.time > hit.ttl) { state.apiCache.delete(String(url)); return null; }
    return cloneApiValue(hit.data);
  }

  function setApiCache(url, data) {
    state.apiCache.set(String(url), { time:Date.now(), ttl:apiCacheTtl(url), data:cloneApiValue(data) });
  }

  const viewCacheEligible = new Set([
    "dashboard", "solicitudes", "ordenes", "clientes", "personal", "usuarios",
    "equipos", "mantenimientos", "catalogo", "cotizaciones",
    "garantia", "notificaciones", "auditoria", "sedes", "vacaciones"
  ]);

  function normalizeViewCacheKey(key) {
    const value = String(key || "");
    if (value === "documentos-laborales") return "documentos";
    if (value === "garantiaSolicitudes") return "garantia";
    return value;
  }

  function viewCacheTtl(module) {
    if (module === "notificaciones") return 15000;
    if (module === "dashboard") return 30000;
    if (module === "auditoria") return 30000;
    return 120000;
  }

  function invalidateViewCache(...keys) {
    keys.flat().filter(Boolean).forEach(key => {
      const module = normalizeViewCacheKey(key);
      state.viewCache.delete(module);
    });
  }

  function markModulesDirty(...keys) {
    keys.flat().filter(Boolean).forEach(key => state.dirtyModules.add(normalizeViewCacheKey(key)));
    invalidateViewCache(...keys);
  }

  function saveViewSnapshot(module) {
    if (!viewCacheEligible.has(module)) return;
    state.viewCache.set(module, {
      time: Date.now(),
      html: content.innerHTML,
      title: title?.textContent || "",
      subtitle: subtitle?.textContent || "",
      eyebrow: eyebrow?.textContent || ""
    });
    state.dirtyModules.delete(module);
  }

  function getViewSnapshot(module) {
    if(["agenda","produccion","cancelaciones"].includes(module))return null;
    const snap = state.viewCache.get(module);
    if (!snap) return null;
    if (state.dirtyModules.has(module) || Date.now() - snap.time > viewCacheTtl(module)) {
      state.viewCache.delete(module);
      return null;
    }
    return snap;
  }

  function restoreViewSnapshot(module, snap) {
    if (!snap) return false;
    applyModuleVisualMode(module);
    if (title) title.textContent = snap.title || "";
    if (subtitle) subtitle.textContent = snap.subtitle || "";
    if (eyebrow) eyebrow.textContent = snap.eyebrow || "";
    content.innerHTML = snap.html;
    content.dataset.renderedModule = module;
    syncPrototypeChrome();
    enhanceRenderedContent();
    return true;
  }

  async function refreshCatalogs(force=false){
    if(force||!state.catalogsUpdatedAt||Date.now()-state.catalogsUpdatedAt>30000){state.catalogs=await api('/api/catalogos',{seCache:'reload'});state.catalogsUpdatedAt=Date.now();}return state.catalogs;
  }

  function invalidateApiCache(matchers = []) {
    const list = Array.isArray(matchers) ? matchers : [matchers];
    if (!list.length) return;
    for (const key of [...state.apiCache.keys()]) {
      if (list.some(m => typeof m === "string" ? key.includes(m) : m?.test?.(key))) state.apiCache.delete(key);
    }
  }

  function invalidateApiCacheForModule(module) {
    const map = {
      dashboard:["/api/dashboard"], solicitudes:["/api/solicitudes"], ordenes:["/api/ordenes"], agenda:["/api/agenda-operativa"],
      clientes:["/api/clientes"], personal:["/api/personal"], usuarios:["/api/usuarios"], equipos:["/api/equipos"],
      mantenimientos:["/api/mantenimientos"], catalogo:["/api/catalogo-maestro"], cotizaciones:["/api/cotizaciones"],
      documentos:["/api/documentos"], garantia:["/api/garantias"], notificaciones:["/api/notificaciones"],
      roles:["/api/roles-accesos"], cuenta:["/api/cuenta","/api/sesiones"], auditoria:["/api/auditoria"], sedes:["/api/mis-sedes","/api/ubicaciones"]
    };
    invalidateApiCache(map[module] || []);
  }

  function invalidateApiCacheForMutation(url) {
    const path=String(url||"").split("?")[0];
    const groups=[
      [/\/api\/solicitudes/, ["/api/solicitudes","/api/ordenes","/api/dashboard"]],
      [/\/api\/ordenes/, ["/api/ordenes","/api/solicitudes","/api/agenda-operativa","/api/cotizaciones","/api/documentos","/api/garantias","/api/dashboard"]],
      [/\/api\/clientes/, ["/api/clientes","/api/solicitudes","/api/dashboard"]],
      [/\/api\/personal/, ["/api/personal","/api/ordenes","/api/agenda-operativa","/api/dashboard"]],
      [/\/api\/equipos|\/api\/mantenimientos/, ["/api/equipos","/api/mantenimientos","/api/dashboard"]],
      [/\/api\/cotizaciones|\/api\/catalogo-maestro/, ["/api/cotizaciones","/api/catalogo-maestro","/api/dashboard"]],
      [/\/api\/documentos/, ["/api/documentos","/api/dashboard"]],
      [/\/api\/cuenta(?:\/|$)/, ["/api/cuenta","/api/auth/me"]],
      [/\/api\/garantias/, ["/api/garantias","/api/dashboard"]],
      [/\/api\/notificaciones/, ["/api/notificaciones"]],
      [/\/api\/auditoria/, ["/api/auditoria"]],
      [/\/api\/roles|\/api\/usuarios/, ["/api/roles-accesos","/api/usuarios"]],
      [/\/api\/mis-sedes|\/api\/ubicaciones/, ["/api/mis-sedes","/api/ubicaciones","/api/solicitudes"]]
    ];
    groups.forEach(([re,keys])=>{ if(re.test(path)) invalidateApiCache(keys); });
  }

  function invalidateListCache(...keys) {
    keys.flat().filter(Boolean).forEach(key => { delete state.listCache[key]; });
  }

  function invalidateListsForMutation(url) {
    const path = String(url || "").split("?")[0];
    if (/\/api\/ordenes/.test(path)) state.orderListDetailCache?.clear?.();
    const rules = [
      [/\/api\/solicitudes/, ["solicitudes", "ordenes", "cotizaciones", "garantia", "dashboard"]],
      [/\/api\/ordenes/, ["ordenes", "solicitudes", "cotizaciones", "documentos", "garantia", "equipos", "dashboard"]],
      [/\/api\/mis-sedes/, ["sedes", "solicitudes"]],
      [/\/api\/clientes/, ["clientes", "solicitudes", "dashboard"]],
      [/\/api\/personal/, ["personal", "vacaciones", "ordenes", "documentos-laborales", "dashboard"]],
      [/\/api\/documentos-laborales/, ["documentos-laborales", "documentos"]],
      [/\/api\/equipos/, ["equipos", "mantenimientos", "ordenes", "dashboard"]],
      [/\/api\/mantenimientos/, ["mantenimientos", "equipos", "dashboard"]],
      [/\/api\/catalogo-maestro/, ["catalogo", "cotizaciones"]],
      [/\/api\/cotizaciones/, ["cotizaciones", "ordenes", "solicitudes", "documentos", "dashboard"]],
      [/\/api\/documentos/, ["documentos", "dashboard"]],
      [/\/api\/garantias/, ["garantia"]],
      [/\/api\/notificaciones/, ["notificaciones"]],
      [/\/api\/auditoria/, ["auditoria"]],
      [/\/api\/roles|\/api\/usuarios/, ["roles", "usuarios"]],
    ];
    rules.forEach(([re, keys]) => {
      if (!re.test(path)) return;
      invalidateListCache(keys);
      markModulesDirty(keys);
    });
    if(/\/api\/(vacaciones|agenda-operativa|cancelaciones|ordenes|personal|equipos|mantenimientos|clientes|catalogo-maestro)/.test(path)){
      invalidateApiCache(['/api/catalogos','/api/dashboard','/api/vacaciones','/api/produccion','/api/agenda-operativa','/api/personal','/api/ordenes','/api/solicitudes','/api/cancelaciones','/api/notificaciones']);
      invalidateListCache('vacaciones','personal','ordenes','solicitudes','equipos','mantenimientos');state.catalogsUpdatedAt=0;markModulesDirty(['dashboard','vacaciones','personal','agenda','ordenes','solicitudes','produccion','cancelaciones','notificaciones']);
    }
    if(/\/api\/(clientes|personal|usuarios)(?:\/|$)/.test(path)) state.peopleCountsLoadedAt=0;
    invalidateApiCacheForMutation(path);
    if (/^\/api\/(?:ordenes(?:\/\d+(?:\/estado)?$|$)|cotizaciones(?:\/|$)|garantias(?:\/|$))/.test(path)) scheduleModulePending();
  }

  function smartClone(value) { return JSON.parse(JSON.stringify(value)); }
  function smartPrefs(key, defaults = {}) {
    if (!state.smartListDefaults[key]) {
      state.smartListDefaults[key] = {
        q: "", pagina: 1, tamano: 10, filtros: {}, orden: "", direccion: "DESC",
        ...smartClone(defaults),
        filtros: { ...(defaults.filtros || {}) },
      };
    }
    if (!state.smartLists[key]) state.smartLists[key] = smartClone(state.smartListDefaults[key]);
    return state.smartLists[key];
  }

  function resetSmartPrefs(key) {
    state.smartLists[key] = smartClone(state.smartListDefaults[key] || { q:"", pagina:1, tamano:10, filtros:{}, orden:"", direccion:"DESC" });
  }

  function smartText(value) {
    return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  }

  function smartDateValue(value) {
    if (!value) return 0;
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? 0 : d.getTime();
  }

  function smartUnique(items, resolver) {
    return [...new Set(items.map(resolver).filter(v => v !== null && v !== undefined && String(v).trim() !== "").map(v => String(v)))]
      .sort((a,b) => a.localeCompare(b, "es", { sensitivity:"base", numeric:true }));
  }

  function smartWithParams(endpoint, params = {}) {
    const url = new URL(endpoint, location.origin);
    Object.entries(params).forEach(([k,v]) => {
      if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, String(v));
    });
    return `${url.pathname}${url.search}`;
  }

  function listCount(key,name,fallback){return state.listCache[key]?.meta?.resumen?.[name]??fallback;}
  function listFacet(key,name,fallback){return state.listCache[key]?.meta?.facetas?.[name]||fallback;}
  async function loadAllPaged(key, endpoint, force = false, isCurrent = () => true) {
    if(['personal','equipos','mantenimientos','vacaciones'].includes(key)){
      const defaults={personal:{orden:'nombre',direccion:'ASC',filtros:{peopleQuick:'TODOS'}},equipos:{orden:'nombre',direccion:'ASC'},mantenimientos:{orden:'programada',direccion:'DESC'},vacaciones:{orden:'solicitada',direccion:'DESC'}};
      const p=smartPrefs(key,defaults[key]);const d=await api(smartWithParams(endpoint,{q:p.q,pagina:p.pagina,tamano:p.tamano,orden:p.orden==='fallas'?'fallas_abiertas':p.orden,direccion:p.direccion,filtros:JSON.stringify(p.filtros),resumen:1}),force?{seCache:'reload'}:{});
      const result = {items:d.items,meta:d,server:true,loadedAt:Date.now()};
      if (isCurrent()) state.listCache[key] = result;
      return result;
    }
    if (!force && state.listCache[key] && Date.now()-state.listCache[key].loadedAt<30000) return state.listCache[key];
    if (!force && state.listInflight.has(key)) return state.listInflight.get(key);

    const task = (async () => {
      const all = [];
      let page = 1, pages = 1, first = null;
      do {
        const data = await api(smartWithParams(endpoint, { pagina: page, tamano: 100 }), force ? { seCache:"reload" } : {});
        if (!first) first = data;
        all.push(...(data.items || []));
        pages = Math.max(1, Number(data.paginas || 1));
        page += 1;
      } while (page <= pages);
      const result = { items: all, meta: first || {}, paginasOrigen: pages, truncado: false,loadedAt:Date.now() };
      state.listCache[key] = result;
      return result;
    })();

    state.listInflight.set(key, task);
    try { return await task; }
    finally { if (state.listInflight.get(key) === task) state.listInflight.delete(key); }
  }

  function smartListData(key, source, config = {}) {
    const p = smartPrefs(key, config.defaults || {});
    if(state.listCache[key]?.server){const d=state.listCache[key].meta;p.pagina=d.pagina;return {...d,filtered:d.items};}
    let items = [...(source || [])];
    const q = smartText(p.q);
    if (q && config.search) {
      items = items.filter(item => {
        const values = config.search(item) || [];
        return values.some(value => smartText(value).includes(q));
      });
    }
    Object.entries(p.filtros || {}).forEach(([name, selected]) => {
      if (!selected || selected === "TODOS" || selected === "TODAS") return;
      const resolver = config.filters?.[name];
      if (!resolver) return;
      const selectedValues = Array.isArray(selected)
        ? selected.map(value => String(value || "").toUpperCase()).filter(value => value && value !== "TODOS" && value !== "TODAS")
        : [String(selected).toUpperCase()];
      if (!selectedValues.length) return;
      items = items.filter(item => selectedValues.includes(String(resolver(item) ?? "").toUpperCase()));
    });
    const sorter = config.sort?.[p.orden];
    if (sorter) {
      const factor = String(p.direccion || "ASC").toUpperCase() === "DESC" ? -1 : 1;
      items.sort((a,b) => {
        const av = sorter(a), bv = sorter(b);
        if (typeof av === "number" && typeof bv === "number") return (av - bv) * factor;
        return String(av ?? "").localeCompare(String(bv ?? ""), "es", { sensitivity:"base", numeric:true }) * factor;
      });
    }
    const total = items.length;
    const size = Math.max(5, Number(p.tamano || 10));
    const pages = Math.max(1, Math.ceil(total / size));
    p.pagina = Math.min(Math.max(1, Number(p.pagina || 1)), pages);
    const start = (p.pagina - 1) * size;
    return { items: items.slice(start, start + size), filtered: items, total, pagina: p.pagina, tamano: size, paginas: pages };
  }

  function smartOptions(values, selected, allLabel = "Todos") {
    const rows = [["TODOS", allLabel], ...(values || []).map(v => Array.isArray(v) ? v : [String(v), String(v).replaceAll("_", " ")])];
    const normalizedSelected = Array.isArray(selected)
      ? (selected.length === 1 ? String(selected[0]) : "TODOS")
      : String(selected || "TODOS");
    return rows.map(([value,label]) => `<option value="${esc(value)}" ${normalizedSelected===String(value)?"selected":""}>${esc(displayEnumText(label))}</option>`).join("");
  }

  function normalizeSmartQuickValues(value) {
    if (Array.isArray(value)) return [...new Set(value.map(v => String(v || "").toUpperCase()).filter(v => v && v !== "TODOS" && v !== "TODAS"))];
    const single = String(value || "").toUpperCase();
    return single && single !== "TODOS" && single !== "TODAS" ? [single] : [];
  }

  function smartControls(key, config = {}) {
    const p = smartPrefs(key, config.defaults || {});
    const filterDefs = config.filters || [];
    const filters = filterDefs.map(f => `<div class="field"><label>${esc(f.label)}</label><select data-smart-filter="${esc(f.name)}" data-smart-key="${esc(key)}">${smartOptions(f.options || [], p.filtros?.[f.name], f.allLabel || "Todos")}</select></div>`).join("");
    const sorts = (config.sorts || []).length ? `<div class="field"><label>Ordenar por</label><select data-smart-sort data-smart-key="${esc(key)}">${config.sorts.map(([value,label])=>`<option value="${esc(value)}" ${String(p.orden)===String(value)?"selected":""}>${esc(label)}</option>`).join("")}</select></div><div class="field"><label>Dirección</label><select data-smart-direction data-smart-key="${esc(key)}"><option value="DESC" ${p.direccion==="DESC"?"selected":""}>Descendente</option><option value="ASC" ${p.direccion==="ASC"?"selected":""}>Ascendente</option></select></div>` : "";

    const quickDef = config.quick === false ? null : filterDefs.find(f => Array.isArray(f.options) && f.options.length > 0 && f.options.length <= 6);
    let quickMarkup = "";
    if (quickDef) {
      const quickOptions = (quickDef.options || []).map(v => Array.isArray(v) ? v : [String(v), String(v).replaceAll("_", " ")]);
      const selected = normalizeSmartQuickValues(p.filtros?.[quickDef.name]);
      const selectedSet = new Set(selected);
      const allActive = selected.length === 0;
      const pills = [["TODOS","Todos"], ...quickOptions].map(([value,label], index) => {
        const active = value === "TODOS" ? allActive : selectedSet.has(String(value).toUpperCase());
        const tone = index === 0 ? "all" : (index % 4 === 1 ? "blue" : index % 4 === 2 ? "red" : index % 4 === 3 ? "cyan" : "green");
        const visibleLabel = key === "equipos" || key === "garantiaSolicitudes" ? displayEnumText(label) : label;
        return `<button class="smart-quick-pill ${tone} ${active?"active":""}" type="button" data-action="smart-quick-filter" data-list-key="${esc(key)}" data-filter-name="${esc(quickDef.name)}" data-value="${esc(value)}"><span>${esc(visibleLabel)}</span></button>`;
      }).join("");
      const chips = selected.map(value => {
        const row = quickOptions.find(([optionValue]) => String(optionValue).toUpperCase() === value);
        const rawLabel = row ? row[1] : value.replaceAll("_", " ");
        const label = key === "equipos" || key === "garantiaSolicitudes" ? displayEnumText(rawLabel) : rawLabel;
        return `<button class="smart-quick-active" type="button" data-action="smart-quick-filter" data-list-key="${esc(key)}" data-filter-name="${esc(quickDef.name)}" data-value="${esc(value)}" aria-label="Quitar filtro ${esc(label)}"><span>${esc(label)}</span><i data-lucide="x"></i></button>`;
      }).join("");
      quickMarkup = `<div class="smart-quick-area"><div class="smart-quick-row"><span class="smart-quick-label">Filtros rápidos:</span><div class="smart-quick-pills">${pills}</div><span class="smart-quick-hint">Puedes combinar varios.</span></div>${chips?`<div class="smart-quick-active-row"><span>${selected.length} filtro${selected.length===1?"":"s"} activo${selected.length===1?"":"s"}</span><div>${chips}</div></div>`:""}</div>`;
    }

    return `<div class="smart-filter-shell"><div class="smart-list-tools">
      <div class="field smart-list-search"><label>Buscar</label><div class="input-with-icon"><i data-lucide="search"></i><input type="search" data-smart-q="${esc(key)}" value="${esc(p.q)}" placeholder="${esc(config.placeholder || "Buscar registros...")}" autocomplete="off"></div></div>
      ${filters}${sorts}
      <div class="field smart-list-size"><label>Por página</label><select data-smart-size data-smart-key="${esc(key)}">${[5,10,20,50].map(n=>`<option value="${n}" ${Number(p.tamano)===n?"selected":""}>${n}</option>`).join("")}</select></div>
      <div class="smart-list-clear"><button class="btn" type="button" data-action="smart-reset" data-list-key="${esc(key)}"><i data-lucide="rotate-ccw"></i> Limpiar</button></div>
    </div>${quickMarkup}</div>`;
  }

  function smartPager(key, meta) {
    const page = Number(meta.pagina || 1), pages = Math.max(1, Number(meta.paginas || 1)), total = Number(meta.total || 0), size = Number(meta.tamano || 10);
    const start = total ? (page - 1) * size + 1 : 0, end = Math.min(total, page * size);
    const nums = [];
    for (let n = Math.max(1, page - 2); n <= Math.min(pages, page + 2); n++) nums.push(n);
    return `<div class="smart-pagination"><div class="smart-pagination-copy">Mostrando <strong>${start}-${end}</strong> de <strong>${total}</strong></div><div class="pager-buttons">
      <button type="button" class="pager-button" data-action="smart-page" data-list-key="${esc(key)}" data-page="1" ${page<=1?"disabled":""} aria-label="Primera página"><i data-lucide="chevrons-left"></i></button>
      <button type="button" class="pager-button" data-action="smart-page" data-list-key="${esc(key)}" data-page="${page-1}" ${page<=1?"disabled":""} aria-label="Página anterior"><i data-lucide="chevron-left"></i></button>
      ${nums.map(n=>`<button type="button" class="pager-button ${n===page?"active":""}" data-action="smart-page" data-list-key="${esc(key)}" data-page="${n}">${n}</button>`).join("")}
      <button type="button" class="pager-button" data-action="smart-page" data-list-key="${esc(key)}" data-page="${page+1}" ${page>=pages?"disabled":""} aria-label="Página siguiente"><i data-lucide="chevron-right"></i></button>
      <button type="button" class="pager-button" data-action="smart-page" data-list-key="${esc(key)}" data-page="${pages}" ${page>=pages?"disabled":""} aria-label="Última página"><i data-lucide="chevrons-right"></i></button>
    </div></div>`;
  }

  function smartResultsMeta(result, label = "registros") {
    return `<div class="smart-results-meta"><span><strong>${normalizeNumber(result.total)}</strong> ${esc(label)}</span><span>Página <strong>${normalizeNumber(result.pagina)}</strong> de <strong>${normalizeNumber(result.paginas)}</strong></span></div>`;
  }

  const filterSearchSelector = '#userReportFilters [name="q"], [data-smart-q], [data-audit-filter]';

  function filterFocus() {
    const input = document.activeElement;
    if (!content.contains(input) || !input.matches(filterSearchSelector)) return null;
    const selector = input.dataset.auditFilter
      ? `[data-audit-filter="${input.dataset.auditFilter}"]`
      : input.dataset.smartQ ? `[data-smart-q="${input.dataset.smartQ}"]` : '#userReportFilters [name="q"]';
    return {selector, start: input.selectionStart, end: input.selectionEnd, direction: input.selectionDirection};
  }

  function restoreFilterFocus(focus) {
    if (!focus) return;
    const input = content.querySelector(focus.selector);
    if (!input) return;
    input.focus({preventScroll:true});
    if (focus.start !== null) input.setSelectionRange(focus.start, focus.end, focus.direction);
  }

  async function refreshFilteredView(render, revision, module) {
    let focus = null;
    let mobilePanelId = null;
    let mobileScroll = 0;
    const isCurrent = () => {
      if (revision !== filterRevision || module !== state.current) return false;
      focus = filterFocus();
      const panel = content.querySelector(".mobile-filter-panel.is-open");
      mobilePanelId = panel?.id;
      mobileScroll = panel?.scrollTop || 0;
      return true;
    };
    try {
      if (!isCurrent()) return;
      await render(isCurrent);
      if (revision !== filterRevision || module !== state.current) return;
      renderRoleModuleHero();
      decorateModuleHeader();
      enhanceRenderedContent();
      saveViewSnapshot(module);
      if (mobilePanelId) {
        const panel = document.getElementById(mobilePanelId);
        if (panel) {
          openMobileFilters(panel, false);
          panel.scrollTop = mobileScroll;
        } else {
          closeMobileFilters();
        }
      }
      restoreFilterFocus(focus);
    } catch (error) {
      if (revision === filterRevision && module === state.current) throw error;
    }
  }

  async function rerenderSmartList(key, revision = ++filterRevision) {
    const map = {
      solicitudes: renderSolicitudes, ordenes: renderOrdenes, sedes: renderMisSedes, clientes: renderClientes,
      personal: renderPersonal, equipos: renderEquipos, mantenimientos: renderMantenimientos, vacaciones: renderVacaciones,
      catalogo: renderCatalogoMaestro, cotizaciones: renderCotizaciones, documentos: renderDocumentos, "expediente-unico": renderDocumentos,
      notificaciones: renderNotificaciones, auditoria: renderAuditoria, garantia: renderGarantia, garantiaSolicitudes: renderGarantia,
    };
    const render = map[key];
    if (!render) return;
    const module = state.current;
    try { await verifyLiveBackend(); }
    catch (error) {
      if (revision === filterRevision && module === state.current) showUnavailableModule(module, error);
      return;
    }
    await refreshFilteredView(render, revision, module);
  }

  function closeTopPopovers(except = null) {
    [[notificationPopover, notificationButton], [userPopover, userMenuButton]].forEach(([popover, trigger]) => {
      if (!popover || popover === except) return;
      popover.hidden = true;
      trigger?.setAttribute("aria-expanded", "false");
    });
  }

  function notificationIcon(type) {
    const value = String(type || "").toUpperCase();
    if (/SEGURIDAD/.test(value)) return "shield-check";
    if (/COTIZ/.test(value)) return "receipt-text";
    if (/CAMBIO|ALCANCE/.test(value)) return "route";
    if (/ASIGN/.test(value)) return "hard-hat";
    if (/SOLICIT/.test(value)) return "inbox";
    if (/ESTADO|ORDEN|CONFIRM/.test(value)) return "clipboard-check";
    return "bell-ring";
  }

  function notificationReadableText(value) {
    const acronyms = new Set(["SEPRIGUA", "OT", "OC", "CAU", "NIT", "PDF", "ID", "SAT", "URL", "SMS", "API"]);
    return String(value ?? "").replace(/_/g, " ").replace(/\s+/g, " ").trim().replace(/[\p{Lu}]{2,}/gu, word =>
      acronyms.has(word) ? word : word.charAt(0) + word.slice(1).toLocaleLowerCase("es"));
  }

  function resetNotificationViews() {
    invalidateApiCache(["/api/notificaciones"]);
    invalidateListCache("notificaciones");
    markModulesDirty("notificaciones");
  }

  const cancellationNoticeStates = new Map();
  let cancellationNoticeCheckedAt = 0;
  let cancellationNoticeSync = null;
  function isPendingCancellationNotice(item) {
    if (String(item.entidad || "").toLowerCase() !== "cancelacion" || !item.entidad_id) return false;
    const type = String(item.tipo || "").toUpperCase();
    if (/APROB|RECHAZ|RESUELT|DECISION/.test(type)) return false;
    return /CANCELA.*(SOLICIT|PENDIENT|REVIS)/.test(type) || /solicitud de cancelaci[oó]n|cancelaci[oó]n pendiente|se tiene que cancelar/i.test(`${item.titulo || ""} ${item.mensaje || ""}`);
  }
  async function syncCancellationNotifications(items = []) {
    const related = items.filter(isPendingCancellationNotice);
    if (!related.length) return false;
    if (!cancellationNoticeSync && Date.now() - cancellationNoticeCheckedAt > 30000) {
      cancellationNoticeSync = (async () => {
        const statuses = new Map();
        let page = 1, pages = 1;
        do {
          const data = await api(`/api/cancelaciones?${new URLSearchParams({pagina:page,tamano:100,estado:""})}`, {seCache:"reload"});
          (data.items || []).forEach(item => statuses.set(String(item.id), String(item.estado || "").toUpperCase()));
          pages = Math.max(1, Number(data.paginas || 1));
          page++;
        } while (page <= pages);
        cancellationNoticeStates.clear();
        statuses.forEach((status, id) => cancellationNoticeStates.set(id, status));
        cancellationNoticeCheckedAt = Date.now();
      })().finally(() => { cancellationNoticeSync = null; });
    }
    try { if (cancellationNoticeSync) await cancellationNoticeSync; } catch (_) { return false; }
    const resolved = related.filter(item => ["APROBADA", "RECHAZADA"].includes(cancellationNoticeStates.get(String(item.entidad_id))));
    resolved.forEach(item => { item.estado_cancelacion = cancellationNoticeStates.get(String(item.entidad_id)); });
    const unread = resolved.filter(item => !item.leida);
    if (!unread.length) return false;
    const results = await Promise.allSettled(unread.map(item => api(`/api/notificaciones/${encodeURIComponent(item.id)}/leer`, {method:"POST",body:{}})));
    let changed = false;
    results.forEach((result, index) => { if (result.status === "fulfilled") { unread[index].leida = true; changed = true; } });
    if (changed) resetNotificationViews();
    return changed;
  }
  function notificationDisplay(item) {
    const status = item.estado_cancelacion || cancellationNoticeStates.get(String(item.entidad_id));
    if (isPendingCancellationNotice(item) && status === "APROBADA")
      return {title:"Cancelación aprobada", message:"Esta solicitud de cancelación ya fue aprobada."};
    if (isPendingCancellationNotice(item) && status === "RECHAZADA")
      return {title:"Cancelación rechazada", message:"Esta solicitud de cancelación ya fue rechazada. Consulta la resolución en Cancelaciones."};
    return {title:notificationReadableText(item.titulo), message:notificationReadableText(item.mensaje)};
  }

  const soundToggle = $(".notice-sound-toggle");
  let notificationAudioContext = null;
  let notificationSoundInitialized = false;
  const notificationKnownIds = new Set();
  let notificationSoundPendingUntil = 0;
  let notificationSoundEnabled = true;
  try { notificationSoundEnabled = localStorage.getItem("seprigua_notification_sound") !== "off"; } catch (_) {}
  function updateNotificationSoundToggle() {
    if (!soundToggle) return;
    soundToggle.setAttribute("aria-pressed", String(notificationSoundEnabled));
    soundToggle.setAttribute("aria-label", notificationSoundEnabled ? "Desactivar sonido de notificaciones" : "Activar sonido de notificaciones");
    soundToggle.title = notificationSoundEnabled ? "Desactivar sonido" : "Activar sonido";
    soundToggle.innerHTML = `<i data-lucide="${notificationSoundEnabled ? "volume-2" : "volume-x"}"></i>`;
    window.lucide?.createIcons();
  }
  async function unlockNotificationAudio() {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext || !notificationSoundEnabled) return;
    try {
      notificationAudioContext ||= new AudioContext();
      if (notificationAudioContext.state !== "running") await notificationAudioContext.resume();
      if (notificationSoundPendingUntil) {
        const stillPending = Date.now() < notificationSoundPendingUntil;
        notificationSoundPendingUntil = 0;
        if (stillPending && notificationAudioContext.state === "running") playNotificationSound();
      }
    } catch (_) {}
  }
  document.addEventListener("pointerdown", unlockNotificationAudio);
  document.addEventListener("keydown", unlockNotificationAudio);
  function playNotificationSound() {
    if (!notificationSoundEnabled) return;
    if (!notificationAudioContext || notificationAudioContext.state !== "running") {
      notificationSoundPendingUntil = Date.now() + 30000;
      unlockNotificationAudio();
      return;
    }
    try {
      const now = notificationAudioContext.currentTime;
      [660, 880, 1100].forEach((frequency, index) => {
        const oscillator = notificationAudioContext.createOscillator();
        const gain = notificationAudioContext.createGain();
        const start = now + index * .105;
        oscillator.type = "sine";
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(.0001, start);
        gain.gain.exponentialRampToValueAtTime(.12, start + .018);
        gain.gain.exponentialRampToValueAtTime(.0001, start + .17);
        oscillator.connect(gain).connect(notificationAudioContext.destination);
        oscillator.start(start);
        oscillator.stop(start + .18);
      });
    } catch (_) {}
  }

  function notificationTargetLabel(entity) {
    const value = String(entity || "").toLowerCase();
    if (value === "ordentrabajo") return "Abrir OT";
    if (value === "solicitudservicio") return "Abrir solicitud";
    if (value === "cotizacion") return "Ir a cotización";
    if (value === "cambioalcance") return "Ir a órdenes";
    return "Ver detalle";
  }

  function notificationTargetButton(item, compact = false) {
    if (!item?.entidad_id && !item?.entidad) return "";
    return `<button class="btn small ${compact ? "ghost" : ""}" type="button" data-action="abrir-notificacion" data-id="${esc(item.id)}" data-entity="${esc(item.entidad || "")}" data-entity-id="${esc(item.entidad_id || "")}">${esc(notificationTargetLabel(item.entidad))}</button>`;
  }

  function renderNotificationPreview(items = []) {
    if (!notificationPreview) return;
    if (!items.length) {
      notificationPreview.innerHTML = `<div class="popover-empty"><i data-lucide="bell-off"></i><strong>Sin notificaciones</strong><span>No tienes avisos pendientes.</span></div>`;
      window.lucide?.createIcons(); return;
    }
    notificationPreview.innerHTML = items.map(x => { const display = notificationDisplay(x); return `
      <article class="preview-notification ${x.leida ? "read" : "unread"}">
        <span class="notification-symbol"><i data-lucide="${notificationIcon(x.tipo)}"></i></span>
        <div class="preview-notification-copy"><strong>${esc(display.title)}</strong><p>${esc(display.message)}</p><div class="notification-preview-meta"><time>${fmt(x.creada)}</time><span class="notice-read-state ${x.leida ? "is-read" : "is-unread"}">${x.leida ? "Leída" : "Sin leer"}</span></div></div>
        <div class="preview-notification-actions">${x.entidad ? `<button class="mini-open" type="button" data-action="abrir-notificacion" data-id="${esc(x.id)}" data-entity="${esc(x.entidad||"")}" data-entity-id="${esc(x.entidad_id||"")}" aria-label="Abrir notificación" title="Abrir detalle"><i data-lucide="arrow-up-right"></i></button>` : ""}${!x.leida ? `<button class="mini-read" type="button" data-action="leer-notificacion" data-id="${esc(x.id)}" aria-label="Marcar como leída" title="Marcar como leída"><i data-lucide="check"></i></button>` : ""}</div>
      </article>`; }).join("");
    window.lucide?.createIcons();
  }

  const NOTIFICATION_REMIND_MS = 20 * 60 * 1000;
  let notificationsVisitedAt = 0;
  let notificationActiveMs = 0;
  let notificationLastTick = Date.now();
  function acknowledgeNotificationsView() {
    notificationsVisitedAt = Date.now();
    notificationActiveMs = 0;
    notificationLastTick = Date.now();
    notificationButton?.classList.remove("se-notification-attention");
    notificationButton?.setAttribute("title","Avisos revisados. Se recordarán en 20 minutos si permanecen sin leer.");
  }
  function refreshNotificationAttention() {
    const now = Date.now();
    if (notificationsVisitedAt && document.visibilityState === "visible" && document.hasFocus()) {
      notificationActiveMs += Math.min(60000, Math.max(0, now - notificationLastTick));
    }
    notificationLastTick = now;
    const pending = state.unreadNotifications > 0;
    const cooling = notificationsVisitedAt && notificationActiveMs < NOTIFICATION_REMIND_MS;
    const animate = pending && !cooling;
    notificationButton?.classList.toggle("se-notification-attention", Boolean(animate));
    if (notificationButton) notificationButton.title = animate ? "Tienes notificaciones pendientes" : pending ? "Notificaciones pendientes revisadas" : "No tienes avisos sin leer";
  }
  async function refreshNotificationBadge(loadPreview = false) {
    let d = await api("/api/notificaciones/resumen", {seCache:"reload"});
    if (await syncCancellationNotifications(d.items || [])) d = await api("/api/notificaciones/resumen", {seCache:"reload"});
    const unread = normalizeNumber(d.no_leidas);
    const items = Array.isArray(d.items) ? d.items : [];
    const hasNewUnread = notificationSoundInitialized && (unread > state.unreadNotifications ||
      items.some(item => !item.leida && item.id != null && !notificationKnownIds.has(String(item.id))));
    items.forEach(item => { if (item.id != null) notificationKnownIds.add(String(item.id)); });
    notificationSoundInitialized = true;
    state.unreadNotifications = unread;
    if (hasNewUnread) playNotificationSound();
    if (hasNewUnread && notificationsVisitedAt) notificationsVisitedAt = 0;
    if (notificationDot) notificationDot.hidden = unread < 1;
    if (notificationCount) {
      notificationCount.hidden = unread < 1;
      notificationCount.textContent = unread > 99 ? "99+" : String(unread);
    }
    refreshNotificationAttention();
    if (state.role) renderNav();
    if (loadPreview || (notificationPopover && !notificationPopover.hidden)) renderNotificationPreview(d.items || []);
    return d;
  }
  function refreshCancellationNotifications() {
    cancellationNoticeCheckedAt = 0;
    resetNotificationViews();
    refreshNotificationBadge(!notificationPopover?.hidden).catch(() => {});
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && state.role) refreshNotificationBadge(!notificationPopover?.hidden).catch(() => {});
  });

  async function openNotificationTarget(entity, entityId, notificationId = null) {
    if (notificationId) {
      try { await api(`/api/notificaciones/${notificationId}/leer`, { method: "POST", body: {} }); resetNotificationViews(); } catch (_) {}
      refreshNotificationBadge().catch(()=>{});
    }
    closeTopPopovers();
    const kind = String(entity || "").toLowerCase();
    if (kind === "ordentrabajo" && entityId) return openOrder(entityId, "resumen", true);
    if (kind === "solicitudservicio" && entityId && state.role !== "TECNICO") return openRequest(entityId);
    if (kind === "cotizacion") {await navigate("cotizaciones",{force:true});return entityId?state.role==="CLIENTE"?openClientQuoteFlow(entityId):portalUI.handle("detalle-cotizacion",entityId):undefined;}
    if (kind === "cambioalcance") return navigate("ordenes");
    if (kind === "vacaciones") {await navigate("vacaciones",{force:true});if(entityId)return portalUI.handle("detalle-vacacion",entityId);return;}
    if (kind === "cancelacion") return navigate("cancelaciones",{force:true});
    if (kind === "equipo") {if(entityId)return portalUI.handle("detalle-equipo",entityId);return navigate("equipos",{force:true});}
    if (kind === "mantenimientoequipo") {if(entityId)return portalUI.handle("detalle-mantenimiento",entityId);return navigate("mantenimientos",{force:true});}
    if (kind === "agendaoperativa") return navigate("agenda",{force:true});
    if (kind === "usuario") return navigate("cuenta",{force:true});
    return navigate("notificaciones");
  }

  async function performLogout() {
    try { await api("/api/auth/logout", { method: "POST", body: {} }); } catch (_) {}
    location.replace("/login");
  }

  // Zoom y tablet comparten el rail fijo; teléfonos estrechos usan drawer.
  // El control del navbar permanece fijo; el sidebar no se re-renderiza.
  const sidebarDrawerQuery = window.matchMedia("(max-width: 1120px)");
  const sidebarRailQuery = window.matchMedia("(min-width: 651px) and (max-width: 1120px)");
  // Al aplicar zoom, los items cambian de altura: no dejar el activo recortado
  // en la parte superior/inferior del nav. Solo se desplaza el menú interno.
  function keepActiveSidebarEntryVisible() {
    const navScroll = sidebar?.querySelector(".system-nav");
    const active = navScroll?.querySelector(".nav-button.active");
    if (!active || !navScroll) return;
    // No desplazar automáticamente los iconos del rail minimizado.
    if (document.body.classList.contains("sidebar-collapsed") && !sidebar?.classList.contains("open")) return;
    const bounds = navScroll.getBoundingClientRect();
    const chosen = active.getBoundingClientRect();
    if (chosen.top < bounds.top + 4) navScroll.scrollTop -= bounds.top + 8 - chosen.top;
    else if (chosen.bottom > bounds.bottom - 4) navScroll.scrollTop += chosen.bottom - bounds.bottom + 8;
  }
  function setSidebarOpen(open){
    const show = sidebarDrawerQuery.matches && Boolean(open);
    sidebar?.classList.toggle("open", show);
    if (sidebarScrim) {
      sidebarScrim.hidden = !show;
      sidebarScrim.classList.toggle("show", show);
    }
    menuButton?.setAttribute("aria-expanded", String(show));
    menuButton?.setAttribute("aria-label", show ? "Cerrar menú" : "Abrir menú");
    menuButton?.setAttribute("title", show ? "Cerrar menú de navegación" : "Abrir menú de navegación");
    document.body.classList.toggle("sidebar-mobile-open", show);
    // Al minimizar el rail, sus iconos empiezan arriba: sin scroll residual.
    if (!show && sidebarRailQuery.matches) sidebar?.querySelector(".system-nav")?.scrollTo({top: 0, behavior: "instant"});
    if (show) {
      // Un menú desplegado empieza desde OPERACIÓN, no a mitad del listado.
      // El rail compacto conserva su scroll al cerrarse cuando corresponda.
      sidebar?.querySelector(".system-nav")?.scrollTo({ top: 0, behavior: "instant" });
    }
    if (sidebarRailQuery.matches && sidebarCollapseButton) {
      sidebarCollapseButton.setAttribute("aria-label", show ? "Cerrar menú" : "Mostrar menú");
      sidebarCollapseButton.setAttribute("title", show ? "Cerrar menú" : "Mostrar menú");
    }
  }

  function applySidebarPreference(){
    // Al pasar de tablet a escritorio nunca se debe quedar el scrim visible.
    setSidebarOpen(false);
    if (sidebarDrawerQuery.matches){
      // Tablet y zoom: mini sidebar SIEMPRE visible (referencia universidad).
      // Solo teléfonos estrechos muestran el menú completamente oculto.
      const isRail = sidebarRailQuery.matches;
      document.body.classList.toggle("sidebar-collapsed", isRail);
      if (sidebarCollapseButton) {
        sidebarCollapseButton.innerHTML = `<i data-lucide="${isRail ? "panel-left-open" : "panel-left-close"}"></i>`;
        sidebarCollapseButton.title = isRail ? "Mostrar menú" : "Cerrar menú";
        sidebarCollapseButton.setAttribute("aria-label", sidebarCollapseButton.title);
      }
      window.lucide?.createIcons();
      return;
    }
    const collapsed = localStorage.getItem("seprigua_sidebar_collapsed") === "1";
    document.body.classList.toggle("sidebar-collapsed", collapsed);
    if (collapsed) sidebar?.querySelector(".system-nav")?.scrollTo({top: 0, behavior: "instant"});
    if (sidebarCollapseButton){
      sidebarCollapseButton.innerHTML = `<i data-lucide="${collapsed?"panel-left-open":"panel-left-close"}"></i>`;
      sidebarCollapseButton.title = collapsed ? "Mostrar menú" : "Ocultar menú";
      sidebarCollapseButton.setAttribute("aria-label", sidebarCollapseButton.title);
    }
    window.lucide?.createIcons();
  }

  function toggleDesktopSidebar(){
    if (sidebarDrawerQuery.matches) return setSidebarOpen(!sidebar?.classList.contains("open"));
    const collapsed = !document.body.classList.contains("sidebar-collapsed");
    document.body.classList.toggle("sidebar-collapsed", collapsed);
    localStorage.setItem("seprigua_sidebar_collapsed", collapsed ? "1" : "0");
    applySidebarPreference();
  }

  async function init() {
    if (init.started) return;
    init.started = true;
    syncPopoverPortal();
    applySidebarPreference();
    try {
      const me = await api("/api/auth/me");
      state.user = me.user;
      window.SEPRIGUACursors?.setUser(me.user);
      state.role = String(me.user.rol || "").toUpperCase();
      state.roleName = String(me.user.rol_nombre || me.user.rol || "").toUpperCase();
      state.isMasterCoordinator = state.roleName === "COORDINADOR";
      state.allowedModules = new Set(Array.isArray(me.user.modulos) ? me.user.modulos : []);
      document.body.dataset.role = state.role.toLowerCase();
      document.body.dataset.roleName = state.roleName.toLowerCase().replaceAll(" ","-");
      const expected = rolePaths[state.role]; if (!expected) return location.replace("/login");
      // Todas las rutas de rol sirven la misma interfaz. Ajustar la URL con History API evita
      // una recarga completa adicional al entrar y elimina el salto visual al panel inicial.
      if (location.pathname !== expected) history.replaceState(null, "", expected + location.search);
      roleChip.textContent = displayEnumText(state.roleName || state.role);
      syncPrototypeChrome();
      renderNav();
      const [cats, health] = await Promise.all([api("/api/catalogos"), api("/api/db/health")]);
      state.catalogs = cats;state.catalogsUpdatedAt=Date.now();
      dbBadgeText.textContent = health.system_migration ? "Sistema conectado" : "Configuración pendiente";
      dbBadge.classList.toggle("error", !health.system_migration);
      refreshNotificationBadge().catch(()=>{});
      refreshModulePending();
      clearInterval(init.notificationTimer);
      init.notificationTimer = setInterval(()=>{if(document.hidden)return;refreshNotificationBadge().catch(()=>{});refreshNotificationAttention();refreshModulePending();}, window.SEPRIGUA_LIGHT_MODE ? 30000 : 15000);
      const key = `seprigua_modulo_${state.roleName || state.role}`;
      const saved = sessionStorage.getItem(key);
      const valid = new Set((modules[state.role] || []).filter(([module])=>moduleAllowed(module)).map(([module]) => module));
      await navigate(saved && valid.has(saved) ? saved : firstAllowedModule());
      document.body.classList.remove("ui-booting");
      clearInterval(init.healthTimer);
      init.healthTimer = window.setInterval(() => {
        if (document.hidden || !state.role) return;
        verifyLiveBackend().then(() => {
          if (content.dataset.offline === "1") navigate(state.current, { force: true }).catch(() => {});
        }).catch(error => showUnavailableModule(state.current, error));
      }, window.SEPRIGUA_LIGHT_MODE ? 60000 : 30000);
      initializePushSilently();
      await handlePushDeepLink();
    } catch (e) {
      document.body.classList.remove("ui-booting");
      dbBadge.classList.add("error"); dbBadgeText.textContent = "Sin conexión";
      content.innerHTML = `<div class="empty-state"><h3>No se pudo iniciar el sistema</h3><p>${esc(e.message)}</p><p>Comprueba el backend y la configuración del sistema.</p></div>`;
    }
  }
  const sidebarNavigationGroups = {
    COORDINADOR: {
      dashboard: "OPERACIÓN",
      solicitudes: "OPERACIÓN",
      ordenes: "OPERACIÓN",
      agenda: "OPERACIÓN",
      cotizaciones_comercial: "OPERACIÓN",
      personas: "GESTIÓN",
      equipo_mantenimiento: "GESTIÓN",
      documentos: "GESTIÓN",
      garantia: "GESTIÓN",
      notificaciones: "SISTEMA",
      roles: "SISTEMA",
      auditoria: "SISTEMA",
      cuenta: "CUENTA"
    },
    TECNICO: {
      dashboard: "OPERACIÓN",
      ordenes: "OPERACIÓN",
      agenda: "OPERACIÓN",
      equipo_mantenimiento: "GESTIÓN",
      vacaciones: "GESTIÓN",
      documentos: "GESTIÓN",
      notificaciones: "SISTEMA",
      cuenta: "CUENTA"
    },
    CLIENTE: {
      dashboard: "OPERACIÓN",
      solicitudes: "OPERACIÓN",
      sedes: "GESTIÓN",
      ordenes: "OPERACIÓN",
      cotizaciones: "OPERACIÓN",
      documentos: "GESTIÓN",
      garantia: "GESTIÓN",
      notificaciones: "SISTEMA",
      cuenta: "CUENTA"
    }
  };

  function sidebarGroupForModule(module) {
    return sidebarNavigationGroups[state.role]?.[module] || "";
  }

  const modulePending = Object.create(null);
  let pendingRefreshTimer, pendingUpdatedAt = -Infinity, pendingRevision = 0;
  function scheduleModulePending() {
    ++pendingRevision;
    pendingUpdatedAt = -Infinity;
    clearTimeout(pendingRefreshTimer);
    pendingRefreshTimer = setTimeout(refreshModulePending, 350);
  }
  async function refreshModulePending() {
    if (!state.role || Date.now()-pendingUpdatedAt < 90000) return;
    pendingUpdatedAt = Date.now();
    const revision = ++pendingRevision;
    const count = async (module, filters) => normalizeNumber((await api(`/api/${module}?tamano=1&${filters}`, {seCache:"reload"})).total);
    const byState = (module, code) => count(module, "estado="+encodeURIComponent(code));
    const coord = state.role === "COORDINADOR", tech = state.role === "TECNICO";
    const tasks = [];
    if (moduleAllowed("ordenes") && (coord || tech)) {
      const states = coord ? ["PENDIENTE","POR_CONFIRMAR"] : ["PENDIENTE","PROGRAMADA","EN_PROCESO","POR_CONFIRMAR"];
      tasks.push(["ordenes", Promise.all(states.map(code=>byState("ordenes", code))).then(results=>results.reduce((a,b)=>a+b,0))]);
    }
    if (moduleAllowed("cotizaciones") && !tech) {
      const states = coord ? ["BORRADOR","OBSERVADA","CONFIRMADA"] : ["ENVIADA"];
      tasks.push(["cotizaciones", count("cotizaciones","filtros="+encodeURIComponent(JSON.stringify({estado:states})))]);
      if (coord) tasks.push(["ordenes_sin_cotizar", count("cotizaciones/ordenes-pendientes","")]);
    }
    if (coord && moduleAllowed("garantia")) {
      tasks.push(["garantia", api("/api/garantias", {seCache:"reload"}).then(data=>warrantyPendingTotal(data.resumen))]);
    }
    const results = await Promise.allSettled(tasks.map(([,task])=>task));
    if (revision !== pendingRevision) return;
    results.forEach((result,index)=>{if(result.status==="fulfilled") modulePending[tasks[index][0]]=result.value;});
    renderNav();
  }
  function warrantyPendingTotal(summary={}) {
    return normalizeNumber(summary.pendientes_configurar)+normalizeNumber(summary.solicitudes_pendientes);
  }
  function navCount(key) {
    if (key==="notificaciones") return state.unreadNotifications;
    if (key==="cotizaciones_comercial"||key==="cotizaciones") return (modulePending.cotizaciones||0)+(modulePending.ordenes_sin_cotizar||0);
    return modulePending[key]||0;
  }
  function navCountText(key, count) {
    if (key==="notificaciones") return `${count} sin leer`;
    if ((key==="cotizaciones_comercial"||key==="cotizaciones") && state.role==="COORDINADOR" && modulePending.ordenes_sin_cotizar) {
      return `${count} pendientes · ${modulePending.ordenes_sin_cotizar} OT por cotizar`;
    }
    return `${count} ${count===1?"pendiente":"pendientes"}`;
  }

  function renderNav() {
    const items = navigationEntries();
    const buttons = [...nav.querySelectorAll(":scope > .nav-button")];

    // Mantener nodos estables evita el parpadeo de Lucide y la sensación
    // de que el sidebar "recarga" en cada módulo.
    const structureMatches =
      buttons.length === items.length &&
      buttons.every((button, index) => button.dataset.module === items[index]?.[0]);

    if (!structureMatches) {
      let lastGroup = "";

      nav.innerHTML = items.map(([key, icon, name]) => {
        const group = groupByKey(key);
        const active = key === state.current || Boolean(group?.[1].members.some(([member]) => member === state.current));
        const displayName = key === "dashboard" ? "Centro de control" : name;
        const total = navCount(key);
        const label = total ? `${displayName} · ${navCountText(key,total)}` : displayName;
        const count = total ? `<b class="nav-notification-count" aria-hidden="true">${total>99?"99+":total}</b>` : "";

        const sidebarGroup = sidebarGroupForModule(key);
        const groupTitle = sidebarGroup && sidebarGroup !== lastGroup
          ? `<span class="nav-group-title" data-nav-group="${esc(sidebarGroup)}">${esc(({"OPERACIÓN":"Operación","GESTIÓN":"Gestión","SISTEMA":"Sistema","CUENTA":"Cuenta"})[sidebarGroup] || sidebarGroup)}</span>`
          : "";

        if (sidebarGroup) lastGroup = sidebarGroup;

        return `${groupTitle}<button class="nav-button ${active ? "active" : ""}" type="button" data-module="${key}" title="${esc(label)}" aria-label="${esc(label)}"><i data-lucide="${icon}"></i><span>${esc(displayName)}</span>${count}</button>`;
      }).join("");

      // Lucide se ejecuta únicamente cuando la estructura se crea de verdad.
      window.lucide?.createIcons();
      return;
    }

    items.forEach(([key, _icon, name], index) => {
      const button = buttons[index];
      if (!button) return;

      const group = groupByKey(key);
      const active = key === state.current || Boolean(group?.[1].members.some(([member]) => member === state.current));
      const displayName = key === "dashboard" ? "Centro de control" : name;

      button.classList.toggle("active", active);

      const total = navCount(key);
      const accessibleName = total ? `${displayName} · ${navCountText(key,total)}` : displayName;
      if (button.title !== accessibleName) button.title = accessibleName;
      if (button.getAttribute("aria-label") !== accessibleName) button.setAttribute("aria-label", accessibleName);

      const label = button.querySelector("span");
      if (label && label.textContent !== displayName) label.textContent = displayName;

      const shouldShowCount = total > 0;
      let count = button.querySelector(".nav-notification-count");

      if (shouldShowCount) {
        const value = total > 99 ? "99+" : String(total);
        if (!count) {
          count = document.createElement("b");
          count.className = "nav-notification-count";
          count.setAttribute("aria-hidden","true");
          button.appendChild(count);
        }
        if (count.textContent !== value) count.textContent = value;
      } else if (count) {
        count.remove();
      }
    });

    // El ZIP de Gabi tenía menos módulos. Con los módulos nuevos, el menú puede
    // necesitar scroll; mantenemos siempre visible el activo sin mover la hoja.
    requestAnimationFrame(() => {
      // El rail minimizado distribuye todos los iconos sin scroll.
      // No forzar scrollIntoView: podía desplazar el menú ocultando otros accesos.
      if (document.body.classList.contains("sidebar-collapsed") && !sidebar?.classList.contains("open")) {
        if (nav.scrollTop !== 0) nav.scrollTop = 0;
        return;
      }
      nav.querySelector(".nav-button.active")?.scrollIntoView?.({ block: "nearest", inline: "nearest" });
    });
  }
  function ensureMobileFilterScrim() {
    let scrim=document.getElementById("mobileFilterScrim");
    if(!scrim){
      scrim=document.createElement("button");
      scrim.type="button";
      scrim.id="mobileFilterScrim";
      scrim.className="mobile-filter-scrim";
      scrim.setAttribute("aria-label","Cerrar filtros");
      scrim.addEventListener("click", closeMobileFilters);
      document.body.appendChild(scrim);
    }
    return scrim;
  }

  function closeMobileFilters() {
    document.querySelectorAll(".mobile-filter-panel.is-open").forEach(panel=>panel.classList.remove("is-open"));
    document.getElementById("mobileFilterScrim")?.classList.remove("is-open");
    document.body.classList.remove("mobile-filters-open");
  }

  function openMobileFilters(panel, focusInput = true) {
    if(!panel) return;
    closeMobileFilters();
    panel.classList.add("is-open");
    ensureMobileFilterScrim().classList.add("is-open");
    document.body.classList.add("mobile-filters-open");
    if (focusInput) panel.querySelector("input,select,button:not(.mobile-filter-close)")?.focus?.({preventScroll:true});
  }

  function enhanceResponsiveTables(root=content) {
    const selector="table.request-table,table.orders-table,table.order-table,table.quote-table,table.people-table,table.data-table,table.user-report-table,table.cc-recent-table";
    root.querySelectorAll(selector).forEach(table=>{
      table.classList.add("se-responsive-table");
      const headers=[...table.querySelectorAll("thead th")].map(th=>th.textContent.trim());
      table.querySelectorAll("tbody tr").forEach(row=>{
        [...row.children].forEach((cell,index)=>{
          if(cell.tagName==="TD" && !cell.dataset.label) cell.dataset.label=headers[index]||"Dato";
        });
      });
    });
  }

  function enhanceMobileFilters(root=content) {
    const panels=[...root.querySelectorAll(".solicitudes-filter-panel,.orders-filters,.quotes-filters,.people-filter-section,.warranty-filter-panel,.smart-list-tools,.user-filter-grid,.catalog-toolbar")]
      .filter(panel=>!(panel.classList.contains("warranty-filter-panel") && panel.querySelector(".smart-list-tools")));
    panels.forEach((panel,index)=>{
      if(panel.classList.contains("mobile-filter-panel")) return;
      const id=`mobileFilters-${state.current}-${index}`;
      panel.classList.add("mobile-filter-panel");
      panel.dataset.mobileFilterId=id;
      const trigger=document.createElement("button");
      trigger.type="button";
      trigger.className="mobile-filter-trigger";
      trigger.innerHTML='<i data-lucide="sliders-horizontal"></i><span>Filtros y orden</span>';
      trigger.setAttribute("aria-controls",id);
      trigger.addEventListener("click",()=>openMobileFilters(panel));
      panel.id=id;
      panel.parentNode?.insertBefore(trigger,panel);
      const head=document.createElement("div");
      head.className="mobile-filter-head";
      head.innerHTML='<strong>Filtros y orden</strong><button type="button" class="mobile-filter-close" aria-label="Cerrar filtros"><i data-lucide="x"></i></button>';
      head.querySelector("button")?.addEventListener("click",closeMobileFilters);
      panel.insertBefore(head,panel.firstChild);
    });
  }

  function enhanceRenderedContent(root=content) {
    enhanceResponsiveTables(root);
    enhanceMobileFilters(root);
    if (!root.querySelector('.se-date-view-note') && historicalDate() && ["dashboard","solicitudes","ordenes","cotizaciones","notificaciones","auditoria","agenda"].includes(state.current)) {
      const banner = document.createElement("div");
      banner.innerHTML = historicalDateNotice();
      const note = banner.firstElementChild;
      if (note) root.insertBefore(note,root.firstChild);
    }
    window.lucide?.createIcons();
  }

  function applyModuleVisualMode(module) {
    document.body.dataset.module = module;
    const coordinatorVisualMode = state.role === "COORDINADOR";
    document.body.classList.toggle("center-control-mode", coordinatorVisualMode && module === "dashboard");
    document.body.classList.toggle("solicitudes-mode", coordinatorVisualMode && module === "solicitudes");
    document.body.classList.toggle("ordenes-list-mode", coordinatorVisualMode && module === "ordenes");
    document.body.classList.toggle("cotizaciones-list-mode", coordinatorVisualMode && module === "cotizaciones");
    document.body.classList.toggle("personas-list-mode", coordinatorVisualMode && ["clientes", "personal", "usuarios"].includes(module));
    document.body.classList.toggle("equipment-maintenance-ui-mode", coordinatorVisualMode && ["equipos", "mantenimientos"].includes(module));
    document.body.classList.toggle("documents-ui-mode", module === "documentos");
    document.body.classList.toggle("warranty-ui-mode", coordinatorVisualMode && module === "garantia");
    document.body.classList.toggle("notifications-ui-mode", coordinatorVisualMode && module === "notificaciones");
    document.body.classList.toggle("audit-ui-mode", coordinatorVisualMode && module === "auditoria");
    document.body.classList.toggle("account-ui-mode", coordinatorVisualMode && module === "cuenta");
    document.body.classList.toggle("agenda-ui-mode", module === "agenda");
    document.body.classList.toggle("roles-ui-mode", coordinatorVisualMode && module === "roles");
  }

  function beginModuleTransition() {
    // El contenido dinámico se oculta ANTES de cambiar cualquier estado o clase
    // de módulo. Así nunca puede pintarse un frame de HTML con los selectores
    // del módulo equivocado mientras una petición asíncrona está pendiente.
    content.classList.remove("se-module-ready");
    content.classList.add("se-module-switching");
    content.setAttribute("aria-busy", "true");
    try { content.inert = true; } catch (_) {}
  }

  function revealModuleContent() {
    return new Promise(resolve => {
      // Dos frames: 1) el navegador aplica las clases del módulo y recalcula estilo;
      // 2) recién entonces hacemos visible el contenido ya completamente estilizado.
      requestAnimationFrame(() => requestAnimationFrame(() => {
        content.classList.remove("se-module-switching");
        content.classList.remove("se-module-ready");
        content.removeAttribute("aria-busy");
        try { content.inert = false; } catch (_) {}
        void content.offsetWidth;
        content.classList.add("se-module-ready");
        window.setTimeout(() => content.classList.remove("se-module-ready"), 180);
        resolve();
      }));
    });
  }

  async function navigate(module, options = {}) {
    const force = Boolean(options?.force);
    const loaderDelay = Number.isFinite(Number(options?.loaderDelay)) ? Math.max(0, Number(options.loaderDelay)) : 650;
    const navigationSource = options?.breadcrumbReset ? null : contentNavigationSource;
    closeMobileFilters();

    if (state.current === "agenda" && module !== "agenda" && state.agenda?.dirty) {
      if (!window.confirm("Hay cambios de planificación sin guardar. ¿Deseas salir y descartarlos?")) return;
      state.agenda.draft.clear(); state.agenda.dirty = false;
    }
    clearTimeout(smartSearchTimer);
    filterRevision++;
    if (state.warrantyTimer) { clearInterval(state.warrantyTimer); state.warrantyTimer = null; }

    module = resolveGroupedModule(module);
    const valid = new Set((modules[state.role] || []).filter(([key])=>moduleAllowed(key)).map(([key]) => key));
    if (!valid.has(module)) module = firstAllowedModule();
    try { await verifyLiveBackend(); }
    catch (error) { showUnavailableModule(module, error); return; }

    if (options?.breadcrumbReset) breadcrumbParent = null;
    else if (navigationSource && navigationSource.module !== module) breadcrumbParent = navigationSource;

    // No volvemos a cargar un módulo que ya está pintado únicamente por volver
    // a presionar su botón. Esto elimina el loader al hacer clic repetido o fuera
    // de la zona de contenido sobre el mismo acceso activo.
    if (!force && state.current === module && content.dataset.renderedModule === module && !state.dirtyModules.has(module)) {
      renderNav();
      updateBreadcrumb();
      return;
    }

    if (force) {
      invalidateListCache(module);
      invalidateApiCacheForModule(module);
      invalidateViewCache(module);
    }

    const previousModule = state.current;
    const hasRenderedModule = Boolean(content.dataset.renderedModule && content.childElementCount);
    const cachedView = !force ? getViewSnapshot(module) : null;

    // Si ya visitamos el módulo y nada lo invalidó, restauramos su vista completa
    // directamente desde memoria. No hay petición, loader ni reconstrucción del HTML.
    if (cachedView) {
      if (module === "notificaciones") acknowledgeNotificationsView();
      beginModuleTransition();
      state.current = module;
      if (state.role) {
        sessionStorage.setItem(`seprigua_modulo_${state.roleName || state.role}`, module);
        const grouped = groupForModule(module);
        if (grouped) sessionStorage.setItem(`seprigua_grupo_${state.role}_${grouped[0]}`, module);
      }
      renderNav();
      const systemScrollRegion = document.getElementById("systemScrollRegion");
      if (systemScrollRegion) systemScrollRegion.scrollTop = 0;
      restoreViewSnapshot(module, cachedView);
      updateBreadcrumb(cachedView.title);
      delete content.dataset.offline;
      decorateModuleHeader();
      await revealModuleContent();
      return;
    }

    // Blindaje anti-FOUC: ocultar la superficie dinámica antes de cambiar
    // state.current, títulos, clases o iniciar cualquier render asíncrono.
    beginModuleTransition();

    // No invalidamos el cache solamente por cambiar de pantalla. Las mutaciones
    // ya invalidan de forma selectiva sus listas relacionadas. Así, al volver a
    // un módulo previamente cargado, los datos disponibles se pintan al instante
    // y el loader global solo aparece cuando realmente hay que esperar al backend.
    state.current = module;
    captureModuleRoot = true;
    if (module === "notificaciones") acknowledgeNotificationsView();

    // CRÍTICO: mientras esperamos la API mantenemos las clases visuales del módulo
    // anterior. Muchos estilos son específicos por módulo (body.*-mode). Cambiarlas
    // antes de que el nuevo HTML esté listo hacía que la vista anterior perdiera su
    // CSS y apareciera por unos segundos como HTML nativo. En el primer arranque no
    // existe contenido anterior, por lo que sí podemos aplicar el modo de inmediato.
    if (!hasRenderedModule) applyModuleVisualMode(module);

    if (state.role) {
      sessionStorage.setItem(`seprigua_modulo_${state.roleName || state.role}`, module);
      const grouped = groupForModule(module);
      if (grouped) sessionStorage.setItem(`seprigua_grupo_${state.role}_${grouped[0]}`, module);
    }

    syncPrototypeChrome();
    renderNav();
    const systemScrollRegion = document.getElementById("systemScrollRegion");
    if (systemScrollRegion) systemScrollRegion.scrollTop = 0;

    const map = { produccion:operationsUI.production,cancelaciones:operationsUI.cancellations, dashboard: renderDashboard, solicitudes: renderSolicitudes, ordenes: renderOrdenes, agenda: renderAgendaOperativa, clientes: renderClientes, sedes: renderMisSedes, personal: renderPersonal, usuarios: renderUsuarios, equipos: renderEquipos, mantenimientos: renderMantenimientos, catalogo: renderCatalogoMaestro, vacaciones: renderVacaciones, cotizaciones: renderCotizaciones, documentos: renderDocumentos, notificaciones: renderNotificaciones, roles: renderRolesAccess, cuenta: renderCuenta, auditoria: renderAuditoria, garantia: renderGarantia };

    let settled = false;
    let globalLoaderToken = null;
    let loaderTimer = null;
    const startLoader = () => {
      if (settled || globalLoaderToken) return;
      globalLoaderToken = loading(module);
    };
    loaderTimer = window.setTimeout(startLoader, loaderDelay);

    try {
      await (map[module] || renderDashboard)();
      if(state.current!==module){await navigate(state.current,{force:true});return;}
      // Algunos módulos asignan el título directamente, sin llamar a setHeading.
      // Guardamos su nombre real para que la vista principal nunca parezca un detalle.
      if (captureModuleRoot) {
        moduleRootHeadings.set(module, title.textContent);
        captureModuleRoot = false;
      }
      updateBreadcrumb(title.textContent);
      settled = true;
      if (loaderTimer) window.clearTimeout(loaderTimer);
      // El HTML nuevo y su clase de módulo se activan en el mismo ciclo de pintura.
      // Así nunca existe un frame con contenido de Solicitudes usando estilos de
      // Órdenes (o viceversa).
      applyModuleVisualMode(module);
      renderContextTabs();
      renderRoleModuleHero();
      decorateModuleHeader();
      enhanceRenderedContent();
      if(['solicitudes','ordenes'].includes(module)&&['COORDINADOR','CLIENTE'].includes(state.role)&&moduleAllowed('cancelaciones')&&!content.querySelector('[data-context-module="cancelaciones"]')){
        const head=content.querySelector('.panel-header');if(head){const link=document.createElement('button');link.type='button';link.className='btn';link.dataset.contextModule='cancelaciones';link.textContent='Solicitudes de cancelación';head.append(link);}
      }
      content.dataset.renderedModule = module;
      delete content.dataset.offline;
      state.dirtyModules.delete(module);
      saveViewSnapshot(module);
      if (globalLoaderToken) await window.SEPRIGUALoader?.finish(globalLoaderToken);
      await revealModuleContent();
    } catch (e) {
      settled = true;
      if (loaderTimer) window.clearTimeout(loaderTimer);
      content.removeAttribute("data-rendered-module");
      // En error también aplicamos primero el modo visual correcto y revelamos
      // una superficie ya estilizada; nunca dejamos visible el HTML intermedio.
      applyModuleVisualMode(module);
      if (globalLoaderToken && window.SEPRIGUALoader?.fail) {
        window.SEPRIGUALoader.fail(globalLoaderToken, e, { retry: () => navigate(module, { force: true }) });
        content.innerHTML = sepriguaModuleError(module, e);
        window.lucide?.createIcons();
      } else {
        if (globalLoaderToken) window.SEPRIGUALoader?.cancel(globalLoaderToken);
        content.innerHTML = sepriguaModuleError(module, e);
        window.lucide?.createIcons();
      }
      if(['solicitudes','ordenes'].includes(module)&&['COORDINADOR','CLIENTE'].includes(state.role)&&moduleAllowed('cancelaciones')&&!content.querySelector('[data-context-module="cancelaciones"]')){
        const head=content.querySelector('.panel-header');if(head){const link=document.createElement('button');link.type='button';link.className='btn';link.dataset.contextModule='cancelaciones';link.textContent='Solicitudes de cancelación';head.append(link);}
      }
      content.dataset.renderedModule = module;
      await revealModuleContent();
    }
  }

  function quickReportMeta(period){
    return {
      semana:{title:"Descarga el reporte de esta semana",label:"semanal"},
      dia:{title:"Descarga el reporte de este día",label:"diario"},
      mes:{title:"Descarga el reporte de este mes",label:"mensual"}
    }[period] || {title:"Descarga el reporte de esta semana",label:"semanal"};
  }

  function selectQuickReportPeriod(button){
    const period=button.dataset.period;
    if(!["semana","dia","mes"].includes(period))return;
    state.quickReportPeriod=period;
    const card=button.closest(".cc-weekly-report");
    card?.querySelectorAll(".cc-report-period-option").forEach(option=>{
      const active=option.dataset.period===period;
      option.classList.toggle("is-active",active);
      option.setAttribute("aria-pressed",String(active));
    });
    const heading=card?.querySelector("#quickReportTitle");
    if(heading)heading.textContent=quickReportMeta(period).title;
    saveViewSnapshot("dashboard");
  }

  async function downloadQuickReport(button){
    const input=content.querySelector("#weeklyReportDate");
    if(!input?.value||!input.checkValidity())return showToast("Elegí una fecha para el reporte.","error");
    state.weeklyReportDate=input.value;
    const period=["semana","dia","mes"].includes(state.quickReportPeriod)?state.quickReportPeriod:"semana";
    const meta=quickReportMeta(period);
    button.disabled=true;
    try{
      const endpoint=period==="semana"
        ?`/api/dashboard/reporte-semanal.pdf?semana=${encodeURIComponent(input.value)}`
        :`/api/dashboard/reporte-periodo.pdf?periodo=${period}&fecha=${encodeURIComponent(input.value)}`;
      const response=await fetch(endpoint,{credentials:"same-origin",cache:"no-store"});
      if(!response.ok||!String(response.headers.get("content-type")||"").includes("application/pdf")){
        const detail=await response.json().catch(()=>({}));
        throw new Error(detail.message||`No fue posible descargar el reporte ${meta.label}.`);
      }
      const blob=await response.blob();
      const url=URL.createObjectURL(blob);
      let filenameDate=input.value;
      if(period==="semana"){
        const [year,month,day]=input.value.split("-").map(Number);
        const monday=new Date(Date.UTC(year,month-1,day));
        monday.setUTCDate(monday.getUTCDate()-((monday.getUTCDay()+6)%7));
        filenameDate=monday.toISOString().slice(0,10);
      }else if(period==="mes")filenameDate=input.value.slice(0,7);
      const link=document.createElement("a");
      link.href=url;link.download=`SEPRIGUA-reporte-${meta.label}-${filenameDate}.pdf`;
      document.body.appendChild(link);link.click();link.remove();
      setTimeout(()=>URL.revokeObjectURL(url),60000);
      showToast(`Reporte ${meta.label} descargado.`);
    }catch(error){showToast(error.message||`No fue posible descargar el reporte ${meta.label}.`,"error");}
    finally{if(button.isConnected)button.disabled=false;}
  }

  document.addEventListener("change", event=>{
    if(!event.target.matches("[data-dashboard-anchor]")||!event.target.value||!event.target.validity.valid)return;
    state.dashboardAnchor=event.target.value;
    state.dashboardRecentPage=1;
    renderDashboard().catch(error=>showToast(error.message,"error"));
  });
  let dashboardRevision=0;
  function dashboardPeriodMarkup(kind,anchor,period) {
    const buttons=[["actual","General"],["dia","Día"],["semana","Semana"],["mes","Mes"]];
    return `<div class="se-operation-period" aria-label="Período del centro de control">
      <div class="actions" role="group" aria-label="Intervalo">${buttons.map(([key,label])=>`<button type="button" class="btn small" data-action="dashboard-period" data-value="${key}" aria-pressed="${kind===key}">${label}</button>`).join("")}</div>
      ${period?`<label>Fecha de referencia<input type="date" data-dashboard-anchor min="2000-01-01" max="2100-12-31" value="${esc(anchor)}"></label><span>${esc(period.desde===period.hasta?period.desde:period.desde+" a "+period.hasta)}</span>`:""}
    </div>`;
  }

  async function renderDashboard() {
    const revision=++dashboardRevision;
    const kind=state.dashboardPeriod || (historicalDate()?"dia":"actual");
    const anchor=state.dashboardAnchor || historicalDate() || gtDateKey(new Date());
    const endpoint=kind==="actual"?"/api/dashboard":"/api/dashboard?"+new URLSearchParams({periodo:kind,fecha:anchor});
    await refreshCatalogs();
    // Los portales de Cliente y Técnico comparten la misma calidad visual del Centro de Control,
    // pero conservan únicamente la información y acciones permitidas para cada rol.
    if (state.role !== "COORDINADOR") {
      const isClient = state.role === "CLIENTE";
      const firstName = dashboardFirstName();
      setHeading("Centro de control", isClient ? "Resumen de solicitudes, servicios y documentos de tu cuenta." : "Resumen de órdenes, agenda y actividad asignada.");
      const d = await api(endpoint);
      if(revision!==dashboardRevision||state.current!=="dashboard")return;
      const periodControls=dashboardPeriodMarkup(kind,anchor,d.periodo);
      const cards = d.cards || {};
      const labels = {
        solicitudes_pendientes:"Solicitudes pendientes", ordenes_activas:"Órdenes activas", emergencias:"Emergencias", tecnicos_disponibles:"Técnicos disponibles", equipos_disponibles:"Equipos disponibles", clientes_activos:"Clientes activos", cotizaciones_pendientes:"Cotizaciones pendientes", mantenimientos_pendientes:"Mantenimientos",
        hoy:d.periodo?"Programadas en el período":"Órdenes de hoy", finalizadas:"Finalizadas", incidencias:"Incidencias", solicitudes:"Solicitudes", servicios_activos:"Servicios activos", completados:"Completados", documentos:"Documentos"
      };
      const icons = {
        solicitudes_pendientes:"inbox", ordenes_activas:"clipboard-check", emergencias:"siren", equipos_disponibles:"wrench", cotizaciones_pendientes:"receipt-text",
        hoy:"calendar-check-2", finalizadas:"circle-check-big", incidencias:"triangle-alert", solicitudes:"file-plus-2", servicios_activos:"activity", completados:"badge-check", documentos:"folder-open"
      };
      const preferredKeys = isClient
        ? ["solicitudes","solicitudes_pendientes","servicios_activos","ordenes_activas","completados","cotizaciones_pendientes","documentos"]
        : ["ordenes_activas","hoy","finalizadas","incidencias","equipos_disponibles","mantenimientos_pendientes"];
      const selected = [];
      preferredKeys.forEach(key => { if (Object.prototype.hasOwnProperty.call(cards,key) && selected.length < 4) selected.push([key,cards[key]]); });
      if (selected.length < 4) Object.entries(cards).forEach(entry => { if (selected.length < 4 && !selected.some(([key]) => key === entry[0])) selected.push(entry); });
      const tones = isClient ? ["blue","cyan","green","amber"] : ["blue","cyan","green","red"];
      const kpis = selected.map(([key,value],index) => `<article class="role-kpi-card role-kpi-${tones[index % tones.length]}">
        <span class="role-kpi-icon"><i data-lucide="${esc(icons[key] || "chart-no-axes-column-increasing")}"></i></span>
        <div class="role-kpi-copy"><small>${esc(labels[key] || key.replaceAll("_"," "))}</small><strong>${normalizeNumber(value)}</strong><span>${isClient ? esc(({solicitudes:"Registradas",ordenes_activas:"En seguimiento",ordenes_completadas:"Trabajos finalizados",documentos:"Disponibles"})[key] || "Resumen de tu cuenta") : "Actividad operativa"}</span></div>
      </article>`).join("");

      const quicks = (isClient
        ? [["solicitudes","circle-plus","Nueva solicitud","Solicita un servicio"],["ordenes","clipboard-list","Mis servicios","Revisa tus trabajos"],["garantia","shield-check","Garantía","Consulta cobertura"],["cotizaciones","file-text","Cotizaciones","Revisa propuestas"]]
        : [["ordenes","clipboard-check","Mis órdenes","Trabajos asignados"],["agenda","route","Mi agenda","Ruta y programación"],["equipos","wrench","Equipo","Inventario técnico"],["vacaciones","calendar-days","Horarios y vacaciones","Consulta tu calendario"]]
      ).filter(([module]) => moduleAllowed(module));
      const quickMarkup = quicks.map(([module,icon,label,description]) => `<button class="role-quick-action" type="button" data-role-nav="${esc(module)}"><span><i data-lucide="${esc(icon)}"></i></span><div><strong>${esc(label)}</strong><small>${esc(description)}</small></div><i data-lucide="chevron-right"></i></button>`).join("");

      const recent = (d.recent || []).slice(0,6);
      const recentMarkup = recent.length ? recent.map(x => `<article class="role-activity-item">
        <span class="role-activity-icon"><i data-lucide="${x.numero ? "clipboard-list" : "activity"}"></i></span>
        <div class="role-activity-copy"><strong>${esc(x.numero || x.tipo || `#${x.id || "—"}`)}</strong><span>${esc(x.cliente || x.descripcion || (isClient ? "Servicio SEPRIGUA" : "Actividad operativa"))}</span><small>${esc(x.sede || x.clasificacion || "Sin sede")} · ${fmt(x.programada || x.fecha)}</small></div>
        <div class="role-activity-status">${badge(x.estado || x.prioridad || "")}${x.numero ? `<button class="btn small" type="button" data-action="ver-orden" data-id="${esc(x.id)}"><i data-lucide="eye"></i><span>Ver</span></button>` : ""}</div>
      </article>`).join("") : `<div class="role-empty-state"><i data-lucide="sparkles"></i><strong>Todo al día</strong><span>No hay actividad reciente para mostrar.</span></div>`;

      const accountLabel = isClient ? (state.user?.cliente || state.user?.nombre || "Cliente SEPRIGUA") : (state.user?.nombre || "Técnico SEPRIGUA");
      const daypart = portalDaypart();
      const dashboardSummary = isClient
        ? "Consulta y gestiona tus servicios desde un solo lugar."
        : "Consulta tus trabajos, prioridades y accesos operativos desde un solo lugar.";
      const dashboardHero = `
        <header class="cc-workspace-heading cc-time-banner" id="centerDaypartBanner" data-daypart="${daypart.key}">
          <img class="cc-time-banner-art" id="centerDaypartArt" src="${daypart.image}" alt="" aria-hidden="true" decoding="async" fetchpriority="high">
          <div class="cc-time-banner-overlay" aria-hidden="true"></div>
          <div class="cc-time-banner-copy">
            <h1 id="centerGreeting" data-user-first="${esc(firstName)}">${daypart.greeting}, ${esc(firstName)}</h1>
            <p>${dashboardSummary}</p>
            <div class="cc-time-banner-footer">
              <div class="cc-sync-state" id="centerSyncState" data-state="updated" role="status" aria-live="polite">
                <i data-lucide="clock-3" aria-hidden="true"></i>
                <span id="centerSyncText">Última actualización</span>
              </div>
              <span class="cc-daypart-detail" id="centerDaypartDetail">${daypart.detail}</span>
            </div>
          </div>
        </header>`;
      content.innerHTML = `<div class="role-dashboard role-dashboard-${isClient ? "client" : "tech"}">
        ${dashboardHero}
        ${periodControls}
        <section class="role-kpi-grid">${kpis || `<div class="role-empty-state"><span>Sin indicadores disponibles.</span></div>`}</section>
        <div class="role-dashboard-layout">
          <section class="panel role-activity-panel"><div class="panel-header"><div><span class="role-section-kicker">MOVIMIENTO RECIENTE</span><h2>Actividad reciente</h2></div></div><div class="role-activity-list">${recentMarkup}</div></section>
          <aside class="panel role-quick-panel"><div class="panel-header"><div><span class="role-section-kicker">ACCESOS RÁPIDOS</span><h2>${isClient ? "Gestiona tu cuenta" : "Herramientas de trabajo"}</h2></div></div><div class="role-quick-list">${quickMarkup}</div></aside>
        </div>
      </div>`;
      window.lucide?.createIcons();
      return;
    }

    // Centro de control del Coordinador.
    setHeading("Centro de control", "Resumen operativo del centro de control");
    document.dispatchEvent(new CustomEvent("seprigua:center-sync-state", { detail: { state: "syncing" } }));

    const d = await api(endpoint);
      if(revision!==dashboardRevision||state.current!=="dashboard")return;
      const periodControls=dashboardPeriodMarkup(kind,anchor,d.periodo);
    const cards = d.cards || {};
    const emergencyCount=normalizeNumber(cards.emergencias);
    const pendingRequests=normalizeNumber(cards.solicitudes_pendientes);
    const activeOrders=normalizeNumber(cards.ordenes_activas);
    const pendingQuotes=normalizeNumber(cards.cotizaciones_pendientes);
    const unquotedOrders=normalizeNumber(cards.ordenes_sin_cotizar);
    const availableTechs = normalizeNumber(cards.tecnicos_disponibles);
    const staffCapacity = dashboardStaffCapacity();
    const availableEquipment = normalizeNumber(cards.equipos_disponibles);
    const activeClients = normalizeNumber(cards.clientes_activos);
    const maintenances = normalizeNumber(cards.mantenimientos_pendientes);
    const pendingWarranties = normalizeNumber(cards.garantias_pendientes);

    // Totales y tendencias son opcionales. Si el backend no los entrega,
    // la UI no inventa porcentajes: muestra un estado neutral/indeterminado.
    const totalEquipment = dashboardOptionalNumber(
      cards.equipos_totales,
      cards.total_equipos,
      d.totals?.equipos,
      d.totales?.equipos,
      Array.isArray(state.catalogs?.equipos) ? state.catalogs.equipos.length : null
    );
    const clientsTrend = dashboardOptionalNumber(
      d.trends?.clientes_activos,
      d.tendencias?.clientes_activos,
      cards.clientes_activos_variacion,
      cards.clientes_activos_tendencia
    );
    const maintenanceTrend = dashboardOptionalNumber(
      d.trends?.mantenimientos,
      d.trends?.mantenimientos_pendientes,
      d.tendencias?.mantenimientos,
      cards.mantenimientos_variacion,
      cards.mantenimientos_tendencia
    );

    const recent = d.recent || [];
    const recentPageSize = 4;
    const recentPages = Math.max(1, Math.ceil(recent.length / recentPageSize));
    state.dashboardRecentPage = Math.min(Math.max(1, Number(state.dashboardRecentPage || 1)), recentPages);
    const recentStartIndex = (state.dashboardRecentPage - 1) * recentPageSize;
    const recentVisible = recent.slice(recentStartIndex, recentStartIndex + recentPageSize);
    const recentRows = recentVisible.map(x => {
      const status = String(x.estado || x.prioridad || "").trim().toUpperCase();
      const kind = String(x.clasificacion || x.tipo || "").trim().toUpperCase();
      const emergency = /EMERGEN|CRITIC/.test(kind);
      const finished = /FINALIZ|COMPLET/.test(status);
      const progress = /PROCESO|CURSO/.test(status);
      const scheduled = /PROGRAM|ASIGNAD/.test(status);
      const cancelled = /CANCEL/.test(status);
      const tone = emergency && !finished ? "danger" : finished ? "success" : progress ? "warning" : scheduled ? "info" : cancelled ? "neutral" : "info";
      const icon = emergency && !finished ? "triangle-alert" : finished ? "check-circle-2" : progress ? "clock-3" : scheduled ? "calendar-check-2" : "clipboard-list";
      const reference = x.numero || x.tipo || `#${x.id || "—"}`;
      const person = x.cliente || x.descripcion || "Sin detalle";
      const context = x.sede ? `Sede: ${esc(x.sede)}` : x.clasificacion ? esc(dashboardReadableLabel(x.clasificacion)) : "";
      const open = x.numero ? iconButton("arrow-up-right", "ver-orden", x.id, `Abrir ${x.numero}`, "cc-activity-open") : "";
      return `<article class="cc-activity-item" role="listitem">
        <span class="cc-activity-icon cc-activity-icon-${tone}" aria-hidden="true"><i data-lucide="${icon}"></i></span>
        <div class="cc-activity-main"><strong class="cc-activity-reference">${esc(reference)}</strong><span class="cc-activity-person">${esc(person)}</span>${context ? `<small class="cc-activity-context">${context}</small>` : ""}</div>
        <div class="cc-activity-side"><div class="cc-activity-meta">${dashboardStatusBadge(x.estado || x.prioridad || "—")}<span class="cc-activity-date">${fmt(x.programada || x.fecha || x.creada)}</span></div>${open}</div>
      </article>`;
    });

    const chartItems = Array.isArray(d.chart) ? d.chart : [];
    const chartLabel=x=>x.dia?x.dia.slice(8,10)+"/"+x.dia.slice(5,7):dashboardMonthLabel(x.mes);
    const chartMax = Math.max(1, ...chartItems.map(x => normalizeNumber(x.ordenes)));
    const chartTotal = chartItems.reduce((sum, x) => sum + normalizeNumber(x.ordenes), 0);
    const chartMarkup = chartItems.length
      ? `<div class="cc-chart-body ${d.periodo?"se-period-graph":""}"><div class="cc-chart-summary"><strong>${chartTotal}</strong><span>${chartTotal === 1 ? "orden registrada" : "órdenes registradas"} en el período</span></div>
          <div class="cc-column-chart" role="img" aria-label="${chartTotal} órdenes registradas en el período">
            ${chartItems.map(x => {
              const value = normalizeNumber(x.ordenes);
              const percentage = value <= 0 ? 0 : Math.max(4, Math.round(value / chartMax * 100));
              return `<div class="cc-chart-column ${value > 0 && value === chartMax ? "cc-chart-column-leading" : ""} ${value === 0 ? "cc-chart-column-zero" : ""}">
                <span class="cc-chart-value">${value}</span><div class="cc-chart-track"><span class="cc-chart-bar" style="height:${percentage}%" title="${esc(chartLabel(x))}: ${value} ${value === 1 ? "orden" : "órdenes"}"></span></div><span class="cc-chart-label">${esc(chartLabel(x))}</span>
              </div>`;
            }).join("")}
          </div>
        </div>`
      : `<div class="cc-chart-empty"><i data-lucide="chart-no-axes-column"></i><span>No hay datos de órdenes para graficar.</span></div>`;

    const firstName = dashboardFirstName();
    const daypart = portalDaypart();

    content.innerHTML = `
      <div class="cc-dashboard-shell">
        <header class="cc-workspace-heading cc-time-banner" id="centerDaypartBanner" data-daypart="${daypart.key}">
          <img class="cc-time-banner-art" id="centerDaypartArt" src="${daypart.image}" alt="" aria-hidden="true" decoding="async" fetchpriority="high">
          <div class="cc-time-banner-overlay" aria-hidden="true"></div>
          <div class="cc-time-banner-copy">
            <h1 id="centerGreeting" data-user-first="${esc(firstName)}">${daypart.greeting}, ${esc(firstName)}</h1>
            <p>Resumen operativo del centro de control</p>
            <div class="cc-time-banner-footer">
              <div class="cc-sync-state" id="centerSyncState" data-state="updated" role="status" aria-live="polite">
                <i data-lucide="clock-3" aria-hidden="true"></i>
                <span id="centerSyncText">Última actualización</span>
              </div>
              <span class="cc-daypart-detail" id="centerDaypartDetail">${daypart.detail}</span>
            </div>
          </div>
        </header>


        ${periodControls}
        <section class="cc-kpi-grid" aria-label="Indicadores operativos principales">
          <article class="cc-kpi cc-kpi-emergency ${emergencyCount > 0 ? "cc-kpi-alert" : "cc-kpi-idle"}">
            <button class="cc-kpi-more" type="button" data-action="dashboard-ver-emergencias" aria-label="Ver más emergencias">
              <span>Ver más</span><i data-lucide="arrow-right"></i>
            </button>
            <div class="cc-kpi-icon"><i data-lucide="triangle-alert"></i></div>
            <div class="cc-kpi-copy">
              <span>Emergencias</span>
              <strong>${emergencyCount}</strong>
              <small>${d.periodo ? "Registros del período" : "Requieren atención"}</small>
            </div>
          </article>

          <article class="cc-kpi cc-kpi-info cc-kpi-requests">
            <button class="cc-kpi-more" type="button" data-action="dashboard-ver-solicitudes" aria-label="Ver más solicitudes pendientes">
              <span>Ver más</span><i data-lucide="arrow-right"></i>
            </button>
            <div class="cc-kpi-icon"><i data-lucide="inbox"></i></div>
            <div class="cc-kpi-copy">
              <span>Solicitudes pendientes</span>
              <strong>${pendingRequests}</strong>
              <small>${d.periodo ? "Registros del período" : "Por gestionar"}</small>
            </div>
          </article>

          <article class="cc-kpi cc-kpi-orders">
            <button class="cc-kpi-more" type="button" data-action="dashboard-ver-ordenes" aria-label="Ver más órdenes activas">
              <span>Ver más</span><i data-lucide="arrow-right"></i>
            </button>
            <div class="cc-kpi-icon"><i data-lucide="clipboard-check"></i></div>
            <div class="cc-kpi-copy">
              <span>Órdenes activas</span>
              <strong>${activeOrders}</strong>
              <small>${d.periodo ? "Registros del período" : "Operación en curso"}</small>
            </div>
          </article>

          <article class="cc-kpi cc-kpi-quote">
            <button class="cc-kpi-more" type="button" data-action="dashboard-ver-cotizaciones" aria-label="Ver órdenes por cotizar y cotizaciones">
              <span>Ver más</span><i data-lucide="arrow-right"></i>
            </button>
            <div class="cc-kpi-icon"><i data-lucide="receipt-text"></i></div>
            <div class="cc-kpi-copy">
              <span>Órdenes por cotizar</span>
              <strong>${unquotedOrders}</strong>
              <small>${pendingQuotes} ${pendingQuotes===1?"cotización por gestionar":"cotizaciones por gestionar"}</small>
            </div>
          </article>
        </section>

        ${pendingWarranties>0?`<section class="cc-warranty-alert"><span class="cc-warranty-alert-icon"><i data-lucide="shield-alert"></i></span><div><strong>${pendingWarranties} solicitud${pendingWarranties===1?"":"es"} de garantía requieren seguimiento</strong><span>Revisa visitas, resultado de garantía o autorizaciones pendientes del cliente.</span></div><button class="btn primary" type="button" data-action="dashboard-ver-garantias">Revisar garantías <i data-lucide="arrow-right"></i></button></section>`:""}

        <section class="cc-report-bento" aria-label="Paneles del Centro de control">
          <div class="cc-report-column cc-report-column-main">
            <section class="cc-secondary-grid">
              <article class="cc-bento-panel cc-capacity-panel">
                <div class="cc-panel-heading cc-panel-heading-row">
                  <div>
                    <h2>Capacidad operativa</h2>
                  </div>
                  <button class="cc-link-action" type="button" data-action="dashboard-ver-capacidad">
                    <span>Ver más</span><i data-lucide="arrow-right" aria-hidden="true"></i>
                  </button>
                </div>
              
                <div class="cc-capacity-grid cc-capacity-grid-staff">
                  <div class="cc-capacity-item">
                    <span class="cc-capacity-icon cc-capacity-blue"><i data-lucide="hard-hat"></i></span>
                    <div class="cc-capacity-copy">
                      <span>Operarios disponibles</span>
                      <strong>${staffCapacity.operarios.available}</strong>
                      ${dashboardCapacityProgress(staffCapacity.operarios.available, staffCapacity.operarios.total, "blue")}
                    </div>
                  </div>
              
                  <div class="cc-capacity-item">
                    <span class="cc-capacity-icon cc-capacity-supervisor"><i data-lucide="shield-user"></i></span>
                    <div class="cc-capacity-copy">
                      <span>Supervisores disponibles</span>
                      <strong>${staffCapacity.supervisores.available}</strong>
                      ${dashboardCapacityProgress(staffCapacity.supervisores.available, staffCapacity.supervisores.total, "blue")}
                    </div>
                  </div>
              
                  <div class="cc-capacity-item">
                    <span class="cc-capacity-icon ${availableEquipment === 0 ? "cc-capacity-red" : "cc-capacity-blue"}"><i data-lucide="wrench"></i></span>
                    <div class="cc-capacity-copy">
                      <span>Equipos disponibles</span>
                      <strong>${availableEquipment}</strong>
                      ${dashboardCapacityProgress(availableEquipment, totalEquipment, availableEquipment === 0 ? "red" : "blue")}
                      ${availableEquipment === 0
                        ? `<small class="cc-inline-alert"><i data-lucide="triangle-alert"></i> Sin equipos disponibles</small>`
                        : ``}
                    </div>
                  </div>
                </div>
              </article>
            </section>
            <section class="cc-detail-grid">
              <article class="cc-bento-panel cc-recent-panel">
                <div class="cc-panel-heading cc-panel-heading-row">
                  <div>
                    <h2>Actividad reciente</h2>
                  </div>
                  <button class="cc-link-action" type="button" data-action="dashboard-ver-ordenes">
                    <span>Ver más</span><i data-lucide="arrow-right" aria-hidden="true"></i>
                  </button>
                </div>
                <div class="cc-recent-table cc-recent-history">
                  <div class="cc-activity-list" role="list" aria-label="Movimientos operativos recientes">
                    ${recentRows.length ? recentRows.join("") : `<div class="cc-activity-empty"><i data-lucide="inbox"></i><span>Todavía no hay actividad para mostrar.</span></div>`}
                  </div>
                  ${dashboardRecentPager({ pagina: state.dashboardRecentPage, paginas: recentPages, total: recent.length, tamano: recentPageSize })}
                </div>
              </article>
            </section>
          </div>
          <div class="cc-report-column cc-report-column-side">
            <section class="cc-secondary-grid">
              <article class="cc-bento-panel cc-summary-panel">
                <div class="cc-panel-heading cc-panel-heading-row">
                  <div>
                    <h2>Resumen operativo</h2>
                  </div>
                  <button class="cc-link-action" type="button" data-action="dashboard-ver-resumen">
                    <span>Ver más</span><i data-lucide="arrow-right" aria-hidden="true"></i>
                  </button>
                </div>
              
                <div class="cc-summary-grid">
                  <div class="cc-summary-item">
                    <span class="cc-summary-icon"><i data-lucide="building-2"></i></span>
                    <div>
                      <span>Clientes activos</span>
                      <strong>${activeClients}</strong>
                      ${dashboardTrendMarkup(clientsTrend)}
                    </div>
                  </div>
                  <div class="cc-summary-item">
                    <span class="cc-summary-icon"><i data-lucide="settings"></i></span>
                    <div>
                      <span>Mantenimientos</span>
                      <strong>${maintenances}</strong>
                      ${dashboardTrendMarkup(maintenanceTrend)}
                    </div>
                  </div>
                </div>
              </article>
            </section>
              <section class="cc-weekly-report" aria-labelledby="quickReportTitle">
                <div class="cc-weekly-report-copy">
                  <div>
                    <span class="cc-report-eyebrow"><i data-lucide="file-text" aria-hidden="true"></i> Reporte rápido</span>
                    <h2 id="quickReportTitle">${esc(quickReportMeta(state.quickReportPeriod).title)}</h2>
                    <p>Genera reportes operativos por semana, día o mes.</p>
                  </div>
                  <span class="cc-weekly-report-art" aria-hidden="true">
                    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M28 5h38l17 17v58a7 7 0 0 1-7 7H28a7 7 0 0 1-7-7V12a7 7 0 0 1 7-7Z" fill="#F8FBFF"/>
                      <path d="M66 5v14a4 4 0 0 0 4 4h13L66 5Z" fill="#C9E1F5"/>
                      <rect x="33" y="18" width="23" height="4" rx="2" fill="#B7D5EB"/>
                      <rect x="33" y="28" width="34" height="4" rx="2" fill="#D5E8F6"/>
                      <rect x="34" y="57" width="8" height="17" rx="2" fill="#65B7E9"/>
                      <rect x="47" y="48" width="8" height="26" rx="2" fill="#1769AA"/>
                      <rect x="60" y="39" width="8" height="35" rx="2" fill="#65B7E9"/>
                      <path d="m34 46 13-8 11 3 11-11" stroke="#0C3E73" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span class="cc-report-art-download"><i data-lucide="arrow-down" aria-hidden="true"></i></span>
                  </span>
                </div>
                <div class="cc-weekly-report-actions">
                  <div class="cc-report-period" role="group" aria-label="Período del reporte">
                    <button class="cc-report-period-option ${state.quickReportPeriod==="semana"?"is-active":""}" type="button" data-action="seleccionar-reporte-periodo" data-period="semana" aria-pressed="${state.quickReportPeriod==="semana"}">Semana</button>
                    <button class="cc-report-period-option ${state.quickReportPeriod==="dia"?"is-active":""}" type="button" data-action="seleccionar-reporte-periodo" data-period="dia" aria-pressed="${state.quickReportPeriod==="dia"}">Día</button>
                    <button class="cc-report-period-option ${state.quickReportPeriod==="mes"?"is-active":""}" type="button" data-action="seleccionar-reporte-periodo" data-period="mes" aria-pressed="${state.quickReportPeriod==="mes"}">Mes</button>
                  </div>
                  <label class="cc-report-date" for="weeklyReportDate"><span class="cc-report-date-label">Fecha de referencia</span><span class="cc-report-date-field"><i data-lucide="calendar-days" aria-hidden="true"></i><input id="weeklyReportDate" type="date" min="2000-01-01" max="2100-12-31" value="${esc(state.weeklyReportDate||historicalDate()||gtDateKey(new Date()))}"></span></label>
                  <button class="btn primary cc-report-download" type="button" data-action="descargar-reporte-semanal"><i data-lucide="file-down" aria-hidden="true"></i><span>Descargar PDF</span></button>
                </div>
              </section>
            <section class="cc-detail-grid">
              <article class="cc-bento-panel cc-chart-panel">
                <div class="cc-panel-heading">
                  <div>
                    <h2>${d.periodo?"Órdenes del período":"Órdenes · Últimos 6 meses"}</h2>
                  </div>
                  <i data-lucide="chart-column"></i>
                </div>
                ${chartMarkup}
              </article>
            </section>
          </div>
        </section>
      </div>
    `;

    window.lucide?.createIcons();
    animateDashboardCapacityBars();

    document.dispatchEvent(new CustomEvent("seprigua:center-data-updated"));
    document.dispatchEvent(new CustomEvent("seprigua:center-sync-state", { detail: { state: "updated" } }));
  }

  /* ========================================================================
     Agenda operativa
     - Coordinación: planificador visual con arrastre horizontal y guardado en lote.
     - Técnico: lectura de su ruta; en móvil se transforma en una lista rápida.
     ======================================================================== */
  function agendaEmergency(order) {
    const classification=String(order?.clasificacion||"").toUpperCase();
    const priority=String(order?.prioridad||"").toUpperCase();
    return classification==="EMERGENCIA" || priority==="CRITICA";
  }

  function agendaPriorityHigh(order) {
    return !agendaEmergency(order) && String(order?.prioridad||"").toUpperCase()==="ALTA";
  }

  function agendaMinuteText(value) {
    if(value===null || value===undefined || !Number.isFinite(Number(value))) return "Sin hora";
    let minute=Math.max(0,Math.min(1439,Math.round(Number(value))));
    const hour=Math.floor(minute/60), mins=minute%60;
    const d=new Date(2000,0,1,hour,mins);
    return d.toLocaleTimeString("es-GT",{hour:"numeric",minute:"2-digit"});
  }

  function agendaDateLabel(value) {
    if(!value) return "—";
    const [y,m,d]=String(value).split("-").map(Number);
    const date=new Date(y,m-1,d);
    return date.toLocaleDateString("es-GT",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
  }

  function agendaDateShift(value,days) {
    const [y,m,d]=String(value).split("-").map(Number);
    const date=new Date(y,m-1,d);date.setDate(date.getDate()+days);
    const z=n=>String(n).padStart(2,"0");
    return `${date.getFullYear()}-${z(date.getMonth()+1)}-${z(date.getDate())}`;
  }

  function agendaDateTimePayload(day,minute) {
    const m=Math.max(0,Math.min(1439,Math.round(Number(minute))));
    const hh=String(Math.floor(m/60)).padStart(2,"0"),mm=String(m%60).padStart(2,"0");
    return `${day}T${hh}:${mm}:00`;
  }

  function agendaAllOrders(data=state.agenda.data) {
    const map=new Map();
    (data?.tecnicos||[]).forEach(t=>(t.ordenes||[]).forEach(o=>map.set(Number(o.id),o)));
    return map;
  }

  function agendaOrder(orderId) {
    return agendaAllOrders().get(Number(orderId)) || null;
  }

  function agendaCurrentMinute(order) {
    if(!order) return null;
    const id=Number(order.id);
    if(state.agenda.draft.has(id)) return Number(state.agenda.draft.get(id).minute);
    return order.minuto===null || order.minuto===undefined ? null : Number(order.minuto);
  }

  function agendaDisplayMinute(order) {
    const minute=agendaCurrentMinute(order);
    return minute===null ? 18*60 : minute;
  }

  function agendaSetDirtyMinute(orderId,minute,extra={}) {
    const order=agendaOrder(orderId);if(!order)return;
    const snapped=Math.max(0,Math.min(1439,Math.round(Number(minute)/15)*15)),id=Number(orderId);
    const old=state.agenda.draft.get(id)||{day:state.agenda.fecha,source:0,target:0};
    const draft={...old,...extra,minute:snapped};
    if(order.minuto!==null&&Number(order.minuto)===snapped&&draft.day===state.agenda.fecha&&draft.source===draft.target)state.agenda.draft.delete(id);
    else state.agenda.draft.set(id,draft);
    state.agenda.dirty=state.agenda.draft.size>0;agendaRefreshDraftDom(id);
  }

  function agendaScheduleForm(id){
    const order=agendaOrder(id);if(!order||!['PENDIENTE','PROGRAMADA'].includes(order.estado_codigo))return;
    const draft=state.agenda.draft.get(Number(id)),crew=(state.agenda.data?.tecnicos||[]).filter(t=>t.ordenes.some(o=>Number(o.id)===Number(id)));
    const destination=(state.agenda.data?.tecnicos||[]).filter(t=>!['VACACIONES','INACTIVO','NO_DISPONIBLE'].includes(t.disponibilidad));
    openModal('Planificar '+order.numero,`<form id="agendaScheduleForm" class="form-grid"><div class="field full"><label>Atención aproximada<input name="scheduled" type="datetime-local" required value="${esc(agendaDateTimePayload(draft?.day||state.agenda.fecha,agendaDisplayMinute(order)))}"></label></div><div class="field"><label>Integrante de origen<select name="source">${crew.map(t=>`<option value="${t.id}" ${Number(draft?.source)===Number(t.id)?'selected':''}>${esc(t.nombre)}</option>`).join('')}</select></label></div><div class="field"><label>Reasignar a<select name="target"><option value="0">Conservar cuadrilla</option>${destination.map(t=>`<option value="${t.id}" ${Number(draft?.target)===Number(t.id)?'selected':''}>${esc(t.nombre+' · '+t.puesto)}</option>`).join('')}</select></label></div><p class="muted full">El cambio queda pendiente hasta pulsar Guardar planificación.</p><div class="form-actions full"><button class="btn" type="button" data-close-modal>Volver</button><button class="btn primary" type="submit">Aplicar a la vista</button></div></form>`);
    $('#agendaScheduleForm').onsubmit=e=>{e.preventDefault();const f=e.currentTarget,d=f.elements.scheduled.value,[hh,mm]=d.slice(11).split(':').map(Number),target=Number(f.elements.target.value);agendaSetDirtyMinute(id,hh*60+mm,{day:d.slice(0,10),source:target?Number(f.elements.source.value):0,target});closeModal();agendaPaint();};
  }

  function agendaRefreshDraftDom(orderId) {
    const order=agendaOrder(orderId);if(!order)return;
    const minute=agendaDisplayMinute(order),start=Number(content.querySelector(".agenda-grid")?.dataset.startMinute||360);
    const hourWidth=Number(content.querySelector(".agenda-grid")?.dataset.hourWidth||112);
    const left=Math.max(0,(minute-start)/60*hourWidth);
    content.querySelectorAll(`[data-agenda-order="${CSS.escape(String(orderId))}"]`).forEach(card=>{
      card.style.left=`${left}px`;
      card.classList.toggle("unscheduled",agendaCurrentMinute(order)===null);
      const time=card.querySelector("[data-agenda-time]");if(time)time.textContent=agendaMinuteText(agendaCurrentMinute(order));
    });
    const save=content.querySelector("#agendaSaveButton");if(save)save.disabled=!state.agenda.dirty;
    const dirty=content.querySelector("#agendaDirtyBar");if(dirty)dirty.hidden=!state.agenda.dirty||!!content.querySelector("[data-agenda-dragging]");
    const reset=content.querySelector("#agendaResetButton");if(reset)reset.disabled=!state.agenda.dirty;
    const count=content.querySelector("#agendaDirtyCount");if(count)count.textContent=String(state.agenda.draft.size);
    if(Number(state.agenda.selectedOrderId)===Number(orderId)) agendaRenderDetail(orderId);
  }

  function agendaWindow(data) {
    const orders=[...agendaAllOrders(data).values()];
    const mins=orders.map(o=>agendaCurrentMinute(o)).filter(v=>v!==null&&Number.isFinite(Number(v))).map(Number);
    let start=6*60;
    if(mins.length) start=Math.min(start,Math.floor(Math.min(...mins)/60)*60);
    start=Math.max(0,start);
    return {start,end:24*60,hourWidth:112};
  }

  function agendaOrderClass(order) {
    const stateCode=String(order?.estado_codigo||"").toUpperCase();
    if(stateCode==="EN_PROCESO") return "live";
    if(agendaEmergency(order)) return "emergency";
    if(agendaPriorityHigh(order)) return "high";
    return "normal";
  }

  function agendaStatusLabel(tech) {
    const status=String(tech.estado_operativo||"DISPONIBLE").toUpperCase();
    const cls=status==="EN_SERVICIO"?"live":status==="EN_COLA"?"queue":status==="DISPONIBLE"?"available":"away";
    const text=status==="EN_COLA"&&Number(tech.cola_cantidad||0)>0?`${tech.cola_cantidad} EN COLA`:status.replaceAll("_"," ");
    return `<span class="agenda-status ${cls}">${esc(text)}</span>`;
  }

  function agendaTechnicianCell(tech) {
    return `<div class="agenda-tech-main">
      <span class="agenda-avatar">${esc(tech.iniciales||"--")}</span>
      <span class="agenda-tech-name"><strong>${esc(tech.nombre||"Técnico")}</strong><small>${esc(tech.puesto||"Personal técnico")}</small></span>
    </div>
    <div class="agenda-tech-meta">${agendaStatusLabel(tech)}<span class="agenda-tech-mode"><i data-lucide="${tech.en_equipo?"users":"user-round"}"></i>${tech.en_equipo?"Trabajo en cuadrilla":"Ruta individual"}</span></div>`;
  }

  function agendaJobCard(order,windowInfo) {
    const id=Number(order.id),minute=agendaDisplayMinute(order),left=Math.max(0,(minute-windowInfo.start)/60*windowInfo.hourWidth);
    const code=String(order.estado_codigo||"").toUpperCase();
    const draggable=state.role==="COORDINADOR" && ["PENDIENTE","PROGRAMADA"].includes(code);
    const visual=order.estado_visual==="SIGUIENTE"?"SIGUIENTE":order.estado_visual==="EN_COLA"?`COLA ${order.cola_posicion||""}`:code==="EN_PROCESO"?"EN SERVICIO":String(order.prioridad||"");
    const location=order.sede||order.municipio||"Sede";
    const unscheduled=agendaCurrentMinute(order)===null;
    return `<button class="agenda-job ${agendaOrderClass(order)} ${unscheduled?"unscheduled":""} ${draggable?"":"locked"} ${Number(state.agenda.selectedOrderId)===id?"selected":""}" type="button"
      data-agenda-order="${id}" data-agenda-draggable="${draggable?1:0}" style="left:${left}px" aria-label="Abrir ${esc(order.numero||`OT ${id}`)}">
      <span class="agenda-job-bar"></span><span class="agenda-job-body">
        <span class="agenda-job-top"><strong>${esc(order.numero||`OT-${id}`)}</strong><span class="agenda-job-chip">${esc(unscheduled?"SIN HORA":visual)}</span></span>
        <span class="agenda-job-title">${esc(order.servicio||"Servicio")}</span>
        <span class="agenda-job-foot"><span><i data-lucide="clock-3"></i><b data-agenda-time>${esc(agendaMinuteText(agendaCurrentMinute(order)))}</b></span><span title="${esc(location)}"><i data-lucide="map-pin"></i>${esc(location)}</span></span>
      </span></button>`;
  }

  function agendaNowLine(windowInfo) {
    const data=state.agenda.data;if(!data||data.fecha!==data.hoy)return "";
    const minute=Number(data.ahora.slice(11,13))*60+Number(data.ahora.slice(14,16));
    if(minute<windowInfo.start||minute>windowInfo.end)return "";
    const left=(minute-windowInfo.start)/60*windowInfo.hourWidth;
    return `<span class="agenda-now-line" style="left:${left}px" title="Hora actual"></span>`;
  }

  function agendaDetailHtml(order) {
    if(!order)return `<div class="agenda-detail-empty"><span><i data-lucide="mouse-pointer-2"></i></span><strong>Selecciona una orden</strong><p>Presiona un bloque para ver cliente, ubicación, horario y acciones rápidas.</p></div>`;
    const emergency=agendaEmergency(order),minute=agendaCurrentMinute(order);
    const location=[order.direccion,order.municipio,order.departamento].filter(Boolean).join(", ") || order.sede || "—";
    const movable=state.role==="COORDINADOR" && ["PENDIENTE","PROGRAMADA"].includes(String(order.estado_codigo||"").toUpperCase());
    return `<div class="agenda-detail-head">
      <span class="agenda-detail-kicker"><i data-lucide="${emergency?"siren":"clipboard-list"}"></i>${emergency?"EMERGENCIA":"DETALLE DE LA ACTIVIDAD"}</span>
      <h3>${esc(order.numero||`OT-${order.id}`)}</h3><p>${esc(order.servicio||"Servicio programado")}</p>
    </div><div class="agenda-detail-body">
      <div class="agenda-detail-state"><span class="agenda-priority ${emergency?"emergency":""}"><i data-lucide="flag"></i>${esc(order.prioridad||"MEDIA")}</span>${badge(order.estado||order.estado_codigo||"")}</div>
      <div class="agenda-detail-grid">
        <div class="agenda-detail-line"><span><i data-lucide="building-2"></i></span><small>Cliente</small><strong>${esc(order.cliente||"—")}</strong></div>
        <div class="agenda-detail-line"><span><i data-lucide="map-pin"></i></span><small>Sede / dirección</small><strong>${esc(location)}</strong></div>
        <div class="agenda-detail-line"><span><i data-lucide="wrench"></i></span><small>Servicio</small><strong>${esc(order.servicio||"—")}</strong></div>
        <div class="agenda-detail-line"><span><i data-lucide="clock-3"></i></span><small>Atención</small><strong>${esc(agendaMinuteText(minute))}${state.agenda.draft.has(Number(order.id))?" · Cambio sin guardar":""}</strong></div>
        <div class="agenda-detail-line"><span><i data-lucide="users"></i></span><small>Cuadrilla</small><strong>${Number(order.integrantes||1)} integrante${Number(order.integrantes||1)===1?"":"s"}${order.encargado?` · ${esc(order.encargado)}`:""}</strong></div>
      </div>
      ${movable?`<button class="btn" type="button" data-action="planificar-agenda" data-id="${order.id}">Planificar fecha / cuadrilla</button><div class="agenda-shift"><button class="btn small" type="button" data-agenda-shift="-15" data-id="${order.id}"><i data-lucide="chevron-left"></i>15 min</button><strong>Ajuste rápido</strong><button class="btn small" type="button" data-agenda-shift="15" data-id="${order.id}">15 min<i data-lucide="chevron-right"></i></button></div>`:""}
      <div class="agenda-detail-actions">
        <button class="btn primary" type="button" data-action="ver-orden" data-id="${order.id}"><i data-lucide="external-link"></i> Ver OT</button>
        <button class="btn" type="button" data-action="ver-orden" data-id="${order.id}"><i data-lucide="activity"></i> Seguimiento</button>
        ${state.role==="COORDINADOR"&&movable?`<button class="btn" type="button" data-action="asignar-tecnico" data-id="${order.id}"><i data-lucide="users-round"></i> Cuadrilla</button><button class="btn" type="button" data-action="cotizar-orden" data-id="${order.id}"><i data-lucide="file-text"></i> Cotización</button>`:""}
      </div>
    </div>`;
  }

  function agendaRenderDetail(orderId) {
    state.agenda.selectedOrderId=Number(orderId)||null;
    content.querySelectorAll(".agenda-job.selected").forEach(x=>x.classList.remove("selected"));
    if(state.agenda.selectedOrderId)content.querySelectorAll(`[data-agenda-order="${CSS.escape(String(state.agenda.selectedOrderId))}"]`).forEach(x=>x.classList.add("selected"));
    const detail=content.querySelector("#agendaDetail");if(detail)detail.innerHTML=agendaDetailHtml(agendaOrder(state.agenda.selectedOrderId));
    window.lucide?.createIcons();
    agendaBindDetailControls();
  }

  function agendaMobileRoute(data) {
    const isCoordinator = state.role === "COORDINADOR";
    const source = isCoordinator
      ? (data.tecnicos || []).filter(t=>{
          const selected=state.agenda.technicianFilter==="TODOS"||String(t.id)===String(state.agenda.technicianFilter);
          if(!selected)return false;
          if(state.agenda.technicianFilter!=="TODOS")return true;
          return state.agenda.showAllStaff || (t.ordenes||[]).length>0;
        }).flatMap(tech => (tech.ordenes || []).map(order => ({ ...order, _tecnico: tech.nombre || "Sin técnico" })))
      : (((data.tecnicos || [])[0]?.ordenes || []).map(order => ({ ...order, _tecnico: "" })));
    const seen=new Set();
    const orders = source.filter(o=>{if(seen.has(o.id)||state.agenda.onlyEmergencies&&!agendaEmergency(o))return false;seen.add(o.id);return true;}).sort((a,b)=>{
      const av=String(a.estado_codigo||"")==="EN_PROCESO"?-1:(agendaCurrentMinute(a)??9999);
      const bv=String(b.estado_codigo||"")==="EN_PROCESO"?-1:(agendaCurrentMinute(b)??9999);
      return (av===-1?0:1)-(bv===-1?0:1) || Number(agendaEmergency(b))-Number(agendaEmergency(a)) || av-bv;
    });
    const title = isCoordinator ? "Agenda del día" : "Mi ruta de trabajo";
    const description = isCoordinator
      ? `${esc(agendaDateLabel(data.fecha))}. Vista móvil de las órdenes visibles por horario.`
      : `${esc(agendaDateLabel(data.fecha))}. Presiona una orden para abrir su detalle.`;
    return `<section class="agenda-route-mobile"><h3>${title}</h3><p>${description}</p><div class="agenda-route-list">${orders.length?orders.map((o,i)=>`<article class="agenda-route-card ${agendaOrderClass(o)}"><span class="agenda-route-number">${String(o.estado_codigo||"").toUpperCase()==="EN_PROCESO"?"AH":String(i+1).padStart(2,"0")}</span><div class="agenda-route-copy"><strong>${esc(o.numero||`OT-${o.id}`)} · ${esc(o.servicio||"Servicio")}</strong><span>${esc(o.cliente||"—")} · ${esc(o.sede||o.municipio||"—")}${o._tecnico?` · ${esc(o._tecnico)}`:""}</span></div><div class="agenda-route-time"><strong>${esc(agendaMinuteText(agendaCurrentMinute(o)))}</strong><small>${esc(o.estado_visual||o.estado||"")}</small></div><button class="btn small" type="button" data-action="ver-orden" data-id="${o.id}"><i data-lucide="external-link"></i> Abrir OT</button>${state.role==="COORDINADOR"&&["PENDIENTE","PROGRAMADA"].includes(o.estado_codigo)?button("Planificar","planificar-agenda",o.id):""}</article>`).join(""):`<div class="agenda-no-data"><span><i data-lucide="calendar-check"></i></span><h3>Ruta libre</h3><p>No hay órdenes visibles para este día.</p></div>`}</div></section>`;
  }

  function agendaPaint() {
    if(!state.agenda.data)return;
    const data=JSON.parse(JSON.stringify(state.agenda.data));
    for(const [id,draft] of state.agenda.draft){
      const source=data.tecnicos.find(t=>Number(t.id)===draft.source),target=data.tecnicos.find(t=>Number(t.id)===draft.target);
      if(source&&target&&source!==target){const order=source.ordenes.find(o=>Number(o.id)===id);if(order){source.ordenes=source.ordenes.filter(o=>Number(o.id)!==id);target.ordenes.push(order);}}
    }
    const win=agendaWindow(data),hourCount=Math.ceil((win.end-win.start)/60),trackWidth=hourCount*win.hourWidth;
    let technicians=(data.tecnicos||[]).filter(t=>state.agenda.technicianFilter==="TODOS"||String(t.id)===String(state.agenda.technicianFilter));
    if(state.role==="COORDINADOR" && state.agenda.technicianFilter==="TODOS" && !state.agenda.showAllStaff){
      technicians=technicians.filter(t=>(t.ordenes||[]).length>0);
    }
    if(state.agenda.onlyEmergencies)technicians=technicians.filter(t=>(t.ordenes||[]).some(agendaEmergency));
    const visibleOrders=technicians.flatMap(t=>(t.ordenes||[]).filter(o=>!state.agenda.onlyEmergencies||agendaEmergency(o)));
    const visibleIds=new Set(visibleOrders.map(o=>Number(o.id)));
    if(state.agenda.selectedOrderId&&!visibleIds.has(Number(state.agenda.selectedOrderId)))state.agenda.selectedOrderId=visibleOrders[0]?Number(visibleOrders[0].id):null;
    const techOptions=(data.tecnicos||[]).map(t=>`<option value="${t.id}" ${String(state.agenda.technicianFilter)===String(t.id)?"selected":""}>${esc(t.nombre)}</option>`).join("");
    const hours=Array.from({length:hourCount},(_,i)=>win.start/60+i);
    const rows=technicians.map(tech=>{
      const orders=(tech.ordenes||[]).filter(o=>!state.agenda.onlyEmergencies||agendaEmergency(o));
      return `<div class="agenda-tech">${agendaTechnicianCell(tech)}</div><div class="agenda-track" data-agenda-tech="${tech.id}">${agendaNowLine(win)}${orders.length?orders.map(o=>agendaJobCard(o,win)).join(""):`<span class="agenda-empty-track">Sin trabajos programados en esta vista.</span>`}</div>`;
    }).join("");
    const summary=data.resumen||{};
    const selected=agendaOrder(state.agenda.selectedOrderId);
    content.innerHTML=`<div class="agenda-shell agenda-role-${String(state.role||"").toLowerCase()}">
      <section class="agenda-command"><div class="agenda-command-copy"><div><h2>${state.role==="TECNICO"?"Mi agenda de trabajo":"Agenda operativa"}</h2><p>${state.role==="TECNICO"?"Tu trabajo actual, la siguiente orden y lo que queda en cola, todo en una sola vista.":"Planifica la secuencia de atención. Los bloques se mueven primero en pantalla y la base de datos cambia únicamente al guardar."}</p></div></div><div class="agenda-command-actions">
        <button class="btn" id="agendaTodayButton" type="button"><i data-lucide="locate-fixed"></i> Hoy</button>
        ${state.role==="COORDINADOR"?`<button class="btn" id="agendaResetButton" type="button" ${state.agenda.dirty?"":"disabled"}><i data-lucide="rotate-ccw"></i> Restablecer</button><button class="btn primary agenda-save" id="agendaSaveButton" type="button" ${state.agenda.dirty?"":"disabled"}><i data-lucide="save"></i> Guardar planificación</button>`:""}
      </div></section>
      <section class="agenda-summary">
        ${state.role==="TECNICO"?(()=>{const tech=(data.tecnicos||[])[0]||{};return `<article class="agenda-summary-card"><small>Órdenes del día</small><strong>${Number(summary.ordenes||0)}</strong><span>${esc(agendaDateLabel(data.fecha))}</span></article><article class="agenda-summary-card live"><small>Ahora</small><strong>${Number(summary.en_servicio||0)}</strong><span>${summary.en_servicio?"Servicio en ejecución":"Sin servicio iniciado"}</span></article><article class="agenda-summary-card"><small>En cola</small><strong>${Number(tech.cola_cantidad||0)}</strong><span>Trabajos pendientes de atención</span></article><article class="agenda-summary-card alert"><small>Emergencias</small><strong>${Number(summary.emergencias||0)}</strong><span>Prioridad de tu ruta</span></article><article class="agenda-summary-card pending"><small>Sin hora</small><strong>${Number(summary.sin_hora||0)}</strong><span>Pendientes de programación</span></article>`})():`<article class="agenda-summary-card"><small>Personal técnico</small><strong>${Number(summary.tecnicos||0)}</strong><span>Supervisor y operarios habilitados</span></article><article class="agenda-summary-card"><small>Órdenes visibles</small><strong>${Number(summary.ordenes||0)}</strong><span>${esc(agendaDateLabel(data.fecha))}</span></article><article class="agenda-summary-card live"><small>En servicio</small><strong>${Number(summary.en_servicio||0)}</strong><span>Trabajos actualmente iniciados</span></article><article class="agenda-summary-card alert"><small>Emergencias</small><strong>${Number(summary.emergencias||0)}</strong><span>Prioridad operativa inmediata</span></article><article class="agenda-summary-card pending"><small>Sin hora</small><strong>${Number(summary.sin_hora||0)}</strong><span>Asignadas pendientes de programación</span></article>`}
      </section>
      <section class="agenda-tools">
        <div class="agenda-tool-field"><label>Fecha</label><input id="agendaDateInput" type="date" value="${esc(data.fecha)}"></div>
        ${state.role==="COORDINADOR"?`<div class="agenda-tool-field"><label>Técnico / supervisor</label><select id="agendaTechnicianFilter"><option value="TODOS">Todos</option>${techOptions}</select></div><button class="btn agenda-staff-toggle ${state.agenda.showAllStaff?"active":""}" id="agendaStaffToggle" type="button"><i data-lucide="${state.agenda.showAllStaff?"users":"briefcase-business"}"></i>${state.agenda.showAllStaff?"Solo con trabajo":"Mostrar todo el personal"}</button>`:`<div class="agenda-tool-field"><label>Vista</label><select disabled><option>Mi ruta asignada</option></select></div>`}
        <div class="agenda-tools-meta">
          <div class="agenda-live-legend"><span class="agenda-legend-item"><i class="agenda-legend-dot live"></i>En servicio</span><span class="agenda-legend-item"><i class="agenda-legend-dot"></i>Programado</span><span class="agenda-legend-item"><i class="agenda-legend-dot emergency"></i>Emergencia</span><span class="agenda-legend-item"><i class="agenda-legend-dot queue"></i>En cola</span></div>
          <label class="agenda-switch"><input id="agendaEmergencyOnly" type="checkbox" ${state.agenda.onlyEmergencies?"checked":""}><span>Solo emergencias</span></label>
        </div>
      </section>
      <div class="agenda-dirty-bar" id="agendaDirtyBar" ${state.agenda.dirty?"":"hidden"}><i data-lucide="circle-alert"></i><span><strong><span id="agendaDirtyCount">${state.agenda.draft.size}</span> cambio(s) sin guardar.</strong> Podés seguir moviendo bloques; nada se escribe en la base hasta pulsar Guardar planificación.</span></div>
      ${agendaMobileRoute(data)}
      <div class="agenda-planner-layout">
        <section class="agenda-board-card"><div class="agenda-board-head"><div><strong>Orden de atención por técnico</strong><small>Arrastra para cambiar hora o integrante. También puedes usar Planificar. Las órdenes ya iniciadas quedan bloqueadas.</small></div><span class="agenda-board-hint"><i data-lucide="move-horizontal"></i>${state.role==="COORDINADOR"?"Arrastra · revisa · guarda":"Vista de solo lectura"}</span></div>
          <div class="agenda-board-scroll" id="agendaBoardScroll"><div class="agenda-grid" data-start-minute="${win.start}" data-hour-width="${win.hourWidth}" style="--agenda-track-width:${trackWidth}px;--agenda-hour-width:${win.hourWidth}px;--agenda-hour-count:${hourCount}">
            <div class="agenda-corner">Técnico / cuadrilla</div><div class="agenda-hours">${hours.map(h=>`<span class="agenda-hour">${String(h).padStart(2,"0")}:00</span>`).join("")}</div>
            ${rows||`<div class="agenda-tech"></div><div class="agenda-no-data"><span><i data-lucide="calendar-x"></i></span><h3>Sin resultados</h3><p>No hay personal con órdenes para los filtros seleccionados.</p></div>`}
          </div></div>
        </section>
        <aside class="agenda-detail" id="agendaDetail">${agendaDetailHtml(selected)}</aside>
      </div>
    </div>`;
    window.lucide?.createIcons();
    agendaBindControls();agendaBindDrag();agendaBindDetailControls();
    requestAnimationFrame(()=>{
      const scroller=content.querySelector("#agendaBoardScroll");if(!scroller)return;
      const target=selected?agendaDisplayMinute(selected):(data.fecha===data.hoy?(()=>{const n=new Date(data.ahora);return n.getHours()*60+n.getMinutes();})():18*60);
      scroller.scrollLeft=Math.max(0,(target-win.start)/60*win.hourWidth-250);
    });
  }

  function agendaBindDetailControls() {
    content.querySelectorAll("[data-agenda-shift]").forEach(btn=>btn.addEventListener("click",()=>{
      const order=agendaOrder(btn.dataset.id);if(!order)return;
      const base=agendaDisplayMinute(order),delta=Number(btn.dataset.agendaShift||0);
      agendaSetDirtyMinute(order.id,base+delta);
    }));
  }

  function agendaConfirmDiscard() {
    return !state.agenda.dirty || window.confirm("Hay cambios de planificación sin guardar. ¿Deseas descartarlos?");
  }

  function agendaBindControls() {
    const dateInput=content.querySelector("#agendaDateInput");
    const changeDay=async next=>{if(!agendaConfirmDiscard())return;state.agenda.fecha=next;state.agenda.draft.clear();state.agenda.dirty=false;state.agenda.selectedOrderId=null;await renderAgendaOperativa();};
    content.querySelector("#agendaTodayButton")?.addEventListener("click",()=>changeDay(state.agenda.data?.hoy||new Date().toISOString().slice(0,10)));
    dateInput?.addEventListener("change",()=>changeDay(dateInput.value));
    content.querySelector("#agendaTechnicianFilter")?.addEventListener("change",e=>{state.agenda.technicianFilter=e.currentTarget.value||"TODOS";agendaPaint();});
    content.querySelector("#agendaStaffToggle")?.addEventListener("click",()=>{state.agenda.showAllStaff=!state.agenda.showAllStaff;agendaPaint();});
    content.querySelector("#agendaEmergencyOnly")?.addEventListener("change",e=>{state.agenda.onlyEmergencies=Boolean(e.currentTarget.checked);agendaPaint();});
    content.querySelector("#agendaResetButton")?.addEventListener("click",()=>{if(!state.agenda.dirty)return;state.agenda.draft.clear();state.agenda.dirty=false;agendaPaint();showToast("Cambios visuales descartados.","info");});
    content.querySelector("#agendaSaveButton")?.addEventListener("click",async()=>{
      if(!state.agenda.dirty||!state.agenda.draft.size)return;
      const button=content.querySelector("#agendaSaveButton");button.disabled=true;
      try{
        const cambios=[...state.agenda.draft.entries()].map(([orden_id,draft])=>({orden_id,programada_para:agendaDateTimePayload(draft.day,draft.minute),programada_original:agendaOrder(orden_id)?.programada_version??null,empleado_origen:draft.source,empleado_destino:draft.target}));
        const result=await api("/api/agenda-operativa/guardar",{method:"POST",body:{fecha:state.agenda.fecha,cambios}});
        showToast(result.message||"Planificación actualizada.");
        state.agenda.draft.clear();state.agenda.dirty=false;await renderAgendaOperativa();
      }catch(err){state.agenda.draft.clear();state.agenda.dirty=false;await renderAgendaOperativa();showToast(err.message,"error");}
    });
  }

  function agendaBindDrag(){
    if(state.role!=='COORDINADOR')return;
    const grid=content.querySelector('.agenda-grid');if(!grid)return;
    const hourWidth=Number(grid.dataset.hourWidth||112);
    content.querySelectorAll('.agenda-job[data-agenda-draggable="1"]').forEach(card=>{
      card.addEventListener('pointerdown',event=>{
        if(event.button!==0)return;
        const id=Number(card.dataset.agendaOrder),order=agendaOrder(id),original=state.agenda.draft.get(id),base=agendaDisplayMinute(order),source=Number(card.closest('[data-agenda-tech]')?.dataset.agendaTech),x=event.clientX,y=event.clientY;let moved=false;
        card.setPointerCapture?.(event.pointerId);card.dataset.agendaDragging='1';
        const move=ev=>{if(Math.abs(ev.clientX-x)+Math.abs(ev.clientY-y)>5)moved=true;if(!moved)return;ev.preventDefault();agendaSetDirtyMinute(id,base+(ev.clientX-x)/hourWidth*60);card.style.transform=`translateY(${ev.clientY-y}px)`;};
        const finish=ev=>{
          card.releasePointerCapture?.(event.pointerId);card.removeAttribute('data-agenda-dragging');card.removeEventListener('pointermove',move);card.removeEventListener('pointerup',finish);card.removeEventListener('pointercancel',finish);
          if(!moved){agendaRenderDetail(id);return;}
          const track=[...content.querySelectorAll('[data-agenda-tech]')].find(t=>{const r=t.getBoundingClientRect();return ev.clientY>=r.top&&ev.clientY<=r.bottom;});
          const target=Number(track?.dataset.agendaTech),person=state.agenda.data.tecnicos.find(t=>Number(t.id)===target);
          if(ev.type==='pointercancel'||!person||['VACACIONES','INACTIVO','NO_DISPONIBLE'].includes(person.disponibilidad)){
            if(original)state.agenda.draft.set(id,original);else state.agenda.draft.delete(id);showToast('Destino no disponible; se restauró la posición.','error');
          }else{
            const draft=state.agenda.draft.get(id)||{minute:base,day:state.agenda.fecha};draft.source=original?.source||source;draft.target=target;state.agenda.draft.set(id,draft);
          }
          state.agenda.dirty=state.agenda.draft.size>0;agendaPaint();
        };
        card.addEventListener('pointermove',move);card.addEventListener('pointerup',finish);card.addEventListener('pointercancel',finish);
      });
    });
  }

  async function renderAgendaOperativa() {
    if(!["COORDINADOR","TECNICO"].includes(state.role))return navigate("dashboard");
    setHeading(state.role==="COORDINADOR"?"Agenda operativa":"Mi agenda","Orden visual de atención, trabajos en curso y cola operativa por horario.");
    if(historicalDate() && !state.agenda.dirty) state.agenda.fecha=historicalDate();
    if(!state.agenda.fecha){
      const now=new Date(),z=n=>String(n).padStart(2,"0");
      state.agenda.fecha=new Intl.DateTimeFormat("en-CA",{timeZone:"America/Guatemala",year:"numeric",month:"2-digit",day:"2-digit"}).format(now);
    }
    const data=await api(`/api/agenda-operativa?fecha=${encodeURIComponent(state.agenda.fecha)}`);
    state.agenda.data=data;state.agenda.fecha=data.fecha;
    state.agenda.draft.clear();state.agenda.dirty=false;
    const all=agendaAllOrders(data);
    if(!state.agenda.selectedOrderId||!all.has(Number(state.agenda.selectedOrderId))){
      const first=[...all.values()].sort((a,b)=>{
        const ar=String(a.estado_codigo||"").toUpperCase()==="EN_PROCESO"?0:1,br=String(b.estado_codigo||"").toUpperCase()==="EN_PROCESO"?0:1;
        if(ar!==br)return ar-br;
        return agendaDisplayMinute(a)-agendaDisplayMinute(b);
      })[0];
      state.agenda.selectedOrderId=first?Number(first.id):null;
    }
    agendaPaint();
  }

  async function renderSolicitudes(isCurrent = () => true) {
    const all=filterSelectedDate("solicitudes",(await loadAllPaged("solicitudes","/api/solicitudes")).items);
    if (!isCurrent()) return;
    if (state.role !== "COORDINADOR") {
      setHeading("Solicitudes de servicio", state.role === "CLIENTE" ? "Crea una solicitud, adjunta imágenes y consulta su estado." : "Recepción de solicitudes programadas y emergencias.");
      const states=listFacet(state.current,"estado",smartUnique(all,x=>String(x.Estado||x.estado||"").toUpperCase()));
      const classes=smartUnique(all,x=>String(x.Clasificacion||x.clasificacion||"").toUpperCase());
      const urgencies=smartUnique(all,x=>String(x.urgencia||"").toUpperCase());
      const result=smartListData("solicitudes",all,{
        defaults:{orden:"creada",direccion:"DESC"},
        search:x=>[x.id,x.cliente,x.sede,x.tipo,x.descripcion,x.ticket,x.Estado,x.estado,x.orden_numero],
        filters:{estado:x=>String(x.Estado||x.estado||"").toUpperCase(),clase:x=>String(x.Clasificacion||x.clasificacion||"").toUpperCase(),urgencia:x=>String(x.urgencia||"").toUpperCase()},
        sort:{creada:x=>smartDateValue(x.creada),cliente:x=>x.cliente||"",estado:x=>String(x.Estado||x.estado||""),tipo:x=>x.tipo||""}
      });
      const rows=result.items.map(x => `<tr>
        <td><div class="se-cell-stack"><strong class="mono">#${esc(x.id)}</strong><span class="se-cell-muted">${fmt(x.creada)}</span></div></td>
        <td><div class="se-cell-stack"><strong>${esc(x.cliente || "Sin cliente")}</strong><span class="se-cell-muted">${esc(x.sede || "Sin sede")}</span></div></td>
        <td><div class="se-description" title="${esc(requestDescriptionPreview(x.descripcion))}">${esc(requestDescriptionPreview(x.descripcion))}</div></td>
        <td><div class="se-cell-stack"><strong>${esc(x.tipo || "—")}</strong>${requestClassBadge(x.Clasificacion||x.clasificacion)}</div></td>
        <td>${x.urgencia?requestUrgencyBadge(x.urgencia):"—"}</td>
        <td>${requestStatusView(x)}</td>
        <td class="se-table-actions">${button("Ver seguimiento","ver-solicitud",x.id,"primary")+(state.role==="CLIENTE"&&!x.solo_lectura&&!x.orden_id&&String(x.estado||x.Estado)!=="CANCELADA"?button("Solicitar cancelación","solicitar-cancelacion","SolicitudServicio:"+x.id):"")}</td>
      </tr>`);
      content.innerHTML = `<div class="toolbar"><div class="toolbar-left"><h2>Solicitudes</h2><p class="muted">Búsqueda y filtros disponibles para ${state.role==="CLIENTE"?"tus solicitudes":"todas las solicitudes visibles"}.</p></div><div class="toolbar-right">${button("Nueva solicitud","nueva-solicitud","","primary")}</div></div><section class="panel smart-list-panel"><div class="panel-body">${smartControls("solicitudes",{placeholder:"ID, cliente, sede, servicio o descripción",filters:[{name:"estado",label:"Estado",options:states},{name:"clase",label:"Clase",options:classes},{name:"urgencia",label:"Urgencia",options:urgencies}],sorts:[["creada","Fecha"],["cliente","Cliente"],["tipo","Servicio"],["estado","Estado"]]})}${smartResultsMeta(result,"solicitudes")}</div>${table(["Solicitud","Cliente / sede","Descripción","Servicio","Urgencia","Estado y seguimiento","Acción"], rows,"No hay solicitudes que coincidan con los filtros.")}${smartPager("solicitudes",result)}</section>`;
      window.lucide?.createIcons();
      return;
    }

    eyebrow.textContent = "SEPRIGUA · OPERACIÓN";
    title.textContent = "Solicitudes de servicio";
    subtitle.textContent = "Gestiona, filtra y da seguimiento a las solicitudes recibidas.";
    syncPrototypeChrome();

    let warrantyRequests=[];
    try{const warrantyData=await api('/api/garantias');warrantyRequests=(warrantyData.solicitudes||[]).filter(x=>['PENDIENTE','EN_REVISION','PENDIENTE_AUTORIZACION','AUTORIZADA_CLIENTE','GARANTIA_APROBADA'].includes(String(x.estado||'').toUpperCase()));state.warrantyRequests=warrantyData.solicitudes||[];state.warranties=warrantyData.items||[];}catch(_err){warrantyRequests=[];}

    const states=listFacet(state.current,"estado",smartUnique(all,x=>String(x.Estado||x.estado||"").toUpperCase()));
    const classes=smartUnique(all,x=>String(x.Clasificacion||x.clasificacion||"").toUpperCase());
    const urgencies=smartUnique(all,x=>String(x.urgencia||"").toUpperCase());
    const sites=smartUnique(all,x=>String(x.sede||"").trim());
    const defaults={orden:"creada",direccion:"DESC",tamano:10,filtros:{rapidos:["TODAS"]}};
    const prefs=smartPrefs("solicitudes",defaults);
    if(!prefs.filtros) prefs.filtros={};
    const selectedQuickKeys = normalizeQuickFilters(prefs.filtros.rapidos || prefs.filtros.rapido || "TODAS");
    prefs.filtros.rapidos = selectedQuickKeys;
    prefs.filtros.rapido = selectedQuickKeys[0] || "TODAS";
    const originalQuick = [...selectedQuickKeys];
    prefs.filtros.rapidos = ["TODAS"];
    prefs.filtros.rapido = "TODAS";
    const baseResult=smartListData("solicitudes",all,{
      defaults,
      search:x=>[x.id,x.cliente,x.sede,x.tipo,x.descripcion,x.ticket,x.Estado,x.estado,x.orden_numero],
      filters:{
        estado:x=>String(x.Estado||x.estado||"").toUpperCase(),
        clase:x=>String(x.Clasificacion||x.clasificacion||"").toUpperCase(),
        urgencia:x=>String(x.urgencia||"").toUpperCase(),
        sede:x=>String(x.sede||"")
      },
      sort:{creada:x=>smartDateValue(x.creada),cliente:x=>x.cliente||"",tipo:x=>x.tipo||"",estado:x=>requestStateValue(x),urgencia:x=>requestUrgencyValue(x),sede:x=>x.sede||""}
    });
    prefs.filtros.rapidos = originalQuick;
    prefs.filtros.rapido = originalQuick[0] || "TODAS";
    let filtered = [...baseResult.filtered];
    const quickFiltersToApply = originalQuick.filter(key => key && key !== "TODAS");
    if (quickFiltersToApply.length) filtered = filtered.filter(item => quickFiltersToApply.some(key => requestQuickMatches(item, key)));
    const size = Math.max(5, Number(prefs.tamano || 10));
    const total = filtered.length;
    const pages = Math.max(1, Math.ceil(total / size));
    prefs.pagina = Math.min(Math.max(1, Number(prefs.pagina || 1)), pages);
    const start = (prefs.pagina - 1) * size;
    const result = { items: filtered.slice(start, start + size), filtered, total, pagina: prefs.pagina, tamano: size, paginas: pages };

    const quicks=requestQuickDefinitions(all);
    const activeQuickSet = new Set(normalizeQuickFilters(prefs.filtros.rapidos || prefs.filtros.rapido || "TODAS"));
    const quickMarkup=quicks.length>1?`<div class="request-quick-row"><span class="request-quick-label">Filtros rápidos:</span><div class="request-quick-filters">${quicks.map(item=>`<button class="request-quick-pill ${activeQuickSet.has(item.key)?"active":""} ${item.tone}" type="button" data-action="request-quick-filter" data-list-key="solicitudes" data-value="${esc(item.key)}"><span>${esc(item.label)}</span><strong>${item.count}</strong></button>`).join("")}</div><span class="request-quick-hint">Puedes elegir uno o varios.</span></div>`:"";
    const activeFiltersMarkup=requestActiveFilterChips(prefs);

    const rows=result.items.map(x => `
      <tr>
        <td class="request-identity-cell"><div class="se-cell-stack"><strong class="mono request-id-cell">#${esc(x.id)}</strong>${requestDateMarkup(x.creada)}</div></td>
        <td><div class="request-client-cell">${entityAvatarLink(x.cliente || "Sin cliente",{entity:x,subtitle:x.sede || "Sin sede"},"ver-solicitud",x.id)}</div></td>
        <td><div class="request-description-cell se-description" title="${esc(requestDescriptionPreview(x.descripcion))}">${esc(requestDescriptionPreview(x.descripcion))}</div></td>
        <td><div class="request-service-cell se-cell-stack"><strong>${esc(x.tipo || "—")}</strong></div></td>
        <td>${x.urgencia ? requestUrgencyBadge(x.urgencia) : `<span class="request-empty-pill">No aplica</span>`}</td>
        <td><div class="se-cell-stack">${requestFollowupMarkup(x)}</div></td>
        <td class="se-table-actions"><button class="request-follow-button" type="button" data-action="ver-solicitud" data-id="${esc(x.id)}" aria-label="Ver seguimiento de solicitud #${esc(x.id)}"><i data-lucide="eye"></i><span>Ver</span></button></td>
      </tr>`);

    if (!isCurrent()) return;
    const filtersPanel = `
      <section class="solicitudes-filter-panel">
        <div class="solicitudes-filter-grid">
          <div class="solicitudes-filter-field solicitudes-search-field">
            <label>Buscar</label>
            <div class="input-with-icon solicitudes-search-input">
              <i data-lucide="search"></i>
              <input type="search" data-smart-q="solicitudes" value="${esc(prefs.q || "")}" placeholder="Buscar por solicitud, cliente, sede o responsable..." autocomplete="off">
            </div>
          </div>
          <div class="solicitudes-filter-field"><label>Estado</label><select data-smart-filter="estado" data-smart-key="solicitudes">${smartOptions(states, prefs.filtros?.estado, "Todos")}</select></div>
          <div class="solicitudes-filter-field"><label>Clase</label><select data-smart-filter="clase" data-smart-key="solicitudes">${smartOptions(classes, prefs.filtros?.clase, "Todos")}</select></div>
          <div class="solicitudes-filter-field"><label>Urgencia</label><select data-smart-filter="urgencia" data-smart-key="solicitudes">${smartOptions(urgencies, prefs.filtros?.urgencia, "Todos")}</select></div>
          <div class="solicitudes-filter-field"><label>Sede</label><select data-smart-filter="sede" data-smart-key="solicitudes">${smartOptions(sites, prefs.filtros?.sede, "Todas")}</select></div>
          <div class="solicitudes-filter-field solicitudes-filter-clear"><label>&nbsp;</label><button class="request-clear-button" type="button" data-action="smart-reset" data-list-key="solicitudes"><i data-lucide="rotate-ccw"></i><span>Limpiar</span></button></div>
        </div>
        ${(quickMarkup || activeFiltersMarkup) ? `<div class="solicitudes-filter-extras">${quickMarkup}${activeFiltersMarkup}</div>` : ""}
      </section>`;

    const tableToolbar = `
      <div class="solicitudes-table-toolbar">
        <div class="solicitudes-table-title"><strong>Solicitudes</strong><span>${normalizeNumber(result.total)} resultado${Number(result.total)===1?"":"s"}</span></div>
        <div class="solicitudes-table-controls">
          <div class="solicitudes-filter-field toolbar-field"><label>Ordenar por</label><select data-smart-sort data-smart-key="solicitudes"><option value="creada" ${String(prefs.orden)==="creada"?"selected":""}>Más recientes</option><option value="cliente" ${String(prefs.orden)==="cliente"?"selected":""}>Cliente</option><option value="tipo" ${String(prefs.orden)==="tipo"?"selected":""}>Servicio</option><option value="estado" ${String(prefs.orden)==="estado"?"selected":""}>Estado</option><option value="urgencia" ${String(prefs.orden)==="urgencia"?"selected":""}>Urgencia</option></select></div>
          <div class="solicitudes-filter-field toolbar-field"><label>Dirección</label><select data-smart-direction data-smart-key="solicitudes"><option value="DESC" ${String(prefs.direccion||"DESC")==="DESC"?"selected":""}>Descendente</option><option value="ASC" ${String(prefs.direccion||"DESC")==="ASC"?"selected":""}>Ascendente</option></select></div>
          <div class="solicitudes-filter-field toolbar-field solicitudes-size-field"><label>Mostrar</label><select data-smart-size data-smart-key="solicitudes">${[10,20,50].map(n=>`<option value="${n}" ${Number(prefs.tamano||10)===n?"selected":""}>${n} por página</option>`).join("")}</select></div>
        </div>
      </div>`;

    const empty = "No hay solicitudes que coincidan con los filtros seleccionados.";
    const tableHtml = table(["Solicitud","Cliente / sede","Descripción","Servicio","Urgencia","Seguimiento","Acción"], rows, empty);
    const warrantyPanel=warrantyRequests.length?`<section class="request-warranty-panel request-warranty-strip" aria-label="Garantías pendientes"><div class="request-warranty-head"><span class="request-warranty-message"><i data-lucide="shield-alert" aria-hidden="true"></i><span><strong>Garantías pendientes:</strong> ${warrantyRequests.length} ${warrantyRequests.length===1?'solicitud de garantía por gestionar':'solicitudes de garantía por gestionar'}.</span></span><button class="btn" type="button" data-action="dashboard-ver-garantias">Ver garantías <i data-lucide="arrow-right" aria-hidden="true"></i></button></div><details class="request-warranty-details"><summary>Ver solicitudes pendientes</summary><div class="request-warranty-list">${warrantyRequests.slice(0,5).map(x=>`<article><span class="request-warranty-icon"><i data-lucide="shield-alert"></i></span><div><strong>${esc(x.numero_orden)} · ${esc(x.cliente)}</strong><span>${esc(x.sede||'Sede')} · ${esc(x.tipo_servicio||'Servicio')}</span><small>${esc(x.descripcion||'')}</small></div>${badge(x.estado)}<button class="btn small primary" type="button" data-action="estado-solicitud-garantia" data-id="${esc(x.solicitud_garantia_id)}">Gestionar</button></article>`).join('')}</div>${warrantyRequests.length>5?`<div class="request-warranty-more">+ ${warrantyRequests.length-5} solicitud(es) adicionales en el módulo de Garantías.</div>`:''}</details></section>`:'';

    content.innerHTML = `
      <section class="solicitudes-workspace">
        <section class="solicitudes-sheet">
          <div class="solicitudes-hero">
            <div class="solicitudes-hero-copy">
              <h2>Solicitudes de servicio</h2>
              <p>Gestiona, filtra y da seguimiento a las solicitudes recibidas.</p>
              <div class="solicitudes-update-line"><span class="solicitudes-update-dot"></span><span>Última actualización: ${esc(formatGTTime(new Date()))}</span></div>
            </div>
            <div class="solicitudes-hero-actions">
              <button class="request-primary-button" type="button" data-action="nueva-solicitud"><i data-lucide="plus"></i><span>Nueva solicitud</span></button>
            </div>
          </div>
          ${warrantyPanel}
          ${filtersPanel}
          <section class="solicitudes-table-panel">
            ${tableToolbar}
            ${tableHtml}
            ${requestPager("solicitudes", result)}
          </section>
        </section>
      </section>`;
    window.lucide?.createIcons();
  }


  function requestStatusView(x) {
    if(x.orden_id){
      const orderState=String(x.orden_estado||x.orden_estado_codigo||"").trim();
      return `<div>${badge("OT CREADA")}<br><span class="muted mono">${esc(x.orden_numero||`OT #${x.orden_id}`)}</span>${orderState?`<br><span class="muted">${esc(orderState)}</span>`:""}</div>`;
    }
    return badge(String(x.Estado||x.estado||"REGISTRADA").toUpperCase());
  }

  function requestFollowupView(x) {
    const steps=[
      {label:"Solicitud registrada",done:true,detail:fmt(x.creada)},
      {label:"Orden de trabajo creada",done:!!x.orden_id,detail:x.orden_id?`${x.orden_numero||`OT #${x.orden_id}`} · ${x.orden_estado||"En seguimiento"}`:"Pendiente de coordinación"},
      {label:"Cotización vinculada",done:!!x.cotizacion_id,detail:x.cotizacion_id?`${x.cotizacion_numero||`Cotización #${x.cotizacion_id}`} · ${x.cotizacion_estado||""}`:"Se genera cuando corresponda, antes o después del servicio"}
    ];
    return `<ol class="se-detail-timeline">${steps.map(s=>`<li class="${s.done?'is-complete':'is-pending'}"><strong>${esc(s.label)}</strong><span>${esc(s.detail||"")}</span></li>`).join("")}</ol>`;
  }

  function evidenceCard(e) {
    const isImage = String(e.tipo || "").toUpperCase() === "FOTO";
    return `<div class="evidence-card">${isImage?`<a href="${esc(e.ruta)}" target="_blank"><img class="evidence-thumb" src="${esc(e.ruta)}" alt="${esc(e.nombre)}" loading="lazy"></a>`:""}<div class="evidence-meta"><strong>${esc(e.nombre)}</strong><span>${esc(e.categoria || "")} · ${esc(e.etapa || "")}</span>${e.Descripcion||e.descripcion?`<span>${esc(e.Descripcion||e.descripcion)}</span>`:""}<a class="btn small" target="_blank" href="${esc(e.ruta)}">Abrir archivo</a></div></div>`;
  }

  async function openRequest(id) {
    const d = await api(`/api/solicitudes/${id}`), x=d.item;
    const detail=window.SepriguaDetail;
    const evidence=(d.evidencias||[]).map(evidenceCard).join("")||detail.empty('Sin evidencias adjuntas','Todavía no se han agregado imágenes o archivos.','paperclip');
    const canCreate = state.role==="COORDINADOR" && !x.orden_id && !["CANCELADA","CONVERTIDA"].includes(String(x.Estado||x.estado).toUpperCase());
    const classification=displayDetailValue(x.Clasificacion||x.clasificacion);
    openModal(`Solicitud #${x.id}`, `${detail.section('Información de la solicitud',[
      ['Cliente',esc(x.cliente)],
      [!x.solicitante_nombre && x.registrada_por_nombre ? 'Registrada por' : 'Solicitante',esc(x.solicitante_nombre || x.registrada_por_nombre || 'No registrado')],['Sede',esc(x.sede)],['Clasificación',esc(classification)],
      ['Estado',badge(x.orden_id?'Convertida a OT':displayDetailValue(x.Estado||x.estado))],
      ['Urgencia',x.urgencia?badge(x.urgencia):'No aplica'],['Fecha preferida',fmt(x.fecha_preferida)],
      ['Ticket del cliente',esc(x.ticket||'No indicado')],
      ['Ubicación',esc([x.Direccion||x.direccion,x.Municipio||x.municipio].filter(Boolean).join(', ')||x.sede)]
    ])}
    ${detail.prose('Descripción',esc(x.descripcion))}
    ${x.orden_id?detail.notice(`La solicitud continúa como ${esc(x.orden_numero||`OT #${x.orden_id}`)}`,'La solicitud se conserva como origen; el avance operativo continúa en la orden de trabajo.','workflow'):''}
    ${detail.block('Seguimiento',requestFollowupView(x),'route','se-detail-followup')}
    ${detail.block('Evidencias iniciales',`<div class="se-detail-evidence-list">${evidence}</div>`,'paperclip','se-detail-evidence')}
    ${detail.actions(`${x.solo_lectura?"":button("Agregar imagen / archivo","evidencia-solicitud",id)}${x.cotizacion_id?button("Ver cotizaciones","ir-cotizaciones",x.cotizacion_id):""}${canCreate?button("Crear OT","crear-ot-solicitud",id,"primary"):""}${x.orden_id?button("Abrir OT","ver-orden",x.orden_id,"primary"):""}`)}`, {detailHeader:{kicker:`Solicitud #${x.id}`,title:x.tipo||'Solicitud de servicio',meta:`Creada el ${fmt(x.creada)}${x.orden_id?' · Convertida a OT':''}`,status:classification,icon:'wrench'}});
    document.dispatchEvent(new CustomEvent("seprigua:tour-record",{detail:{type:"solicitud",id:Number(id)}}));
  }

  async function uploadEvidenceFiles(url, files, fields) {
    const ids = new Map(), failures = [];
    for (const file of Array.from(files)) {
      const form = new FormData();
      form.append("archivo", file);
      for (const [key, value] of Object.entries(fields)) if (value) form.append(key, value);
      try {
        const result = await api(url, {method:"POST", body:form});
        const id = Number(result.id);
        if (!Number.isSafeInteger(id) || id <= 0) throw new Error("El servidor no confirmó el archivo.");
        // Si dos envíos devuelven el mismo ID, cuenta el archivo una sola vez.
        ids.set(id, ids.get(id) === true || result.duplicada !== true);
      } catch (err) {
        failures.push(`${file.name}: ${err.message}`);
      }
    }
    const guardados = [...ids.values()].filter(Boolean).length;
    return {guardados, existentes:ids.size-guardados, ids:[...ids.keys()], failures};
  }

  function evidenceUploadMessage(result) {
    const parts = [];
    if (result.ids.length) {
      parts.push(`${result.ids.length} ${result.ids.length === 1 ? "archivo disponible" : "archivos disponibles"}.`);
      if (result.existentes) {
        if (result.guardados) parts.push(`${result.guardados} ${result.guardados === 1 ? "nuevo" : "nuevos"}.`);
        parts.push(`${result.existentes} ${result.existentes === 1 ? "ya estaba guardado" : "ya estaban guardados"}.`);
      }
    }
    if (result.failures.length) parts.push(`${result.failures.length} sin subir. ${result.failures[0]}`);
    return parts.join(" ");
  }

  function ensureEvidenceBatch(result) {
    const message = evidenceUploadMessage(result);
    if (result.failures.length) throw new Error(message);
    return message;
  }

  function uploadRequestFiles(solicitudId, files, description="") {
    return uploadEvidenceFiles(`/api/solicitudes/${solicitudId}/evidencias`, files, {descripcion:description});
  }

  async function requestForm() {
    await refreshCatalogs();
    const isCoord = state.role === "COORDINADOR";
    const clients = state.catalogs.clientes || [];
    const types = state.catalogs.tipos_servicio || [];

    openModal("Nueva solicitud", `<form id="requestForm" class="form-grid" autocomplete="off">
      ${isCoord ? `<div class="field"><label>Cliente</label><select name="cliente_id" id="requestClient" required><option value="">Seleccione...</option>${optionList(clients)}</select></div>` : ""}
      <div class="field"><label>Sede / ubicación</label><select name="ubicacion_id" id="requestLocation" required><option value="">${isCoord ? "Seleccione primero un cliente" : "Cargando..."}</option></select>${!isCoord?`<div class="field-helper-action"><span>¿Necesitas otra tienda o sede?</span><button class="btn small" type="button" data-action="ir-mis-sedes">Administrar sedes</button></div>`:""}</div>
      <div class="field"><label>Tipo de servicio</label><select name="tipo_servicio_id" id="requestType" required><option value="">Seleccione...</option>${optionList(types,"id",x=>x.nombre)}</select></div>
      <div class="field"><label>Clasificación</label><select name="clasificacion" id="requestClass" required><option value="">Seleccione...</option><option value="PROGRAMADA">Programada</option><option value="EMERGENCIA">Emergencia</option></select></div>
      <div class="field field-disabled" id="urgencyField"><label>Urgencia <small>(solo emergencia)</small></label><select name="urgencia" id="requestUrgency" disabled><option value="">Seleccione...</option><option value="BAJA">Baja</option><option value="MEDIA">Media</option><option value="ALTA">Alta</option><option value="CRITICA">Crítica</option></select></div>
      ${isCoord ? `<div class="field"><label>Canal</label><select name="canal"><option value="">Seleccione...</option><option value="LLAMADA">Llamada</option><option value="MENSAJE">Mensaje</option><option value="CORREO">Correo</option><option value="OTRO">Otro</option></select></div>` : ""}
      <div class="field"><label>Fecha preferida</label><input type="datetime-local" name="fecha_preferida" autocomplete="off"></div>
      <div class="field"><label>Ticket del cliente <small>(opcional)</small></label><input name="ticket" maxlength="60" placeholder="Ej. número interno de tu empresa"><small>Puedes usar el mismo ticket para varios trabajos.</small></div>
      <div class="field full"><label>Descripción del problema</label><textarea name="descripcion" required placeholder="Describe el trabajo o problema..." autocomplete="off"></textarea></div>
      <div class="field full"><label>Imágenes / archivos de referencia <small>(opcional, varios)</small></label><input type="file" id="requestFiles" multiple accept="image/*,video/mp4,video/quicktime,application/pdf"><div class="inline-actions"><button class="btn small" type="button" id="clearRequestFiles">Quitar archivos</button></div><small>Fotos, videos o PDF. Se guardan como evidencia de la solicitud.</small></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="reset" id="resetRequestForm">Limpiar formulario</button><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Guardar solicitud</button></div></div>
    </form>`);

    async function locations(cid = "") {
      const select = $("#requestLocation");
      select.innerHTML = `<option value="">Cargando...</option>`;
      if (isCoord && !cid) {
        select.innerHTML = `<option value="">Seleccione primero un cliente</option>`;
        return;
      }
      const q = isCoord ? `?cliente_id=${encodeURIComponent(cid)}` : "";
      const d = await api(`/api/ubicaciones${q}`);
      if (!(d.items || []).length) {
        select.innerHTML = `<option value="">Sin ubicaciones disponibles</option>`;
        return;
      }
      select.innerHTML = `<option value="">Seleccione...</option>${optionList(d.items,"id",x=>{
        const name = x.sucursal || x.referencia || "Sede";
        const place = [x.municipio, x.departamento].filter(v=>v && String(v).toUpperCase()!=="PENDIENTE").join(", ");
        const pending = Number(x.ubicacion_pendiente || 0) ? " · dirección pendiente" : "";
        return `${name}${place ? ` · ${place}` : ""}${pending}`;
      })}`;
    }

    const syncUrgency=()=>{
      const emergency=$("#requestClass").value==="EMERGENCIA";
      const urgency=$("#requestUrgency");
      urgency.disabled=!emergency;
      urgency.required=emergency;
      if(!emergency) urgency.value="";
      $("#urgencyField").classList.toggle("field-disabled",!emergency);
    };

    $("#requestClass").addEventListener("change",syncUrgency);
    $("#clearRequestFiles").addEventListener("click",()=>{$("#requestFiles").value="";});

    if (isCoord) {
      $("#requestClient").addEventListener("change", e => locations(e.target.value).catch(err => showToast(err.message,"error")));
    } else {
      await locations();
    }

    $("#requestForm").addEventListener("reset",()=>{
      setTimeout(()=>{
        $("#requestClass").value="";
        $("#requestUrgency").value="";
        $("#requestFiles").value="";
        syncUrgency();
        if(isCoord) locations("");
      },0);
    });

    syncUrgency();

    $("#requestForm").addEventListener("submit", async e => {
      e.preventDefault();
      const form=e.currentTarget, f=new FormData(form), files=$("#requestFiles").files;
      const body=Object.fromEntries([...f.entries()].filter(([k])=>k!=="urgencia" || !$("#requestUrgency").disabled));
      const submit=form.querySelector('button[type="submit"]'); submit.disabled=true; submit.textContent="Guardando...";
      try {
        const result=await api("/api/solicitudes", { method:"POST", body });
        const solicitudId=result.item?.SolicitudServicioId || result.item?.solicitudServicioId || result.item?.id;
        if(solicitudId)document.dispatchEvent(new CustomEvent("seprigua:tour-record",{detail:{type:"solicitud-creada",id:Number(solicitudId)}}));
        if (solicitudId && files.length) ensureEvidenceBatch(await uploadRequestFiles(solicitudId,files,body.descripcion||""));
        showToast(files.length ? "Solicitud e imágenes registradas." : "Solicitud registrada.");
        closeModal(); navigate("solicitudes");
        refreshNotificationBadge(!notificationPopover?.hidden).catch(() => {});
      } catch(err) { showToast(err.message,"error"); submit.disabled=false; submit.textContent="Guardar solicitud"; }
    });
  }

  function techQueueRank(x) {
    const code=String(x.estado_codigo||x.estado||"").toUpperCase();
    if(code==="EN_PROCESO") return 0;
    if(["COMPLETADA","CANCELADA"].includes(code)) return 9e15 + smartDateValue(x.finalizada||x.creada);
    const emergency=String(x.clasificacion||"").toUpperCase()==="EMERGENCIA" ? 0 : 1;
    const p={CRITICA:0,ALTA:1,MEDIA:2,BAJA:3}[String(x.Prioridad||x.prioridad||"").toUpperCase()] ?? 4;
    const when=smartDateValue(x.programada||x.asignado_en||x.creada)||Date.now();
    return 1e12 + emergency*1e11 + p*1e10 + Math.min(Math.floor(when/1000),9e9);
  }

  function technicianQueuePositions(items) {
    const open=(items||[]).filter(x=>!["COMPLETADA","CANCELADA"].includes(String(x.estado_codigo||"").toUpperCase()));
    open.sort((a,b)=>techQueueRank(a)-techQueueRank(b));
    const positions=new Map(); let pending=0;
    open.forEach(x=>{
      const code=String(x.estado_codigo||"").toUpperCase();
      if(code==="EN_PROCESO") positions.set(String(x.id),{label:"EN SERVICIO",position:0});
      else { pending+=1; positions.set(String(x.id),{label:pending===1?"SIGUIENTE":`EN COLA #${pending}`,position:pending}); }
    });
    return positions;
  }

  async function renderOrdenes(isCurrent = () => true) {
    setHeading(state.role === "TECNICO" ? "Mis órdenes" : state.role === "CLIENTE" ? "Mis servicios" : "Órdenes de trabajo", "Flujo real de solicitud → coordinación → ejecución → cierre, usando los estados configurados en el sistema.");
    const all=filterSelectedDate("ordenes",(await loadAllPaged("ordenes","/api/ordenes")).items);

    if (state.role !== "COORDINADOR") {
      const states=smartUnique(all,x=>String(x.estado||"").toUpperCase());
      const priorities=smartUnique(all,x=>String(x.Prioridad||x.prioridad||"").toUpperCase());
      const services=smartUnique(all,x=>x.tipo||"");
      const queuePositions=state.role==="TECNICO"?technicianQueuePositions(all):new Map();
      const result=smartListData("ordenes",all,{
        defaults:{orden:state.role==="TECNICO"?"cola":"programada",direccion:state.role==="TECNICO"?"ASC":"DESC"},
        search:x=>[x.numero,x.cliente,x.sede,x.tipo,x.estado,x.Prioridad,x.prioridad,x.clasificacion],
        filters:{estado:x=>String(x.estado||"").toUpperCase(),prioridad:x=>String(x.Prioridad||x.prioridad||"").toUpperCase(),servicio:x=>String(x.tipo||"")},
        sort:{cola:x=>techQueueRank(x),programada:x=>smartDateValue(x.programada||x.creada),numero:x=>x.numero||"",cliente:x=>x.cliente||"",estado:x=>x.estado||"",prioridad:x=>x.Prioridad||x.prioridad||""}
      });
      const rows=result.items.map(x => {const q=queuePositions.get(String(x.id));const qlabel=state.role==="TECNICO"&&q?`<div class="muted" style="margin-top:.25rem;font-size:.72rem;font-weight:800">${esc(q.label)}${String(x.clasificacion||"").toUpperCase()==="EMERGENCIA"?" · EMERGENCIA":""}</div>`:"";return `<tr>
        <td class="mono">${esc(x.numero)}</td>
        <td><div class="se-cell-stack"><strong>${esc(x.cliente || "Sin cliente")}</strong><span class="se-cell-muted">${esc(x.sede || "Sin sede")}</span></div></td>
        <td>${esc(x.tipo)}</td>
        <td><div class="se-cell-stack">${badge(x.suspendida?"SUSPENDIDA · EN REVISIÓN":x.estado)}${badge(x.Prioridad||x.prioridad)}${qlabel}</div></td>
        <td>${fmt(x.programada)}</td>
        <td class="se-table-actions">${button("Ver","ver-orden",x.id,"primary")}</td>
      </tr>`;});
      content.innerHTML = `<div class="toolbar"><div class="toolbar-left"><h2>${state.role==="TECNICO"?"Mis órdenes":"Mis servicios"}</h2><p class="muted">Filtra por estado, prioridad o servicio sin recargar la página.</p></div>${state.role==="CLIENTE"&&moduleAllowed("cancelaciones")?`<div class="orders-page-actions"><button class="btn orders-cancellations-button" type="button" data-context-module="cancelaciones"><i data-lucide="circle-x"></i><span>Solicitudes de cancelación</span></button></div>`:""}</div><section class="panel smart-list-panel"><div class="panel-body">${smartControls("ordenes",{placeholder:"Orden, cliente, sede o servicio",filters:[{name:"estado",label:"Estado",options:states},{name:"prioridad",label:"Prioridad",options:priorities},{name:"servicio",label:"Servicio",options:services}],sorts:[...(state.role==="TECNICO"?[["cola","Cola operativa"]]:[]),["programada","Fecha / programación"],["numero","Número de OT"],["cliente","Cliente"],["estado","Estado"],["prioridad","Prioridad"]]})}${smartResultsMeta(result,"órdenes")}</div>${table(["Orden","Cliente / sede","Servicio","Estado y prioridad","Atención aproximada","Acción"],rows,"No hay órdenes que coincidan con los filtros.")}${smartPager("ordenes",result)}</section>`;
      window.lucide?.createIcons();
      return;
    }

    const details = await loadOrderListDetails(all);
    if (!isCurrent()) return;
    const defaults = {
      orden:"fecha", direccion:"DESC", tamano:20,
      filtros:{ estado:"TODOS", prioridad:"TODOS", tecnico:"TODOS", fecha:"TODAS", rapidos:["TODAS"] },
      densidad:"COMODA", fechaDesde:"", fechaHasta:"",
      columnas:{ supervisor:false, programada:false, cotizacion:false }
    };
    const prefs = smartPrefs("ordenes", defaults);
    prefs.filtros = Object.assign({}, defaults.filtros, prefs.filtros || {});
    prefs.filtros.rapidos = normalizeOrderQuickFilters(prefs.filtros.rapidos || "TODAS");
    prefs.densidad = prefs.densidad || "COMODA";
    prefs.columnas = Object.assign({}, defaults.columnas, prefs.columnas || {});

    const states = smartUnique(all, x => orderStateKey(x.estado)).map(v => [v, requestDisplayText(v)]);
    const priorities = [["CRITICA","Crítica"],["ALTA","Alta"],["MEDIA","Media"],["BAJA","Baja"]].filter(([value]) => all.some(x => orderPriorityKey(x.Prioridad||x.prioridad)===value));
    const technicianNames = smartUnique(all.flatMap(item => orderCrewRows(details.get(String(item.id))).map(t => t.nombre)).filter(Boolean), x => x);

    let prepared = all.filter(item => {
      const detail = details.get(String(item.id));
      const techFilter = String(prefs.filtros.tecnico || "TODOS");
      if (techFilter && techFilter !== "TODOS") {
        const crew = orderCrewRows(detail);
        if (techFilter === "SIN_ASIGNAR") {
          if (detail?._loadError || crew.length) return false;
        } else if (!crew.some(t => String(t.nombre || "").toUpperCase() === techFilter.toUpperCase())) return false;
      }
      if (!orderDateFilterMatches(item, prefs.filtros.fecha, prefs)) return false;
      const quicks = normalizeOrderQuickFilters(prefs.filtros.rapidos).filter(v => v !== "TODAS");
      if (quicks.length && !quicks.some(key => orderQuickMatches(item, detail, key))) return false;
      return true;
    });

    const priorityRank = {CRITICA:4,ALTA:3,MEDIA:2,BAJA:1,SIN_PRIORIDAD:0};
    const stateRank = {EN_PROCESO:4,PROGRAMADA:3,SIN_ESTADO:2,FINALIZADA:1,CANCELADA:0};
    const result = smartListData("ordenes", prepared, {
      defaults,
      search:item => {
        const detail = details.get(String(item.id));
        return [item.numero,item.cliente,item.sede,item.tipo,item.estado,item.Prioridad,item.prioridad,...orderCrewRows(detail).map(t=>t.nombre)];
      },
      filters:{
        estado:item=>orderStateKey(item.estado),
        prioridad:item=>orderPriorityKey(item.Prioridad||item.prioridad)
      },
      sort:{
        fecha:item=>smartDateValue(orderDateForList(item)),
        prioridad:item=>priorityRank[orderPriorityKey(item.Prioridad||item.prioridad)]||0,
        estado:item=>stateRank[orderStateKey(item.estado)]||0,
        numero:item=>item.numero||"",
        cliente:item=>item.cliente||""
      }
    });

    const quickDefs = [
      ["TODAS","Todas","all"],
      ["EN_PROCESO","En proceso","process"],
      ["SIN_ASIGNAR","Sin asignar","unassigned"],
      ["CRITICAS","Críticas","critical"],
      ["FINALIZADAS","Finalizadas","finalized"],
      ["HOY","Hoy","today"]
    ].map(([key,label,tone]) => ({key,label,tone,count:key==="TODAS"?all.length:all.filter(item=>orderQuickMatches(item,details.get(String(item.id)),key)).length}))
      .filter(def => def.key === "TODAS" || def.count > 0);
    const selectedQuick = new Set(normalizeOrderQuickFilters(prefs.filtros.rapidos));
    const quickMarkup = quickDefs.map(def => `<button class="order-quick-pill ${def.tone} ${selectedQuick.has(def.key)?"active":""}" type="button" data-action="order-quick-filter" data-value="${esc(def.key)}"><span>${esc(def.label)}</span><strong>${def.count}</strong></button>`).join("");

    const criticalUnassigned = all.filter(item => {
      const detail = details.get(String(item.id));
      return orderPriorityKey(item.Prioridad||item.prioridad)==="CRITICA" && !detail?._loadError && orderCrewRows(detail).length===0 && !["FINALIZADA","CANCELADA"].includes(orderStateKey(item.estado));
    });

    const optionalHeaders = [];
    if (prefs.columnas.supervisor) optionalHeaders.push(["Supervisor","supervisor"]);
    if (prefs.columnas.programada) optionalHeaders.push(["Atención programada","programada"]);
    if (prefs.columnas.cotizacion) optionalHeaders.push(["Cotización relacionada","cotizacion"]);

    const rows = result.items.map(item => {
      const detail = details.get(String(item.id));
      const clientName = String(item.cliente || "Sin cliente").trim() || "Sin cliente";
      const clientIdentity = entityAvatarLink(clientName, { entity:item, className:"order-client-identity" }, "ver-orden", item.id);
      const extraCells = optionalHeaders.map(([,key]) => {
        if (key === "supervisor") return `<td>${orderSupervisorCell(detail)}</td>`;
        if (key === "programada") return `<td>${orderDateMarkup(item.programada)}</td>`;
        if (key === "cotizacion") return `<td>${orderQuoteCell(detail)}</td>`;
        return `<td>—</td>`;
      }).join("");
      return `<tr>
        <td class="order-number-cell"><div class="se-cell-stack"><strong class="mono">${esc(item.numero || `OT-${item.id}`)}</strong>${orderDateMarkup(orderDateForList(item))}</div></td>
        <td class="order-client-cell"><div class="se-cell-stack">${clientIdentity}${entityDetailButton(item.sede || "Sin sede","ver-orden",item.id,"se-entity-secondary")}</div></td>
        <td class="order-service-cell"><span>${esc(item.tipo || "Sin servicio")}</span></td>
        <td>${orderCrewCell(detail)}</td>
        <td><div class="se-cell-stack">${item.suspendida?badge("SUSPENDIDA · EN REVISIÓN"):orderStatePill(item.estado)}${orderPriorityPill(item.Prioridad || item.prioridad)}${item.cotizacion_pendiente&&moduleAllowed("cotizaciones")?`<button class="btn small se-pending-dot" type="button" data-action="cotizar-orden" data-id="${esc(item.id)}">Realizar cotización</button>`:""}</div></td>
        ${extraCells}
        <td class="order-action-cell se-table-actions"><button class="order-view-button" type="button" data-action="ver-orden" data-id="${esc(item.id)}"><i data-lucide="eye"></i><span>Ver</span></button></td>
      </tr>`;
    }).join("");

    const tableHeaders = ["Orden","Cliente / sede","Servicio","Técnico asignado","Estado y prioridad",...optionalHeaders.map(([label])=>label),"Acción"];
    const tableMarkup = result.total ? `<div class="order-table-scroll se-table-responsive-scope"><table class="order-table order-compact-table ${optionalHeaders.length ? "has-extra-columns" : ""} ${prefs.densidad === "COMPACTA" ? "is-compact" : "is-comfortable"}"><thead><tr>${tableHeaders.map((label,index)=>`<th class="${index===0?"order-sticky-first":""}">${esc(label)}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table></div>` : `<div class="order-empty-state"><span class="order-empty-icon"><i data-lucide="clipboard-list"></i></span><h3>No encontramos órdenes con estos filtros.</h3><p>Prueba cambiando Estado, Técnico, Prioridad o Fecha.</p><button class="order-clear-button" type="button" data-action="smart-reset" data-list-key="ordenes"><i data-lucide="rotate-ccw"></i><span>Limpiar filtros</span></button></div>`;

    const customDateMarkup = String(prefs.filtros.fecha||"").toUpperCase()==="PERSONALIZADO" ? `<div class="order-custom-date-row"><label><span>Desde</span><input type="date" data-order-date-from value="${esc(prefs.fechaDesde||"")}"></label><label><span>Hasta</span><input type="date" data-order-date-to value="${esc(prefs.fechaHasta||"")}"></label></div>` : "";
    const technicianOptions = [["TODOS","Todos"],["SIN_ASIGNAR","Sin asignar"],...technicianNames.map(name=>[name,name])];
    const dateOptions = [["TODAS","Todas las fechas"],["HOY","Hoy"],["SEMANA","Esta semana"],["MES","Este mes"],["PERSONALIZADO","Personalizado"]];

    content.innerHTML = `<section class="orders-workspace">
      <header class="orders-page-header">
        <div class="orders-page-copy"><h2>Órdenes de trabajo</h2><p>Consulta, asigna y supervisa las órdenes activas de la operación.</p></div>
        <div class="orders-page-actions">
          ${moduleAllowed("cancelaciones") ? `<button class="btn orders-cancellations-button" type="button" data-context-module="cancelaciones"><i data-lucide="circle-x"></i><span>Solicitudes de cancelación</span></button>` : ""}
          <button class="orders-create-button" type="button" data-action="nueva-orden"><i data-lucide="plus"></i><span>Crear OT</span></button>
        </div>
      </header>

      <section class="orders-filters" aria-label="Filtros de órdenes">
        <div class="orders-filter-grid">
          <label class="orders-filter-field orders-search-field"><span>Buscar</span><div class="orders-search-control"><i data-lucide="search"></i><input type="search" data-smart-q="ordenes" value="${esc(prefs.q||"")}" placeholder="Buscar por orden, cliente, sede o servicio..." autocomplete="off"></div></label>
          <label class="orders-filter-field"><span>Estado</span><select data-smart-filter="estado" data-smart-key="ordenes">${smartOptions(states,prefs.filtros.estado,"Todos")}</select></label>
          <label class="orders-filter-field"><span>Prioridad</span><select data-smart-filter="prioridad" data-smart-key="ordenes">${smartOptions(priorities,prefs.filtros.prioridad,"Todas")}</select></label>
          <label class="orders-filter-field"><span>Técnico</span><select data-smart-filter="tecnico" data-smart-key="ordenes">${technicianOptions.map(([value,label])=>`<option value="${esc(value)}" ${String(prefs.filtros.tecnico||"TODOS")===String(value)?"selected":""}>${esc(label)}</option>`).join("")}</select></label>
          <label class="orders-filter-field"><span>Fecha</span><select data-smart-filter="fecha" data-smart-key="ordenes">${dateOptions.map(([value,label])=>`<option value="${value}" ${String(prefs.filtros.fecha||"TODAS")===value?"selected":""}>${label}</option>`).join("")}</select></label>
          <div class="orders-filter-clear-wrap"><span>&nbsp;</span><button class="order-clear-button" type="button" data-action="smart-reset" data-list-key="ordenes"><i data-lucide="rotate-ccw"></i><span>Limpiar filtros</span></button></div>
        </div>
        ${customDateMarkup}
        <div class="orders-quick-row"><span class="orders-quick-label">Filtros rápidos:</span><div class="orders-quick-list">${quickMarkup}</div><span class="orders-quick-hint">Puedes combinar varios.</span></div>
        ${[...selectedQuick].filter(value=>value!=="TODAS").length?`<div class="orders-active-quick"><span>${[...selectedQuick].filter(value=>value!=="TODAS").length} filtro${[...selectedQuick].filter(value=>value!=="TODAS").length===1?"":"s"} activo${[...selectedQuick].filter(value=>value!=="TODAS").length===1?"":"s"}</span><div>${[...selectedQuick].filter(value=>value!=="TODAS").map(value=>{const def=quickDefs.find(item=>item.key===value);return `<button type="button" class="smart-quick-active" data-action="order-quick-filter" data-value="${esc(value)}"><span>${esc(def?.label||value)}</span><i data-lucide="x"></i></button>`}).join("")}</div></div>`:""}
      </section>

      ${criticalUnassigned.length ? `<div class="orders-alert" role="status"><span class="orders-alert-icon"><i data-lucide="triangle-alert"></i></span><strong>${criticalUnassigned.length} orden${criticalUnassigned.length===1?" crítica está":"es críticas están"} sin técnico asignado.</strong><button type="button" data-action="order-critical-unassigned">Ver órdenes <i data-lucide="arrow-right"></i></button></div>` : ""}

      <section class="orders-list-section">
        <div class="orders-list-toolbar">
          <div class="orders-list-title"><i data-lucide="clipboard-list"></i><div><strong>Órdenes</strong><span>${result.total} resultado${result.total===1?"":"s"}</span></div></div>
          <div class="orders-list-options">
            <label><span>Ordenar por</span><select data-smart-sort data-smart-key="ordenes"><option value="fecha" ${prefs.orden==="fecha"?"selected":""}>Fecha</option><option value="prioridad" ${prefs.orden==="prioridad"?"selected":""}>Prioridad</option><option value="estado" ${prefs.orden==="estado"?"selected":""}>Estado</option><option value="numero" ${prefs.orden==="numero"?"selected":""}>Orden</option><option value="cliente" ${prefs.orden==="cliente"?"selected":""}>Cliente</option></select></label>
            <label><span>Dirección</span><select data-smart-direction data-smart-key="ordenes"><option value="DESC" ${prefs.direccion==="DESC"?"selected":""}>Descendente</option><option value="ASC" ${prefs.direccion==="ASC"?"selected":""}>Ascendente</option></select></label>
            <label><span>Vista</span><select data-order-density><option value="COMODA" ${prefs.densidad==="COMODA"?"selected":""}>Cómoda</option><option value="COMPACTA" ${prefs.densidad==="COMPACTA"?"selected":""}>Compacta</option></select></label>
            <details class="order-columns-menu"><summary class="order-columns-trigger"><span class="order-columns-trigger-icon"><i data-lucide="columns-3"></i></span><span>Columnas</span><i class="order-columns-chevron" data-lucide="chevron-down"></i></summary><div class="order-columns-popover"><div class="order-columns-popover-head"><span class="order-columns-popover-icon"><i data-lucide="layout-panel-top"></i></span><div><strong>Personalizar tabla</strong><small>Elige la información adicional que quieres ver.</small></div></div><div class="order-columns-options"><label class="order-column-option"><span class="order-column-copy"><span class="order-column-icon"><i data-lucide="user-round-check"></i></span><span><strong>Supervisor</strong><small>Responsable que coordina la OT.</small></span></span><span class="se-switch"><input type="checkbox" data-order-column="supervisor" ${prefs.columnas.supervisor?"checked":""}><span class="se-switch-ui" aria-hidden="true"></span></span></label><label class="order-column-option"><span class="order-column-copy"><span class="order-column-icon"><i data-lucide="calendar-clock"></i></span><span><strong>Atención programada</strong><small>Fecha y hora estimada de atención.</small></span></span><span class="se-switch"><input type="checkbox" data-order-column="programada" ${prefs.columnas.programada?"checked":""}><span class="se-switch-ui" aria-hidden="true"></span></span></label><label class="order-column-option"><span class="order-column-copy"><span class="order-column-icon"><i data-lucide="file-text"></i></span><span><strong>Cotización relacionada</strong><small>Documento vinculado a la orden.</small></span></span><span class="se-switch"><input type="checkbox" data-order-column="cotizacion" ${prefs.columnas.cotizacion?"checked":""}><span class="se-switch-ui" aria-hidden="true"></span></span></label></div><div class="order-columns-note"><i data-lucide="lock-keyhole"></i><span>Las columnas esenciales permanecen siempre visibles.</span></div></div></details>
          </div>
        </div>
        ${tableMarkup}
        ${orderPager(result)}
      </section>
    </section>`;
    window.lucide?.createIcons();
  }


  async function orderForm(preselectedSolicitud = "") {
    const req = await loadAllPaged("solicitudes","/api/solicitudes");
    const open = req.items.filter(x => !["CANCELADA","CONVERTIDA"].includes(String(x.Estado||x.estado||"").toUpperCase()));
    if(!open.length){showToast("No hay solicitudes pendientes para convertir en OT.","error");return;}
    openModal("Crear orden de trabajo", `<form id="orderForm" class="form-grid">
      <div class="field full"><label>Solicitud</label><select name="solicitud_id" id="orderRequest" required><option value="">Seleccione...</option>${optionList(open,"id",x=>`#${x.id} · ${x.cliente} · ${x.sede} · ${String(x.descripcion||"").slice(0,70)}`,preselectedSolicitud)}</select></div>
      <div class="field"><label>Prioridad</label><select name="prioridad" id="orderPriority"><option>BAJA</option><option selected>MEDIA</option><option>ALTA</option><option>CRITICA</option></select><small>Se propone desde la urgencia de la solicitud, pero coordinación puede modificarla.</small></div>
      <div class="field"><label>Fecha y hora aproximada de atención</label><input type="datetime-local" name="programada_para" id="orderSchedule"><small>Es una referencia operativa; tráfico, bloqueos, lluvia u otras condiciones pueden modificar la llegada.</small></div>
      <div class="field"><label>Ticket del cliente</label><input name="ticket" maxlength="60"></div><div class="field"><label>No. OT papel</label><input name="orden_papel" maxlength="60"></div>
      <div class="field full"><label>Observaciones</label><textarea name="observaciones"></textarea></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Crear OT y asignar cuadrilla</button></div></div>
    </form>`);
    const syncFromRequest=()=>{
      const selected=open.find(x=>String(x.id)===String($("#orderRequest").value)); if(!selected)return;
      const urgency=String(selected.urgencia||"").toUpperCase();
      $("#orderPriority").value=["BAJA","MEDIA","ALTA","CRITICA"].includes(urgency)?urgency:"MEDIA";
      if(selected.fecha_preferida) $("#orderSchedule").value=toLocalInput(selected.fecha_preferida);
      $("#orderForm [name=ticket]").value=selected.ticket||"";
    };
    $("#orderRequest").addEventListener("change",syncFromRequest); syncFromRequest();
    $("#orderForm").addEventListener("submit", async e => {
      e.preventDefault(); const submit=e.currentTarget.querySelector('button[type="submit"]'); submit.disabled=true;
      try {
        const result=await api("/api/ordenes",{method:"POST",body:Object.fromEntries(new FormData(e.currentTarget).entries())});
        const orderId=result.item?.OrdenTrabajoId||result.item?.ordenTrabajoId||result.item?.id;
        if(orderId)document.dispatchEvent(new CustomEvent("seprigua:tour-record",{detail:{type:"orden-creada",id:Number(orderId),solicitudId:Number(preselectedSolicitud)||null}}));
        showToast("Orden creada. Ahora define la cuadrilla.");
        if(orderId) return crewForm(orderId,true);
        closeModal(); navigate("ordenes");
      } catch(err){showToast(err.message,"error");submit.disabled=false;}
    });
  }

  async function crewForm(id, created=false) {
    await refreshCatalogs(true);
    const d=await api(`/api/ordenes/${id}`);
    const assigned=new Map((d.tecnicos||[]).filter(t=>["ASIGNADO","CONFIRMADO"].includes(String(t.estado||t.Estado).toUpperCase())).map(t=>[String(t.empleado_id),String(t.funcion||"TECNICO").toUpperCase()]));
    const freshCatalogs=await api("/api/catalogos");
    state.catalogs={...state.catalogs,...freshCatalogs};
    const technicians=state.catalogs.tecnicos||[];
    const techMeta=(t,checked=false)=>{const activeHere=Number(t.orden_activa_id||0)===Number(id);const busy=String(t.estado_operativo||"").toUpperCase()==="EN_SERVICIO"&&!activeHere;let queued=Number(t.cola_cantidad||0);if(checked&&!activeHere)queued=Math.max(0,queued-1);const parts=[];if(activeHere)parts.push("En esta OT");else if(busy&&t.orden_activa_numero)parts.push(`Atendiendo ${t.orden_activa_numero}`);else if(queued>0)parts.push("Con trabajos asignados");else parts.push(String(t.disponibilidad||"DISPONIBLE").replaceAll("_"," "));if(queued>0)parts.push(`${queued} en cola`);if(t.siguiente_orden_numero&&Number(t.siguiente_orden_id||0)!==Number(id))parts.push(`Siguiente: ${t.siguiente_orden_numero}${String(t.siguiente_clasificacion||"").toUpperCase()==="EMERGENCIA"?" · emergencia":""}`);return parts.join(" · ");};
    const cards=technicians.map(t=>{
      const fn=assigned.get(String(t.id))||"TECNICO",checked=assigned.has(String(t.id));
      const unavailable=["INACTIVO","NO_DISPONIBLE"].includes(String(t.disponibilidad||"").toUpperCase());
      const initials=String(t.nombre||"?").trim().split(/\s+/).slice(0,2).map(x=>x.charAt(0)).join("").toUpperCase()||"?";
      const stateLabel=String(t.estado_operativo||t.disponibilidad||"DISPONIBLE").replaceAll("_"," ");
      return `<article class="crew-person-card ${checked?"selected":""} ${unavailable&&!checked?"unavailable":""}" data-crew-card="${esc(t.id)}">
        <label class="crew-person-select">
          <input type="checkbox" class="crew-check" value="${esc(t.id)}" ${checked?"checked":""} ${unavailable&&!checked?"disabled":""}>
          <span class="crew-checkbox-ui"><i data-lucide="check"></i></span>
          <span class="crew-avatar">${esc(initials)}</span>
          <span class="crew-person-copy"><strong>${esc(t.nombre)}</strong><small>${esc(t.puesto||"Personal de campo")}</small><span>${esc(techMeta(t,checked))}</span></span>
          <span class="crew-status ${String(t.estado_operativo||"").toUpperCase()==="EN_SERVICIO"?"busy":""}">${esc(stateLabel)}</span>
        </label>
        <label class="crew-function-field"><span>Función en esta cuadrilla</span><select class="inline-select crew-function" data-id="${esc(t.id)}" ${checked?"":"disabled"}><option value="ENCARGADO" ${fn==="ENCARGADO"?"selected":""}>Encargado</option><option value="TECNICO" ${fn==="TECNICO"?"selected":""}>Técnico</option><option value="APOYO" ${fn==="APOYO"?"selected":""}>Apoyo</option></select></label>
      </article>`;
    }).join("");
    openModal(created?"Asignar cuadrilla de la nueva OT":"Gestionar cuadrilla",`<form id="crewForm" class="crew-manager">
      <div class="crew-manager-intro"><span><i data-lucide="users-round"></i></span><div><strong>Selecciona al personal de campo</strong><p>Debe existir exactamente un <b>Encargado</b>. Si alguien ya está atendiendo otra OT, esta asignación queda en su cola; las emergencias se priorizan.</p></div></div>
      <label class="se-extra-approval"><input type="checkbox" name="autorizar_extra"><span><strong>Autorizar trabajo extra durante vacaciones</strong><br><small>Aplica a esta OT y al personal seleccionado con vacaciones aprobadas para hoy o para la fecha programada.</small></span></label>
      <div class="crew-manager-list">${cards||`<div class="empty-state"><h3>No hay personal disponible</h3><p>Revisa el estado laboral y disponibilidad del personal.</p></div>`}</div>
      <div class="crew-manager-footer"><div class="crew-manager-help"><i data-lucide="info"></i><span>Los cambios no se aplican hasta presionar <strong>Guardar cuadrilla</strong>.</span></div><div class="form-actions"><button class="btn" type="button" data-action="ver-orden" data-id="${id}">Volver a la OT</button><button class="btn primary" type="submit"><i data-lucide="save"></i> Guardar cuadrilla</button></div></div>
    </form>`);
    $$(".crew-check").forEach(ch=>ch.addEventListener("change",()=>{const sel=$(`.crew-function[data-id="${CSS.escape(ch.value)}"]`);sel.disabled=!ch.checked;ch.closest(".crew-person-card")?.classList.toggle("selected",ch.checked);}));
    $("#crewForm").addEventListener("submit",async e=>{
      e.preventDefault();
      const integrantes=$$(".crew-check:checked").map(ch=>({empleado_id:Number(ch.value),funcion:$(`.crew-function[data-id="${CSS.escape(ch.value)}"]`).value}));
      if(!integrantes.length)return showToast("Selecciona al menos un integrante.","error");
      if(integrantes.filter(x=>x.funcion==="ENCARGADO").length!==1)return showToast("Debes dejar exactamente un ENCARGADO.","error");
      const submit=e.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;
      try{const result=await api(`/api/ordenes/${id}/cuadrilla`,{method:"PUT",body:{integrantes,autorizar_extra:e.currentTarget.elements.autorizar_extra.checked}});const queued=integrantes.filter(x=>{const t=technicians.find(v=>Number(v.id)===Number(x.empleado_id));if(!t)return false;const wasAlready=assigned.has(String(x.empleado_id));const busyElsewhere=String(t.estado_operativo||"").toUpperCase()==="EN_SERVICIO"&&Number(t.orden_activa_id||0)!==Number(id);const otherQueue=Math.max(0,Number(t.cola_cantidad||0)-(wasAlready?1:0));return busyElsewhere||otherQueue>0;}).length;showToast(queued?`Cuadrilla actualizada. ${queued} integrante(s) tienen trabajo en cola.`:(result.message||"Cuadrilla actualizada."));state.listCache.ordenes=null;await openOrder(id);}catch(err){showToast(err.message,"error");submit.disabled=false;}
    });
  }

  async function editOrderForm(id) {
    const d=await api(`/api/ordenes/${id}`),x=d.item,coord=state.role==="COORDINADOR";
    openModal(`Editar ${x.numero}`,`<form id="editOrderForm" class="form-grid">
      ${coord?`<div class="field"><label>Prioridad</label><select name="prioridad"><option ${String(x.Prioridad).toUpperCase()==="BAJA"?"selected":""}>BAJA</option><option ${String(x.Prioridad).toUpperCase()==="MEDIA"?"selected":""}>MEDIA</option><option ${String(x.Prioridad).toUpperCase()==="ALTA"?"selected":""}>ALTA</option><option ${String(x.Prioridad).toUpperCase()==="CRITICA"?"selected":""}>CRITICA</option></select></div><div class="field"><label>Fecha y hora aproximada de atención</label><input type="datetime-local" name="programada_para" value="${esc(toLocalInput(x.programada))}"><small>Referencia aproximada, no hora exacta garantizada.</small></div>`:""}
      <div class="field"><label>Ticket del cliente</label><input name="ticket" maxlength="60" value="${esc(x.ticket||"")}"></div><div class="field"><label>No. OT papel</label><input name="orden_papel" maxlength="60" value="${esc(x.orden_papel||"")}"></div>
      ${coord?`<div class="field full"><label>Observaciones de coordinación</label><textarea name="observaciones">${esc(x.observaciones||"")}</textarea></div>`:""}
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-action="ver-orden" data-id="${id}">Volver a la OT</button><button class="btn primary">Guardar cambios</button></div></div>
    </form>`);
    $("#editOrderForm").addEventListener("submit",async e=>{e.preventDefault();try{await api(`/api/ordenes/${id}`,{method:"PATCH",body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast("Datos actualizados.");await openOrder(id);}catch(err){showToast(err.message,"error");}});
  }


  function orderStepButton(id,key,number,label,done,active){
    return `<button class="order-step ${done?"done":""} ${active===key?"active":""}" type="button" data-action="orden-paso" data-id="${esc(id)}" data-step="${esc(key)}"><span class="order-step-number">${done?"✓":number}</span><span><strong>${esc(label)}</strong><small>${done?"Listo":"Pendiente"}</small></span></button>`;
  }

  function orderStepper(id,active,d,x){
    const p=d.progress||{},code=String(x.estado_codigo||"").toUpperCase();
    const hasPaperNumber=!!String(x.orden_papel||"").trim(), hasPaperFile=normalizeNumber(p.documentos_ot)>0;
    const physicalPaperUsed=hasPaperNumber||hasPaperFile;
    const step1=(!d.reglas_cierre?.ticket_obligatorio||!!String(x.ticket||"").trim()) && (!physicalPaperUsed || (hasPaperNumber && hasPaperFile));
    const minPhotos=Math.max(0,normalizeNumber(d.reglas_cierre?.min_fotos ?? 1));
    const step2=normalizeNumber(p.fotos_trabajo)>=minPhotos;
    const step3=normalizeNumber(p.actividades)>=1;
    const step4=code==="COMPLETADA";
    return `<section class="order-stepper" aria-label="Flujo de cierre técnico">
      ${orderStepButton(id,"documento",1,"Ticket y respaldo físico",step1,active)}
      ${orderStepButton(id,"evidencia",2,"Evidencia",step2,active)}
      ${orderStepButton(id,"descripcion",3,"Descripción",step3,active)}
      ${orderStepButton(id,"finalizar",4,"Finalizar OT",step4,active)}
    </section>`;
  }

  function orderEvidenceBy(d,predicate){return (d.evidencias||[]).filter(predicate);}

  function orderSignatureItems(d){
    return (d.evidencias||[]).filter(e=>String(e.categoria||e.Categoria||"").toUpperCase()==="FIRMA"||String(e.Descripcion||e.descripcion||"").trim().toUpperCase().startsWith("FIRMA:"));
  }

  function orderSignatureGallery(d,{showEmpty=false}={}){
    const signatures=orderSignatureItems(d);
    if(!signatures.length)return showEmpty?`<div class="signature-empty"><i data-lucide="pen-line"></i><span>Todavía no se ha guardado una firma de conformidad.</span></div>`:"";
    return `<div class="signature-gallery">${signatures.map(e=>{const label=String(e.Descripcion||e.descripcion||"FIRMA").replace(/^FIRMA:\s*/i,"")||"Firma";return `<article class="signature-preview-card"><div class="signature-preview-image"><img src="${esc(e.ruta)}" alt="Firma de ${esc(label)}" loading="lazy"></div><div class="signature-preview-copy"><small>Firma de conformidad</small><strong>${esc(label)}</strong><span>${fmt(e.creada||e.CreadoEn||e.tomada)}</span><a href="${esc(e.ruta)}" target="_blank" rel="noopener">Ver imagen completa</a></div></article>`;}).join("")}</div>`;
  }

  function uploadOrderFiles(id,files,{etapa="DURANTE",categoria="FOTO_TRABAJO",descripcion=""}={}){
    return uploadEvidenceFiles(`/api/ordenes/${id}/evidencias`, files, {etapa,categoria,descripcion});
  }

  function orderHeader(id,x){
    const fromAgenda=state.current==="agenda";
    return `<div class="toolbar order-workspace-toolbar"><div class="toolbar-left"><button class="btn" type="button" data-action="${fromAgenda?"volver-agenda":"volver-ordenes"}">← ${fromAgenda?"Volver a agenda":"Volver a órdenes"}</button><span class="badge">${esc(x.numero)}</span>${badge(x.estado)}</div><div class="toolbar-right">${button("Resumen","orden-paso",id,"primary")}</div></div>`;
  }

  async function openOrder(id, step="resumen", refresh=true) {
    closeModal();
    state.openOrderId=Number(id); state.orderStep=step||"resumen";
    if(refresh || !state.orderDetail || Number(state.orderDetail?.item?.id)!==Number(id)) state.orderDetail=await api(`/api/ordenes/${id}`);
    document.dispatchEvent(new CustomEvent("seprigua:tour-record",{detail:{type:"orden",id:Number(id)}}));
    const d=state.orderDetail,x=d.item;
    const tech=state.role==="TECNICO",coord=state.role==="COORDINADOR",client=state.role==="CLIENTE";
    if(client && state.orderStep!=="resumen")state.orderStep="resumen";
    setHeading(`Orden ${x.numero}`, `${x.cliente} · ${x.tipo} · ${x.sede||"Sede sin nombre"}`);

    const activeTechs=(d.tecnicos||[]).filter(t=>["ASIGNADO","CONFIRMADO"].includes(String(t.estado||t.Estado).toUpperCase()));
    const techs=activeTechs.map(t=>`${esc(t.nombre)} (${esc(t.funcion||"TECNICO")})`).join(", ")||"Sin técnicos asignados";
    const quoteList=d.cotizaciones||[],currentQuote=quoteList[0]||null;
    const orderCode=String(x.estado_codigo||"").toUpperCase();
    const warrantySetup = orderCode==="COMPLETADA" && coord && moduleAllowed("garantia") ? `<div class="notice-card"><strong>Garantía del servicio</strong><p>Define el plazo desde la fecha de finalización. Puedes dejarlo pendiente y resolverlo desde Garantías.</p><button class="btn primary" type="button" data-action="configurar-garantia" data-id="${esc(id)}"><i data-lucide="shield-check"></i> Configurar garantía</button></div>` : "";
    const reschedules=d.reprogramaciones||[],pendingReschedule=reschedules.find(r=>r.estado==="PENDIENTE");
    const p=d.progress||{},photos=normalizeNumber(p.fotos_trabajo),acts=normalizeNumber(p.actividades),docs=normalizeNumber(p.documentos_ot),pendingScopes=normalizeNumber(p.cambios_pendientes);
    const isCoralsa=/CORALSA/i.test(String(x.cliente||""));
    const shellStart=`<div class="order-workspace">${orderHeader(id,x)}${(coord||tech)?orderStepper(id,state.orderStep,d,x):""}`;
    const shellEnd=`</div>`;

    if(state.orderStep==="documento" && (coord||tech)){
      const docEvidence=orderEvidenceBy(d,e=>String(e.etapa||"").toUpperCase()==="DOCUMENTO"||String(e.categoria||"").toUpperCase()==="ORDEN_FISICA");
      const paperStatus = docs && x.orden_papel ? "Respaldo físico validado" : (docs || x.orden_papel ? "Respaldo físico incompleto" : "Sin hoja física · no aplica");
      content.innerHTML=`${shellStart}<section class="panel order-screen"><div class="panel-header"><div><span class="eyebrow">PASO 1 DE 4</span><h2>Ticket y respaldo físico</h2></div><span class="badge ${docs&&x.orden_papel?"green":""}">${esc(paperStatus)}</span></div><div class="panel-body">
        <div class="notice-card"><strong>La hoja física es opcional</strong><p>Registra el ticket cuando el cliente lo proporcione. Si el cliente utiliza OT u OC en papel, agrega su número y sube una foto o PDF. La carga realizada por Coordinación o por un Técnico asignado funciona como validación interna y no depende del cliente.${isCoralsa?" Para CORALSA, cuando exista hoja física, procura que la imagen muestre firma y sello.":""}</p></div>
        <form id="orderDocForm" class="form-grid" autocomplete="off">
          <div class="field"><label>Número de ticket</label><input name="ticket" maxlength="60" value="${esc(x.ticket||"")}" ${d.reglas_cierre?.ticket_obligatorio?"required":""}></div>
          <div class="field"><label>Número de OT u OC física <small>(opcional)</small></label><input name="orden_papel" maxlength="60" value="${esc(x.orden_papel||"")}" placeholder="Solo si existe hoja física"></div>
          <div class="field full"><label>Foto o PDF de la OT / OC <small>(opcional)</small></label><input type="file" name="archivos" multiple accept="image/*,application/pdf"><small>Si registras un número de OT/OC física, adjunta también su respaldo. Si no existe hoja física, deja ambos campos vacíos.</small></div>
          <div class="field full"><label>Descripción del documento <small>(opcional)</small></label><textarea name="descripcion" placeholder="Ej. copia física validada por coordinación${isCoralsa?", con firma y sello":""}."></textarea></div>
          <div class="field full"><div class="form-actions"><button class="btn" type="button" data-action="orden-paso" data-id="${esc(id)}" data-step="resumen">Volver al resumen</button><button class="btn primary" type="submit">Guardar y continuar</button></div></div>
        </form>
        <h3 class="section-title">Documentos cargados</h3><div class="evidence-grid">${docEvidence.map(evidenceCard).join("")||`<div class="muted">No se ha cargado hoja física. Esto no bloquea el cierre de la OT.</div>`}</div>
      </div></section>${shellEnd}`;
      $("#orderDocForm")?.addEventListener("submit",async e=>{
        e.preventDefault();const form=e.currentTarget;
        if(form.dataset.saving==="1")return;
        const fd=new FormData(form),files=form.querySelector('[name="archivos"]').files;
        const paperNumber=String(fd.get("orden_papel")||"").trim();
        const existingPhysicalDocs=Number(d.progress?.documentos_ot||0);
        if(!paperNumber && (files.length || existingPhysicalDocs>0)){showToast("Introduce el número de OT/OC física para identificar el documento adjunto.","error");form.querySelector('[name="orden_papel"]')?.focus();return;}
        if(paperNumber && !files.length && existingPhysicalDocs===0){showToast("Adjunta una foto o PDF de la OT/OC física antes de continuar.","error");form.querySelector('[name="archivos"]')?.focus();return;}
        if(d.reglas_cierre?.ticket_obligatorio && !String(fd.get("ticket")||"").trim()){showToast("Registra el número de ticket para continuar.","error");form.querySelector('[name="ticket"]')?.focus();return;}
        form.dataset.saving="1";const submit=form.querySelector('[type="submit"]');if(submit)submit.disabled=true;
        try{await api(`/api/ordenes/${id}`,{method:"PATCH",body:{ticket:fd.get("ticket"),orden_papel:paperNumber}});
          if(files.length)ensureEvidenceBatch(await uploadOrderFiles(id,files,{etapa:"DOCUMENTO",categoria:"ORDEN_FISICA",descripcion:fd.get("descripcion")||""}));
          showToast("Paso 1 guardado.");await openOrder(id,"evidencia",true);
        }catch(err){showToast(err.message,"error");if(submit?.isConnected)submit.disabled=false;}
        finally{delete form.dataset.saving;}
      });
      window.lucide?.createIcons(); return;
    }

    if(state.orderStep==="evidencia" && (coord||tech)){
      const workEvidence=orderEvidenceBy(d,e=>String(e.categoria||"").toUpperCase()==="FOTO_TRABAJO");
      const minPhotos=Math.max(0,normalizeNumber(d.reglas_cierre?.min_fotos ?? 1));
      content.innerHTML=`${shellStart}<section class="panel order-screen"><div class="panel-header"><div><span class="eyebrow">PASO 2 DE 4</span><h2>Subir evidencia del servicio</h2></div><span class="badge ${photos>=minPhotos?"green":"orange"}">${photos}/${minPhotos} foto${minPhotos===1?"":"s"}</span></div><div class="panel-body">
        <p class="muted">Carga las fotografías que demuestran el trabajo realizado.${minPhotos>0?` El cierre técnico requiere al menos ${minPhotos} foto${minPhotos===1?"":"s"}.`:""}</p>
        <form id="orderEvidenceForm" class="form-grid">
          <div class="field full"><label>Fotografías</label><input type="file" name="archivos" multiple accept="image/*" required></div>
          <div class="field"><label>Etapa</label><select name="etapa"><option selected>DURANTE</option><option>DESPUES</option></select></div>
          <div class="field full"><label>Descripción <small>(opcional)</small></label><textarea name="descripcion" placeholder="Describe lo que muestran las fotografías."></textarea></div>
          <div class="field full"><div class="form-actions"><button class="btn" type="button" data-action="orden-paso" data-id="${esc(id)}" data-step="documento">Anterior</button><button class="btn primary" type="submit">Subir y continuar</button></div></div>
        </form>
        <h3 class="section-title">Evidencia cargada</h3><div class="evidence-grid">${workEvidence.map(evidenceCard).join("")||`<div class="muted">Todavía no hay fotografías del trabajo.</div>`}</div>
        ${workEvidence.length?`<div class="notice-card" style="margin-top:18px"><strong>Collage automático disponible</strong><p>SEPRIGUA organiza las fotografías incluidas en la OT por etapa (Antes, Durante y Después) y genera una sola imagen lista para entregar.</p><div class="actions"><a class="btn" href="/api/ordenes/${esc(id)}/collage.jpg" target="_blank" rel="noopener"><i data-lucide="images"></i> Ver collage</a><a class="btn primary" href="/api/ordenes/${esc(id)}/collage.jpg?download=1" download><i data-lucide="download"></i> Descargar collage</a></div></div>`:""}
      </div></section>${shellEnd}`;
      $("#orderEvidenceForm")?.addEventListener("submit",async e=>{
        e.preventDefault();
        const form=e.currentTarget;if(form.dataset.uploading==="1")return;
        const fd=new FormData(form),files=form.querySelector('[name="archivos"]').files,submit=form.querySelector('button[type="submit"]');
        form.dataset.uploading="1";if(submit){submit.disabled=true;submit.dataset.originalText=submit.textContent;submit.textContent="Subiendo...";}
        try{
          const r=await uploadOrderFiles(id,files,{etapa:fd.get("etapa")||"DURANTE",categoria:"FOTO_TRABAJO",descripcion:fd.get("descripcion")||""});
          showToast(ensureEvidenceBatch(r));
          await openOrder(id,"descripcion",true);
        }catch(err){showToast(err.message,"error");form.dataset.uploading="0";if(submit){submit.disabled=false;submit.textContent=submit.dataset.originalText||"Subir y continuar";}}
      });
      window.lucide?.createIcons(); return;
    }

    if(state.orderStep==="descripcion" && (coord||tech)){
      const activities=(d.actividades||[]).map(a=>`<div class="timeline-item"><strong>${esc(a.empleado)}</strong> · ${fmt(a.realizada||a.RealizadaEn)}<br>${esc(a.Descripcion||a.descripcion)}${a.Resultado||a.resultado?`<br><span class="muted">Observación: ${esc(a.Resultado||a.resultado)}</span>`:""}</div>`).join("")||`<div class="muted">Todavía no hay descripción final registrada.</div>`;
      const employeeField=coord?`<div class="field"><label>Técnico responsable</label><select name="empleado_id" required><option value="">Seleccione...</option>${optionList(activeTechs,"empleado_id",t=>t.nombre)}</select></div>`:"";
      content.innerHTML=`${shellStart}<section class="panel order-screen"><div class="panel-header"><div><span class="eyebrow">PASO 3 DE 4</span><h2>Descripción y observaciones del trabajo</h2></div><span class="badge ${acts?"green":"orange"}">${acts?"Registrado":"Pendiente"}</span></div><div class="panel-body">
        <form id="orderDescriptionForm" class="form-grid">${employeeField}<div class="field full"><label>Descripción del servicio realizado</label><textarea name="descripcion" required placeholder="Detalla qué se realizó en la OT."></textarea></div><div class="field full"><label>Observaciones</label><textarea name="resultado" placeholder="Resultado, hallazgos, recomendaciones o notas para el cliente."></textarea></div><div class="field full"><div class="form-actions"><button class="btn" type="button" data-action="orden-paso" data-id="${esc(id)}" data-step="evidencia">Anterior</button><button class="btn primary" type="submit">Guardar y continuar</button></div></div></form>
        <h3 class="section-title">Registros del servicio</h3><div class="timeline">${activities}</div>
      </div></section>${shellEnd}`;
      $("#orderDescriptionForm")?.addEventListener("submit",async e=>{e.preventDefault();try{await api(`/api/ordenes/${id}/actividades`,{method:"POST",body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast("Descripción y observaciones guardadas.");await openOrder(id,"finalizar",true);}catch(err){showToast(err.message,"error");}});
      window.lucide?.createIcons(); return;
    }

    if(state.orderStep==="finalizar" && (coord||tech)){
      const hasPaperNumber=!!String(x.orden_papel||"").trim(), hasPaperFile=docs>0, physicalPaperUsed=hasPaperNumber||hasPaperFile;
      const paperReady=!physicalPaperUsed||(hasPaperNumber&&hasPaperFile);
      const minPhotos=Math.max(0,normalizeNumber(d.reglas_cierre?.min_fotos ?? 1));
      const checks=[
        [!d.reglas_cierre?.ticket_obligatorio||!!String(x.ticket||"").trim(),d.reglas_cierre?.ticket_obligatorio?"Ticket registrado":"Ticket opcional"],
        [paperReady,physicalPaperUsed?`Respaldo físico completo${isCoralsa?" (firma y sello cuando aplique)":""}`:"Hoja física no requerida"],
        [photos>=minPhotos,`Evidencia fotográfica (${photos}/${minPhotos})`],
        [acts>=1,"Descripción y observaciones registradas"],
        [pendingScopes===0,"Sin cambios de alcance pendientes"]
      ];
      const ready=checks.every(c=>c[0]);
      let finishAction="";
      if(orderCode==="COMPLETADA") finishAction=`<div class="completion-banner"><strong>✓ OT finalizada</strong><span>La orden ya está cerrada y visible como finalizada. La cotización puede enviarse antes o después y no modifica este estado.</span></div>`;
       else if(pendingReschedule) finishAction=`<div class="notice-card"><strong>OT suspendida</strong><p>Coordinación debe resolver la reprogramación antes de reanudar el trabajo.</p></div>`;
       else if((coord||tech) && ["PENDIENTE","PROGRAMADA"].includes(orderCode)) finishAction=`<div class="notice-card"><strong>Primero inicia el trabajo</strong><p>La OT debe estar EN PROCESO antes de poder finalizarla.</p><button class="btn primary" type="button" data-action="iniciar-orden" data-id="${esc(id)}">Iniciar trabajo</button></div>`;
      else if((coord||tech) && ["EN_PROCESO","POR_CONFIRMAR"].includes(orderCode)) finishAction=`<div class="final-action"><button class="btn finish-button" type="button" data-action="finalizar-tecnico" data-id="${esc(id)}" ${ready?"":"disabled"}>✓ Marcar OT como finalizada</button><p class="muted">${ready?"Coordinación o el técnico pueden cerrar la OT; no se necesita confirmación del cliente ni una cotización previa.":"Completa los puntos pendientes antes de finalizar."}</p></div>`;
      const canSign=["EN_PROCESO","POR_CONFIRMAR","COMPLETADA"].includes(orderCode);
      content.innerHTML=`${shellStart}<section class="panel order-screen"><div class="panel-header"><div><span class="eyebrow">PASO 4 DE 4</span><h2>Finalizar orden de trabajo</h2></div></div><div class="panel-body"><div class="check-list">${checks.map(([ok,label])=>`<div class="check-item ${ok?"ok":"pending"}"><span>${ok?"✓":"○"}</span><strong>${esc(label)}</strong></div>`).join("")}</div>${finishAction}${warrantySetup}<section class="order-signature-block"><div class="order-signature-head"><div><span class="eyebrow">CONFORMIDAD</span><h3>Firma del cliente o responsable</h3><p>La firma queda guardada como evidencia y sigue visible incluso después de cerrar la OT.</p></div>${canSign?button(orderCode==="COMPLETADA"?"Agregar firma de conformidad":"Guardar firma","firma-orden",id,"primary"):""}</div>${orderSignatureGallery(d,{showEmpty:true})}</section><div class="form-actions"><button class="btn" type="button" data-action="orden-paso" data-id="${esc(id)}" data-step="descripcion">Anterior</button><button class="btn" type="button" data-action="orden-paso" data-id="${esc(id)}" data-step="resumen">Ir al resumen</button></div></div></section>${shellEnd}`;
      window.lucide?.createIcons(); return;
    }

    const extraCrew=(d.tecnicos||[]).filter(member=>member.trabajo_extra&&(coord||Number(member.empleado_id)===Number(state.user?.empleado_id)));
    const extraSummary=(coord||tech)&&extraCrew.length?`<div class="notice-card"><span class="se-extra-label">Trabajo extra</span><p>${esc(extraCrew.map(member=>member.nombre).join(", "))} · fuera de horario o durante vacaciones aprobadas.</p></div>`:"";
    const quoteSummary=currentQuote
      ? `<div class="timeline-item"><strong>${esc(currentQuote.numero||`Cotización #${currentQuote.id}`)}</strong> ${badge(currentQuote.estado||"BORRADOR")}<br><span class="muted">Versión ${esc(currentQuote.version||"—")} · ${money(currentQuote.total,currentQuote.moneda)}</span></div>`
      : `<div class="muted">Todavía no hay cotización vinculada. Puede crearse antes o después de finalizar la OT.</div>`;
    const quoteActions=coord
      ? `<div class="actions" style="margin-top:10px">${currentQuote?button("Ir a cotizaciones","ir-cotizaciones",currentQuote.id):x.cotizacion_pendiente&&moduleAllowed("cotizaciones")?button("Realizar cotización","cotizar-orden",id,"primary"):""}</div>`
      : currentQuote?`<div class="actions" style="margin-top:10px">${button("Ver cotización","ir-cotizaciones",currentQuote.id,"primary")}</div>`:"";
    const correction=Number(x.requiere_correccion||0)?`<section class="panel"><div class="panel-body"><strong>Corrección solicitada por cliente</strong><p>${esc(x.motivo_correccion||"Pendiente de corrección")}</p></div></section>`:"";
    const recentHistory=(d.historial||[]).slice(0,8).map(h=>`<div class="timeline-item">${esc(h.anterior||"Inicio")} → <strong>${esc(h.nuevo)}</strong><br><span class="muted">${fmt(h.fecha)} · ${esc(h.Comentario||h.comentario||"")}</span></div>`).join("")||`<div class="muted">Sin historial.</div>`;
    const incidents=(d.incidencias||[]).slice(0,6).map(i=>`<div class="timeline-item"><strong>${esc(i.tipo)}</strong> ${badge(i.Estado||i.estado)}<br>${esc(i.Descripcion||i.descripcion)}${i.accion?`<br><span class="muted">Acción: ${esc(i.accion)}</span>`:""}${coord&&!i.resuelta?`<div class="actions">${button("Resolver","resolver-incidencia",i.id)}</div>`:""}</div>`).join("")||`<div class="muted">Sin incidencias.</div>`;
    const scopes=(d.cambios_alcance||[]).slice(0,6).map(c=>`<div class="timeline-item"><strong>${badge(c.estado)} Cambio de alcance</strong><br>${esc(c.detectado)}<br><span class="muted">${esc(c.motivo||"")}</span><div class="actions">${coord&&String(c.estado).toUpperCase()==="PENDIENTE"&&!c.informado_por?button("Enviar al cliente","enviar-cambio",c.id):""}${client&&!x.solo_lectura&&String(c.estado).toUpperCase()==="PENDIENTE"&&c.informado_por?button("Responder","responder-cambio",c.id,"primary"):""}</div></div>`).join("")||`<div class="muted">Sin cambios de alcance.</div>`;
    const allowedCoordStates=(state.catalogs.estados_orden||[]).filter(s=>!["COMPLETADA","POR_CONFIRMAR"].includes(String(s.codigo||"").toUpperCase()));
    const stateControl=coord&&orderCode!=="COMPLETADA"&&!pendingReschedule?`<select class="inline-select" id="stateSelect"><option value="">Cambiar estado...</option>${optionList(allowedCoordStates)}</select><button class="btn small primary" data-action="cambiar-estado" data-id="${esc(id)}">Aplicar</button>`:"";
    const startButton=tech&&!pendingReschedule&&["PENDIENTE","PROGRAMADA"].includes(orderCode)?button("Iniciar trabajo","iniciar-orden",id,"primary"):"";
    const suspendButton=(coord||tech)&&orderCode==="EN_PROCESO"?button("Suspender y reprogramar","suspender-orden",id,"primary"):"";
    const opActions=(coord||tech)?`<section class="panel"><div class="panel-header"><h2>Acciones de la OT</h2></div><div class="panel-body"><div class="actions">${stateControl}${startButton}${suspendButton}${coord?button("Editar datos","editar-orden",id):""}${coord?button("Gestionar cuadrilla","asignar-tecnico",id):""}${button("Incidencia","incidencia",id)}${button("Cambio de alcance","cambio-alcance",id)}</div>${tech?`<p class="muted">El cierre técnico se realiza en las cuatro pantallas superiores.</p>`:""}</div></section>`:"";
    const reschedulePanel=reschedules.length?`<section class="panel"><div class="panel-header"><div><h2>Suspensiones y reprogramaciones</h2><p class="muted">Historial de la misma orden de trabajo.</p></div>${pendingReschedule?badge("PENDIENTE"):""}</div><div class="panel-body"><div class="timeline">${reschedules.map(r=>`<div class="timeline-item"><strong>${esc(r.estado==="RESUELTA"?"Reprogramación aprobada":r.estado==="CERRADA"?"Solicitud rechazada":"Solicitud pendiente")}</strong><br><span class="muted">Solicitada: ${fmt(r.solicitada_en)} · Original: ${fmt(r.original)} · Propuesta: ${fmt(r.propuesta)}${r.confirmada?` · Confirmada: ${fmt(r.confirmada)}`:""}</span><p>${esc(r.motivo)}</p>${!client?`<p><strong>Realizado:</strong> ${esc(r.trabajo_realizado||"")}<br><strong>Pendiente:</strong> ${esc(r.pendiente||"")}</p><p class="muted">Solicitó: usuario #${esc(r.solicitada_por||"—")} · Autorizó: ${r.autorizada_por?`usuario #${esc(r.autorizada_por)}`:"pendiente"}</p><div class="actions">${(r.evidencias||[]).map((photo,index)=>`<a class="btn small" href="/api/archivos/evidencia/${Number(photo)}" target="_blank" rel="noopener">Foto ${index+1}</a>`).join("")}</div>${r.decision?`<p class="muted">Decisión: ${esc(r.decision)}</p>`:""}${coord&&r.estado==="PENDIENTE"?`<div class="actions">${button("Aprobar o rechazar","decidir-reprogramacion",id,"primary")}</div>`:""}`:""}</div>`).join("")}</div></div></section>`:"";
    const signatureCount=orderSignatureItems(d).length;
    const signatureSummary=(signatureCount||(coord||tech)&&["EN_PROCESO","POR_CONFIRMAR","COMPLETADA"].includes(orderCode))?`<section class="panel order-signature-summary"><div class="panel-header"><div><h2>Firma de conformidad</h2><p class="muted">${signatureCount?`${signatureCount} firma(s) guardada(s) como evidencia de la OT.`:"Aún no hay firma guardada."}</p></div>${(coord||tech)&&["EN_PROCESO","POR_CONFIRMAR","COMPLETADA"].includes(orderCode)?button(signatureCount?"Agregar otra firma":"Capturar firma","firma-orden",id,"primary"):""}</div><div class="panel-body">${orderSignatureGallery(d,{showEmpty:true})}</div></section>`:"";
    const noChargeWarranty=/GARANT[IÍ]A\s+APROBADA.*SIN\s+COBRO/i.test(String(x.observaciones||""));
    const warrantyChargeBanner=noChargeWarranty?`<div class="order-no-charge-banner"><i data-lucide="shield-check"></i><div><strong>GARANTÍA APROBADA · SIN COBRO</strong><span>Esta atención quedó identificada como trabajo cubierto por garantía.</span></div></div>`:"";

    content.innerHTML=`${shellStart}${warrantyChargeBanner}${warrantySetup}${extraSummary}<section class="se-detail-page-section">${window.SepriguaDetail.section('Información de la orden',[
      ['Cliente',esc(x.cliente)],
      [!x.solicitante_nombre && x.registrada_por_nombre ? 'Registrada por' : 'Solicitante',esc(x.solicitante_nombre || x.registrada_por_nombre || 'No registrado')],
      ['Sede',esc(x.sede)],['Estado',badge(x.estado)],
      ['Prioridad',esc(displayDetailValue(x.Prioridad||x.prioridad))],['Atención aproximada',fmt(x.programada)],
      ['Cuadrilla',techs],['Ubicación',esc([x.Direccion||x.direccion,x.Municipio||x.municipio].filter(Boolean).join(', ')||x.sede)],
      ['Ticket',esc(x.ticket||'—')],['OT / OC',esc(x.orden_papel||'—')]
    ])}${client&&!x.solo_lectura&&["PENDIENTE","PROGRAMADA"].includes(orderCode)&&!(x.iniciada||x.iniciada_en)?button("Solicitar cancelación","solicitar-cancelacion","OrdenTrabajo:"+id):""}${window.SepriguaDetail.prose('Solicitud',esc(x.solicitud))}</section>
      ${correction}${pendingReschedule?`<div class="notice-card"><strong>Trabajo suspendido</strong><p>La solicitud de reprogramación está pendiente de decisión. Las evidencias y actividades anteriores permanecen en esta OT.</p></div>`:""}${reschedulePanel}${opActions}${signatureSummary}
      ${tech?"":`<section class="panel"><div class="panel-header"><h2 class="${coord&&x.cotizacion_pendiente&&moduleAllowed("cotizaciones")?"se-pending-dot":""}">Cotización</h2><span class="muted">Independiente del cierre técnico</span></div><div class="panel-body">${quoteSummary}${quoteActions}</div></section>`}
      <div class="two-col"><section class="panel"><div class="panel-header"><h2>Historial reciente</h2></div><div class="panel-body"><div class="timeline">${recentHistory}</div></div></section><section class="panel"><div class="panel-header"><h2>Incidencias</h2></div><div class="panel-body"><div class="timeline">${incidents}</div></div></section></div>
      <section class="panel"><div class="panel-header"><h2>Cambios de alcance</h2></div><div class="panel-body"><div class="timeline">${scopes}</div></div></section>${shellEnd}`;
    try {
      const tracking=await api(`/api/ordenes/${id}/seguimiento`,{seCache:"reload"});
      if(Number(state.openOrderId)===Number(id) && state.orderStep==="resumen"){
        const alreadyArrived=(tracking.llegadas||[]).some(item=>Number(item.empleado_id)===Number(state.user?.empleado_id));
        const alreadyDeparted=(tracking.salidas||[]).some(item=>Number(item.empleado_id)===Number(state.user?.empleado_id));
        const canArrive=tech && !alreadyArrived && ["PENDIENTE","PROGRAMADA","EN_PROCESO"].includes(orderCode);
        const canDepart=tech && !alreadyDeparted && !alreadyArrived && ["PENDIENTE","PROGRAMADA"].includes(orderCode);
        const section=document.createElement("section"); section.className="panel work-order-timeline";
        section.innerHTML=`<div class="panel-header"><div><h2>Bitácora completa del trabajo</h2><p class="muted">Seguimiento compartido con cliente, técnico y Coordinación.</p></div><div class="actions">${canDepart?`<button class="btn" type="button" data-action="registrar-salida-ot" data-id="${esc(id)}"><i data-lucide="truck"></i> Voy en camino</button>`:""}${canArrive?`<button class="btn primary" type="button" data-action="registrar-llegada-ot" data-id="${esc(id)}"><i data-lucide="map-pin-check"></i> Registrar llegada</button>`:""}</div></div><div class="panel-body">${portalUI.workEvents(tracking.eventos)}${!tracking.llegadas?.length?'<p class="muted">Todavía no hay una hora de llegada registrada.</p>':''}</div>`;
        content.querySelector(".order-workspace")?.appendChild(section);
      }
    }catch(error){console.warn("No se pudo cargar la bitácora de la OT",error);}
    window.lucide?.createIcons();
  }

  function backToOrder(id){return `<button class="btn" type="button" data-action="ver-orden" data-id="${id}">Volver a la OT</button>`;}

  function suspendOrderForm(id){
    const coord=state.role==="COORDINADOR";
    openModal("Suspender y reprogramar",`<form id="suspendOrderForm" class="form-grid">
      <div class="field full"><label>Motivo de suspensión</label><textarea name="motivo" maxlength="700" minlength="10" required placeholder="Explica por qué no se pudo terminar la intervención."></textarea><small>El motivo general será visible para el cliente cuando se confirme la nueva fecha.</small></div>
      <div class="field full"><label>Trabajo realizado</label><textarea name="trabajo_realizado" maxlength="220" minlength="5" required></textarea></div>
      <div class="field full"><label>Actividades pendientes</label><textarea name="pendiente" maxlength="220" minlength="5" required></textarea></div>
      <div class="field"><label>Fecha y hora propuesta</label><input type="datetime-local" name="propuesta" required></div>
      ${coord?`<div class="field"><label>Fecha confirmada <small>(opcional)</small></label><input type="datetime-local" name="confirmada_para"><small>Si la indicas, Coordinación aprueba la reprogramación ahora.</small></div>`:""}
      <div class="field full"><label>Fotografías de la suspensión</label><input type="file" name="fotos" accept="image/*" multiple required><small>Entre 1 y 6 imágenes. Quedarán en la misma OT.</small></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">${coord?"Guardar suspensión":"Solicitar reprogramación"}</button></div></div>
    </form>`);
    $("#suspendOrderForm")?.addEventListener("submit",async event=>{
      event.preventDefault();const form=event.currentTarget,files=[...form.querySelector('[name="fotos"]').files];
      if(form.dataset.saving==="1")return;
      if(files.length<1||files.length>6){showToast("Adjunta entre 1 y 6 fotografías.","error");return;}
      form.dataset.saving="1";const save=form.querySelector('[type="submit"]');save.disabled=true;
      try{
        const fd=new FormData(form);
        const uploads=await uploadOrderFiles(id,files,{categoria:"FOTO_TRABAJO",etapa:"DURANTE",descripcion:"Evidencia de suspensión y reprogramación"});
        ensureEvidenceBatch(uploads);
        await api(`/api/ordenes/${id}/reprogramaciones`,{method:"POST",body:{
          motivo:fd.get("motivo"),trabajo_realizado:fd.get("trabajo_realizado"),pendiente:fd.get("pendiente"),
          propuesta:fd.get("propuesta"),confirmada_para:fd.get("confirmada_para")||null,evidencias:uploads.ids
        }});
        showToast("Suspensión registrada en la misma OT.");await openOrder(id,"resumen",true);
      }catch(error){showToast(error.message,"error");form.dataset.saving="0";save.disabled=false;}
    });
  }

  function decideRescheduleForm(id){
    const pending=(state.orderDetail?.reprogramaciones||[]).find(r=>r.estado==="PENDIENTE");
    if(!pending){showToast("No hay solicitud pendiente.","error");return;}
    openModal("Decidir reprogramación",`<form id="decideRescheduleForm" class="form-grid">
      <div class="field full"><strong>${esc(pending.motivo)}</strong><p class="muted">Realizado: ${esc(pending.trabajo_realizado||"")}<br>Pendiente: ${esc(pending.pendiente||"")}</p><p class="muted">Fecha original: ${fmt(pending.original)} · Propuesta: ${fmt(pending.propuesta)}</p><div class="actions">${(pending.evidencias||[]).map((photo,index)=>`<a class="btn small" href="/api/archivos/evidencia/${Number(photo)}" target="_blank" rel="noopener">Foto ${index+1}</a>`).join("")}</div></div>
      <div class="field full"><p class="muted">Puedes ajustar la cuadrilla o el equipo en el resumen de la OT antes de aprobar. Se comprobará la disponibilidad al guardar.</p></div>
      <div class="field"><label>Fecha y hora confirmada</label><input type="datetime-local" name="confirmada_para" required></div>
      <div class="field full"><label>Observación de Coordinación <small>(opcional)</small></label><textarea name="observacion" maxlength="120"></textarea></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn danger" type="button" id="rejectReschedule">Rechazar</button><button class="btn primary" type="submit">Aprobar y programar</button></div></div>
    </form>`);
    const form=$("#decideRescheduleForm");
    const decide=async decision=>{if(form.dataset.saving==="1")return;form.dataset.saving="1";try{const fd=new FormData(form);await api(`/api/ordenes/${id}/reprogramaciones/${pending.id}/decision`,{method:"POST",body:{decision,confirmada_para:decision==="APROBAR"?fd.get("confirmada_para"):null,observacion:fd.get("observacion")}});showToast(decision==="APROBAR"?"Reprogramación aprobada.":"Solicitud rechazada.");await openOrder(id,"resumen",true);}catch(error){showToast(error.message,"error");form.dataset.saving="0";}};
    form?.addEventListener("submit",event=>{event.preventDefault();decide("APROBAR");});
    $("#rejectReschedule")?.addEventListener("click",()=>decide("RECHAZAR"));
  }

  async function quickAction(action,id) {
    if(action==="iniciar-orden"){
      const target=(state.catalogs.estados_orden||[]).find(s=>String(s.codigo||"").toUpperCase()==="EN_PROCESO");
      if(!target)return showToast("No se encontró el estado EN PROCESO configurado.","error");
      try{await api(`/api/ordenes/${id}/estado`,{method:"POST",body:{estado_id:target.id,comentario:"Inicio de trabajo registrado desde el portal operativo"}});showToast("Trabajo iniciado.");await openOrder(id,state.orderStep==="finalizar"?"finalizar":"resumen",true);}catch(err){showToast(err.message,"error");}return;
    }
    if(action==="finalizar-tecnico"){
      const completed=(state.catalogs.estados_orden||[]).find(s=>String(s.codigo||"").toUpperCase()==="COMPLETADA");
      if(!completed)return showToast("No se encontró el estado de finalización configurado.","error");
      try{await api(`/api/ordenes/${id}/estado`,{method:"POST",body:{estado_id:completed.id,comentario:"Cierre de OT completado desde el flujo de 4 pasos"}});showToast("OT finalizada correctamente.");await openOrder(id,"finalizar",true);}catch(err){showToast(err.message,"error");}return;
    }
    if(action==="cambiar-estado"){
      const estado_id=$("#stateSelect")?.value;if(!estado_id)return showToast("Selecciona el siguiente estado.","error");
      try{await api(`/api/ordenes/${id}/estado`,{method:"POST",body:{estado_id,comentario:"Cambio desde el panel SEPRIGUA"}});showToast("Estado actualizado.");await openOrder(id);}catch(e){showToast(e.message,"error");}return;
    }
    if(action==="editar-orden")return editOrderForm(id);
    if(action==="asignar-tecnico")return crewForm(id);
    if(action==="actividad"){
      const detail=await api(`/api/ordenes/${id}`),assigned=(detail.tecnicos||[]).filter(t=>["ASIGNADO","CONFIRMADO"].includes(String(t.estado).toUpperCase()));
      const employ=state.role==="COORDINADOR"?`<div class="field"><label>Empleado</label><select name="empleado_id" required>${optionList(assigned,"empleado_id",x=>x.nombre)}</select></div>`:"";
      openModal("Registrar actividad",`<form id="miniForm">${employ}<div class="field"><label>Actividad realizada</label><textarea name="descripcion" required></textarea></div><div class="field"><label>Resultado</label><textarea name="resultado"></textarea></div><div class="form-actions">${backToOrder(id)}<button class="btn primary">Guardar</button></div></form>`);
      $("#miniForm").addEventListener("submit",async e=>{e.preventDefault();try{await api(`/api/ordenes/${id}/actividades`,{method:"POST",body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast("Actividad registrada.");await openOrder(id);}catch(err){showToast(err.message,"error");}});return;
    }
    if(action==="incidencia"){
      openModal("Registrar incidencia",`<form id="miniForm"><div class="field"><label>Tipo</label><select name="tipo"><option>ACCESO</option><option>RETRASO</option><option>SEGURIDAD</option><option>EQUIPO</option><option>PERSONAL</option><option>CLIENTE</option><option>SERVICIO</option><option selected>OTRA</option></select></div><div class="field"><label>Descripción</label><textarea name="descripcion" required></textarea></div><div class="field"><label>Acción tomada</label><textarea name="accion"></textarea></div><div class="form-actions">${backToOrder(id)}<button class="btn primary">Guardar</button></div></form>`);
      $("#miniForm").addEventListener("submit",async e=>{e.preventDefault();try{await api(`/api/ordenes/${id}/incidencias`,{method:"POST",body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast("Incidencia registrada.");await openOrder(id);}catch(err){showToast(err.message,"error");}});return;
    }
    if(action==="resolver-incidencia"){
      const orderId=window.__currentOrderId||null;
      // El botón de incidencia usa id de incidencia; obtenemos la OT visible desde el título/datos mediante state temporal.
      const oid=state.openOrderId;if(!oid)return showToast("Vuelve a abrir la OT.","error");
      openModal("Resolver incidencia",`<form id="resolveIncident"><div class="field"><label>Acción tomada / solución</label><textarea name="accion" required></textarea></div><div class="form-actions">${backToOrder(oid)}<button class="btn primary">Marcar resuelta</button></div></form>`);
      $("#resolveIncident").addEventListener("submit",async e=>{e.preventDefault();try{await api(`/api/ordenes/${oid}/incidencias/${id}/resolver`,{method:"PATCH",body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast("Incidencia resuelta.");await openOrder(oid);}catch(err){showToast(err.message,"error");}});return;
    }
    if(action==="cambio-alcance"){
      openModal("Reportar cambio de alcance",`<form id="scopeForm" class="form-grid"><div class="field full"><label>Alcance previsto</label><textarea name="original"></textarea></div><div class="field full"><label>Cambio detectado</label><textarea name="detectado" required></textarea></div><div class="field full"><label>Motivo</label><textarea name="motivo" required></textarea></div><div class="field full"><label>Trabajo adicional / alternativa propuesta</label><textarea name="propuesta"></textarea></div><div class="field full"><div class="form-actions">${backToOrder(id)}<button class="btn primary">Registrar cambio</button></div></div></form>`);
      $("#scopeForm").addEventListener("submit",async e=>{e.preventDefault();try{await api(`/api/ordenes/${id}/cambios-alcance`,{method:"POST",body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast(state.role==="TECNICO"?"Cambio reportado a coordinación.":"Cambio de alcance registrado.");await openOrder(id);}catch(err){showToast(err.message,"error");}});return;
    }
    if(action==="enviar-cambio"){
      const oid=state.openOrderId;if(!oid)return;
      try{await api(`/api/ordenes/${oid}/cambios-alcance/${id}/enviar`,{method:"POST",body:{}});showToast("Cambio enviado al cliente.");await openOrder(oid);}catch(err){showToast(err.message,"error");}return;
    }
    if(action==="responder-cambio"){
      const oid=state.openOrderId;if(!oid)return;
      openModal("Responder cambio de alcance",`<form id="scopeResponse"><div class="field"><label>Respuesta</label><select name="estado"><option>AUTORIZADO</option><option>RECHAZADO</option><option>ALTERNATIVA</option></select></div><div class="field"><label>Observaciones</label><textarea name="respuesta"></textarea></div><div class="form-actions">${backToOrder(oid)}<button class="btn primary">Responder</button></div></form>`);
      $("#scopeResponse").addEventListener("submit",async e=>{e.preventDefault();try{await api(`/api/ordenes/${oid}/cambios-alcance/${id}/responder`,{method:"POST",body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast("Respuesta registrada.");await openOrder(oid);}catch(err){showToast(err.message,"error");}});return;
    }
    if(action==="evidencia-solicitud"){
      openModal("Agregar evidencia a solicitud",`<form id="requestEvidenceForm"><div class="field"><label>Imágenes / archivos</label><input type="file" name="archivos" multiple accept="image/*,video/mp4,video/quicktime,application/pdf" required></div><div class="field"><label>Descripción</label><textarea name="descripcion"></textarea></div><div class="form-actions"><button class="btn" type="button" data-action="ver-solicitud" data-id="${id}">Volver</button><button class="btn primary">Subir</button></div></form>`);
      $("#requestEvidenceForm").addEventListener("submit",async e=>{e.preventDefault();const form=e.currentTarget;if(form.dataset.uploading==="1")return;const files=form.querySelector('[name="archivos"]').files,desc=form.querySelector('[name="descripcion"]').value,submit=form.querySelector('button[type="submit"]');form.dataset.uploading="1";if(submit){submit.disabled=true;submit.textContent="Subiendo...";}try{const r=await uploadRequestFiles(id,files,desc);showToast(ensureEvidenceBatch(r));await openRequest(id);}catch(err){showToast(err.message,"error");form.dataset.uploading="0";if(submit){submit.disabled=false;submit.textContent="Subir";}}});return;
    }
    if(action==="evidencia"){
      openModal("Subir evidencias",`<form id="evidenceForm"><div class="field"><label>Archivos</label><input type="file" name="archivos" multiple accept="image/*,video/mp4,video/quicktime,application/pdf" required></div><div class="field"><label>Etapa</label><select name="etapa"><option>ANTES</option><option selected>DURANTE</option><option>DESPUES</option><option>DOCUMENTO</option></select><small>Para la OT física o PDF usa DOCUMENTO.</small></div><div class="field"><label>Descripción</label><textarea name="descripcion"></textarea></div><div class="form-actions">${backToOrder(id)}<button class="btn primary">Subir</button></div></form>`);
      $("#evidenceForm").addEventListener("submit",async e=>{
        e.preventDefault();const form=e.currentTarget;if(form.dataset.uploading==="1")return;
        const files=form.querySelector('[name="archivos"]').files,etapa=form.querySelector('[name="etapa"]').value,descripcion=form.querySelector('[name="descripcion"]').value,submit=form.querySelector('button[type="submit"]');
        form.dataset.uploading="1";if(submit){submit.disabled=true;submit.dataset.originalText=submit.textContent;submit.textContent="Subiendo...";}
        try{const r=await uploadOrderFiles(id,files,{etapa,categoria:etapa==="DOCUMENTO"?"ORDEN_FISICA":"",descripcion});showToast(ensureEvidenceBatch(r));await openOrder(id);}catch(err){showToast(err.message,"error");form.dataset.uploading="0";if(submit){submit.disabled=false;submit.textContent=submit.dataset.originalText||"Subir";}}
      });return;
    }
  }

  async function renderMisSedes(isCurrent = () => true) {
    if (state.role !== "CLIENTE") return navigate("dashboard");
    setHeading("Mis sedes", "Agrega y administra las tiendas o ubicaciones de tu empresa para utilizarlas en nuevas solicitudes.");
    const all=(await loadAllPaged("sedes","/api/mis-sedes")).items;
    if (!isCurrent()) return;
    state.clientSites=all;
    const active=all.filter(x=>x.activo).length,inactive=all.length-active;
    const result=smartListData("sedes",all,{
      defaults:{orden:"nombre",direccion:"ASC"},
      search:x=>[x.nombre,x.codigo,x.telefono,x.direccion,x.municipio,x.departamento],
      filters:{estado:x=>x.activo?"ACTIVA":"INACTIVA"},
      sort:{nombre:x=>x.nombre||"",municipio:x=>x.municipio||"",estado:x=>x.activo?1:0}
    });
    const cards=`<section class="mini-stats-grid site-summary-grid"><article class="mini-stat"><span>Total de sedes</span><strong>${all.length}</strong></article><article class="mini-stat"><span>Activas</span><strong>${active}</strong></article><article class="mini-stat"><span>Inactivas</span><strong>${inactive}</strong></article></section>`;
    const rows=result.items.map(x=>`<tr><td><div class="site-name-cell"><span class="site-pin"><i data-lucide="map-pin"></i></span><div><strong>${esc(x.nombre||"Sede")}</strong><small>${esc(x.codigo||"Sin código")}</small></div></div></td><td>${esc(x.telefono||"—")}</td><td>${esc(x.direccion||"—")}</td><td>${esc([x.municipio,x.departamento].filter(Boolean).join(", ")||"—")}</td><td>${badge(x.activo?"ACTIVA":"INACTIVA")}</td><td><div class="inline-actions">${button("Editar","editar-sede",x.id)}${button(x.activo?"Desactivar":"Activar","toggle-sede",x.id,x.activo?"danger":"primary")}</div></td></tr>`);
    content.innerHTML=`${cards}<div class="toolbar"><div class="toolbar-left"><h2>Sedes y tiendas registradas</h2><p class="muted">Busca y filtra tus propias ubicaciones.</p></div><div class="toolbar-right"><button class="btn" type="button" data-action="importar-mis-sedes"><i data-lucide="file-up"></i> Importar sucursales</button>${button("Agregar sede","nueva-sede","","primary")}</div></div><section class="panel smart-list-panel"><div class="panel-body">${smartControls("sedes",{placeholder:"Sede, código, dirección o municipio",filters:[{name:"estado",label:"Estado",options:[["ACTIVA","Activas"],["INACTIVA","Inactivas"]]}],sorts:[["nombre","Nombre"],["municipio","Municipio"],["estado","Estado"]]})}${smartResultsMeta(result,"sedes")}</div>${table(["Sede / tienda","Teléfono","Dirección","Municipio / departamento","Estado","Acciones"],rows,"No hay sedes que coincidan con los filtros.")}${smartPager("sedes",result)}</section>`;
    window.lucide?.createIcons();
  }


  function sedeForm(id = null) {
    const current = id ? state.clientSites.find(x => String(x.id) === String(id)) : null;
    openModal(current ? "Editar sede / tienda" : "Agregar nueva sede / tienda", `<form id="clientSiteForm" class="form-grid se-sede-form" autocomplete="off">
      <div class="se-sede-form-heading full"><i data-lucide="store"></i><div><strong>Información de la sucursal</strong><p>Identificá el establecimiento y completá su ubicación.</p></div></div>
      <div class="field full"><label>Nombre de la sede / tienda <span class="se-required">*</span></label><input name="nombre" maxlength="180" required placeholder="Ej. Restaurante Zona 10" value="${esc(current?.nombre||"")}"></div>
      <div class="field"><label>Código interno</label><input name="codigo" maxlength="30" placeholder="Ej. Z10-01" value="${esc(current?.codigo||"")}"></div>
      <div class="field"><label>Teléfono</label><input name="telefono" maxlength="20" inputmode="tel" placeholder="Ej. 2424-0000" value="${esc(current?.telefono||"")}"></div>
      <div class="se-sede-form-section full"><i data-lucide="map-pin"></i><strong>Ubicación</strong></div>
      <div class="field"><label>Municipio <span class="se-required">*</span></label><input name="municipio" maxlength="100" required placeholder="Ej. Guatemala" value="${esc(current?.municipio||"")}"></div>
      <div class="field"><label>Departamento <span class="se-required">*</span></label><input name="departamento" maxlength="100" required value="${esc(current?.departamento||"Guatemala")}"></div>
      <div class="field full"><label>Dirección completa <span class="se-required">*</span></label><textarea name="direccion" maxlength="450" rows="2" required placeholder="Avenida, calle, zona, local o centro comercial">${esc(current?.direccion||"")}</textarea></div>
      <div class="field full"><label>Referencia para llegar</label><textarea name="referencia_llegada" maxlength="400" rows="2" placeholder="Entrada, nivel, local o punto de referencia">${esc(current?.referencia_llegada||"")}</textarea></div>
      <div class="field full"><label>Observaciones</label><textarea name="observaciones" maxlength="500" rows="2" placeholder="Indicaciones adicionales (opcional)">${esc(current?.observaciones||"")}</textarea></div>
      <div class="se-sede-form-footer full"><span>* Campos obligatorios</span><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">${current?"Guardar cambios":"Agregar sede"}</button></div></div>
    </form>`);
    const form = $("#clientSiteForm");
    form?.addEventListener("submit", async e => {
      e.preventDefault();
      const submit = form.querySelector('button[type="submit"]');
      submit.disabled = true;
      try {
        const body = Object.fromEntries(new FormData(form).entries());
        const result = await api(current ? `/api/mis-sedes/${current.id}` : "/api/mis-sedes", {method: current ? "PATCH" : "POST", body});
        showToast(result.message || (current ? "Sede actualizada." : "Sede agregada."));
        closeModal();
        await renderMisSedes();
      } catch (err) {
        showToast(err.message, "error");
      } finally {
        submit.disabled = false;
      }
    });
  }

  function confirmSedeState(id) {
    const item = state.clientSites.find(x => String(x.id) === String(id));
    if (!item) return;
    const activate = !item.activo;
    openModal(activate ? "Activar sede" : "Desactivar sede", `<div class="confirm-card ${activate?"":"danger"}"><div class="confirm-icon"><i data-lucide="${activate?"circle-check-big":"triangle-alert"}"></i></div><div><h3>${activate?"¿Activar esta sede?":"¿Desactivar esta sede?"}</h3><p>${activate?"Volverá a estar disponible al crear solicitudes.":"Ya no aparecerá como opción para nuevas solicitudes, pero el historial de servicios se conserva."}</p><strong>${esc(item.nombre||"Sede")}</strong></div></div><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn ${activate?"primary":"danger"}" type="button" data-action="confirmar-toggle-sede" data-id="${esc(id)}" data-active="${activate?1:0}">${activate?"Activar":"Desactivar"}</button></div>`);
    window.lucide?.createIcons();
  }

  async function renderClientes(isCurrent = () => true) {
    setHeading("Clientes y personal", "Administra clientes, sedes, colaboradores y accesos del sistema.");
    const all=(await loadAllPaged("clientes","/api/clientes")).items;
    state.peopleCounts.clientes=all.length;
    await ensurePeopleCounts("clientes");
    if (!isCurrent()) return;
    const activeCount=all.filter(x=>!!x.activo).length;
    const inactiveCount=all.length-activeCount;
    const siteCount=all.reduce((sum,x)=>sum+normalizeNumber(x.sedes),0);
    const multiSiteCount=all.filter(x=>normalizeNumber(x.sedes)>1).length;
    const prefs=smartPrefs("clientes",{orden:"nombre",direccion:"ASC",filtros:{peopleQuick:["TODOS"]}});
    const quickValues=normalizeSmartQuickValues(prefs.filtros?.peopleQuick);
    const quickSet=new Set(quickValues);
    let source=[...all];
    if(quickValues.length) source=source.filter(x=>quickValues.some(quick=>quick==="ACTIVOS"?!!x.activo:quick==="INACTIVOS"?!x.activo:quick==="VARIAS_SEDES"?normalizeNumber(x.sedes)>1:true));
    const result=smartListData("clientes",source,{
      defaults:{orden:"nombre",direccion:"ASC",filtros:{peopleQuick:"TODOS"}},
      search:x=>[x.codigo,x.nombre,x.nit,x.telefono,x.correo],
      filters:{estado:x=>x.activo?"ACTIVO":"INACTIVO"},
      sort:{nombre:x=>x.nombre||"",codigo:x=>x.codigo||"",solicitudes:x=>Number(x.solicitudes||0),sedes:x=>Number(x.sedes||0),estado:x=>x.activo?1:0,creado_en:x=>x.creado_en||""}
    });
    const rows=result.items.map(x=>{
      const active=!!x.activo;
      const contact=[x.contacto_principal_nombre,x.contacto_principal_correo,x.contacto_principal_telefono].filter(Boolean);
      const menu=peopleActionMenu([
        {label:"Editar cliente",icon:"pencil",action:"editar-cliente",id:x.id},
        {label:"Gestionar sedes",icon:"map-pinned",action:"ver-sedes",id:x.id},
        {separator:true},
        {label:active?"Desactivar":"Reactivar",icon:active?"user-round-x":"user-round-check",action:"toggle-cliente",id:x.id,danger:active,attrs:`data-active="${active?0:1}" data-name="${esc(x.nombre||"")}"`}
      ]);
      return `<tr>
        <td><div class="people-primary-cell">${entityDetailButton(x.nombre||"Cliente","ver-cliente",x.id)}<span>${esc(x.codigo||"Sin código")}${x.nit?` · NIT ${esc(x.nit)}`:""}</span></div></td>
        <td><button class="people-number-cell se-entity-link-block" type="button" data-action="ver-sedes" data-id="${esc(x.id)}" aria-label="Ver sedes de ${esc(x.nombre||"cliente")}"><strong>${normalizeNumber(x.sedes)}</strong><span>${normalizeNumber(x.sedes)===1?"sede":"sedes"}</span></button></td>
        <td><div class="people-contact-cell">${contact.length?`${entityDetailButton(x.contacto_principal_nombre||"Contacto","ver-cliente",x.id)}${x.contacto_principal_correo?`<span class="people-contact-detail" title="${esc(x.contacto_principal_correo)}">${esc(x.contacto_principal_correo)}</span>`:""}${x.contacto_principal_telefono?`<span class="people-contact-detail">${esc(x.contacto_principal_telefono)}</span>`:""}`:`<span class="people-muted">Sin contacto principal</span>`}</div></td>
        <td>${peopleStatusBadge(active?"ACTIVO":"INACTIVO")}</td>
        <td><div class="people-row-actions"><button class="people-outline-action" type="button" data-action="ver-cliente" data-id="${esc(x.id)}"><i data-lucide="eye"></i><span>Ver perfil</span></button>${menu}</div></td>
      </tr>`;
    });
    const quicks=`<div class="people-quick-row"><span>Filtros rápidos:</span><div class="people-quick-list">${peopleQuickButton("clientes","TODOS","Todos",all.length,quickValues.length===0)}${peopleQuickButton("clientes","ACTIVOS","Activos",activeCount,quickSet.has("ACTIVOS"))}${peopleQuickButton("clientes","INACTIVOS","Inactivos",inactiveCount,quickSet.has("INACTIVOS"))}${peopleQuickButton("clientes","VARIAS_SEDES","Con varias sedes",multiSiteCount,quickSet.has("VARIAS_SEDES"))}</div><span class="people-quick-hint">Puedes combinar varios.</span></div>${quickValues.length?`<div class="people-active-quick"><span>${quickValues.length} filtro${quickValues.length===1?"":"s"} activo${quickValues.length===1?"":"s"}</span><div>${quickValues.map(value=>`<button class="smart-quick-active" type="button" data-action="people-quick-filter" data-list-key="clientes" data-value="${esc(value)}"><span>${esc(value==="VARIAS_SEDES"?"Con varias sedes":value.charAt(0)+value.slice(1).toLowerCase())}</span><i data-lucide="x"></i></button>`).join("")}</div></div>`:""}`;
    const p=smartPrefs("clientes");
    const filters=`<section class="people-filter-section clients-filter-modern">
      <div class="clients-filter-main">
        <label class="people-field people-search clients-search-control">
          <span class="clients-filter-kicker">Buscar</span>
          <div class="clients-search-box"><i data-lucide="search"></i><input type="search" data-smart-q="clientes" value="${esc(p.q)}" placeholder="Cliente, sede, NIT, correo o teléfono..." autocomplete="off"></div>
        </label>
        <div class="clients-filter-controls">
          <label class="clients-filter-select state-filter">
            <span class="clients-filter-icon"><i data-lucide="circle-dot"></i></span>
            <span class="clients-filter-copy"><small>Estado</small><select data-smart-filter="estado" data-smart-key="clientes">${smartOptions([["ACTIVO","Activos"],["INACTIVO","Inactivos"]],p.filtros?.estado,"Todos")}</select></span>
          </label>
          <label class="clients-filter-select sort-filter">
            <span class="clients-filter-icon"><i data-lucide="arrow-up-down"></i></span>
            <span class="clients-filter-copy"><small>Ordenar</small><select data-smart-sort data-smart-key="clientes"><option value="nombre" ${p.orden==="nombre"?"selected":""}>Nombre</option><option value="sedes" ${p.orden==="sedes"?"selected":""}>Sedes</option><option value="solicitudes" ${p.orden==="solicitudes"?"selected":""}>Solicitudes</option><option value="creado_en" ${p.orden==="creado_en"?"selected":""}>Fecha de registro</option><option value="estado" ${p.orden==="estado"?"selected":""}>Estado</option></select></span>
          </label>
          <label class="clients-filter-select direction-filter">
            <span class="clients-filter-icon"><i data-lucide="move-vertical"></i></span>
            <span class="clients-filter-copy"><small>Dirección</small><select data-smart-direction data-smart-key="clientes"><option value="ASC" ${p.direccion==="ASC"?"selected":""}>Ascendente</option><option value="DESC" ${p.direccion==="DESC"?"selected":""}>Descendente</option></select></span>
          </label>
          <label class="clients-filter-select size-filter">
            <span class="clients-filter-icon"><i data-lucide="rows-3"></i></span>
            <span class="clients-filter-copy"><small>Mostrar</small><select data-smart-size data-smart-key="clientes">${[5,10,20,50].map(n=>`<option value="${n}" ${Number(p.tamano)===n?"selected":""}>${n} por página</option>`).join("")}</select></span>
          </label>
          <button class="people-clear clients-clear-button" type="button" data-action="smart-reset" data-list-key="clientes" title="Restablecer filtros"><i data-lucide="rotate-ccw"></i><span>Limpiar</span></button>
        </div>
      </div>
      ${quicks}
    </section>`;
    content.innerHTML=`<div class="people-workspace">${peopleWorkspaceHeader("clientes")}
      <section class="people-metrics">${peopleMetric("Clientes activos",activeCount,"Con servicio habilitado")}${peopleMetric("Sedes registradas",siteCount,"Ubicaciones vinculadas")}${peopleMetric("Clientes inactivos",inactiveCount,"Historial conservado")}</section>
      <section class="people-context"><div><h2>Clientes y sedes</h2><p>Consulta empresas, contactos y ubicaciones registradas.</p></div></section>
      ${filters}
      ${peopleTableShell("Clientes",result,["Cliente","Sedes","Contacto principal","Estado","Acciones"],rows,smartPager("clientes",result),"clientes")}
    </div>`;
    window.lucide?.createIcons();
  }


  async function fetchClientDetail(id){
    if(!id) throw new Error("No se recibió el identificador del cliente.");
    const d=await api(`/api/clientes/${encodeURIComponent(id)}/detalle`);
    if(!d?.item) throw new Error("No fue posible obtener los datos del cliente.");
    return d.item;
  }

  async function openClientDetail(id){
    openModal("Detalle del cliente", `<div class="loading-card">Cargando información del cliente...</div>`, {lockBackdrop:false});
    const x=await fetchClientDetail(id);
    openModal("Detalle del cliente",`${window.SepriguaDetail.section('Información del cliente',[
      ['Código',esc(x.codigo||'—')],['Estado',x.activo?'<span class="badge green">Activo</span>':'<span class="badge red">Inactivo</span>'],
      ['Nombre comercial',esc(x.nombre_comercial||'—')],['Razón social',esc(x.razon_social||'—')],['NIT',esc(x.nit||'—')],
      ['Teléfono',esc(x.telefono||'—')],['Correo',esc(x.correo||'—')],['Dirección fiscal',esc(x.direccion_fiscal||'—')],
      ['Sedes',normalizeNumber(x.sedes)],['Contactos',normalizeNumber(x.contactos)],
      ['Fecha de registro',x.creado_en?fmt(x.creado_en):'—'],['Contacto principal',esc(x.contacto_principal?.nombre||'Sin registrar')],
      ['Cargo del contacto',esc(x.contacto_principal?.cargo||'—')],['Teléfono del contacto',esc(x.contacto_principal?.telefono||'—')],
      ['Correo del contacto',esc(x.contacto_principal?.correo||'—')],['Solicitudes',normalizeNumber(x.solicitudes)],
      ['Última actualización',fmt(x.actualizado_en)]
    ],'building-2')}${x.observaciones?window.SepriguaDetail.prose('Observaciones',esc(x.observaciones)):''}
    <div class="form-actions"><button class="btn" type="button" data-action="ver-sedes" data-id="${esc(id)}">Ver sedes</button><button class="btn" type="button" data-action="editar-cliente" data-id="${esc(id)}">Editar</button><button class="btn ${x.activo?"danger":"primary"}" type="button" data-action="toggle-cliente" data-id="${esc(id)}" data-active="${x.activo?0:1}" data-name="${esc(x.nombre_comercial||"")}">${x.activo?"Desactivar":"Reactivar"}</button></div>`, {detailHeader:{kicker:`Cliente ${x.codigo||''}`,title:x.nombre_comercial||x.razon_social||'Cliente',meta:x.razon_social||'Cuenta empresarial',status:x.activo?'Activo':'Inactivo',icon:'building-2'}});
    window.lucide?.createIcons();
  }

  async function clientForm(id=""){
    const editing=!!id;
    if(editing) openModal("Editar cliente", `<div class="loading-card">Cargando datos para editar...</div>`, {lockBackdrop:false});
    const current=editing?await fetchClientDetail(id):null;
    openModal(editing?"Editar cliente":"Crear cliente",`<form id="clientCreateForm" class="form-grid" autocomplete="off">
      <div class="field"><label>Código de cliente</label><input name="codigo" maxlength="20" placeholder="Ej. CLI-001" required value="${esc(current?.codigo||"")}"></div>
      <div class="field"><label>NIT</label><input name="nit" maxlength="20" placeholder="NIT del cliente" value="${esc(current?.nit||"")}"></div>
      <div class="field full"><label>Nombre comercial</label><input name="nombre_comercial" maxlength="180" required placeholder="Nombre con el que identificamos al cliente" value="${esc(current?.nombre_comercial||"")}"></div>
      <div class="field full"><label>Razón social</label><input name="razon_social" maxlength="220" placeholder="Opcional" value="${esc(current?.razon_social||"")}"></div>
      <div class="field"><label>Teléfono principal</label><input name="telefono" maxlength="20" placeholder="+502 ..." value="${esc(current?.telefono||"")}"></div>
      <div class="field"><label>Correo principal</label><input type="email" name="correo" maxlength="160" placeholder="contacto@empresa.com" value="${esc(current?.correo||"")}"></div>
      <div class="field full"><label>Dirección fiscal</label><textarea name="direccion_fiscal" maxlength="400" placeholder="Opcional">${esc(current?.direccion_fiscal||"")}</textarea></div>
      <div class="field full"><label>Observaciones</label><textarea name="observaciones" maxlength="700" placeholder="Información interna del cliente">${esc(current?.observaciones||"")}</textarea></div>
      ${editing?`<div class="field full"><div class="notice-card"><strong>Fecha de registro:</strong> ${current?.creado_en?fmt(current.creado_en):"No disponible"}. Este dato es automático y no se puede editar.</div></div><div class="field full"><div class="user-form-intro"><span><i data-lucide="contact-round"></i></span><div><strong>Contacto principal de la empresa</strong><p>Se muestra el contacto principal registrado de la empresa. Es independiente de las cuentas del portal; si estaba vinculado a una cuenta antigua, al cambiarlo se guardará como contacto empresarial separado.</p></div></div></div>
      <div class="field full"><label>Nombre del contacto</label><input name="contacto_nombre" maxlength="180" placeholder="Ej. Ana Pérez" value="${esc(current?.contacto_principal?.nombre||"")}"></div>
      <div class="field"><label>Cargo</label><input name="contacto_cargo" maxlength="120" placeholder="Gerencia, mantenimiento..." value="${esc(current?.contacto_principal?.cargo||"")}"></div>
      <div class="field"><label>Teléfono del contacto</label><input name="contacto_telefono" maxlength="20" value="${esc(current?.contacto_principal?.telefono||"")}"></div>
      <div class="field full"><label>Correo del contacto</label><input type="email" name="contacto_correo" maxlength="160" value="${esc(current?.contacto_principal?.correo||"")}"></div>
      <div class="field full"><div class="notice-card"><strong>Baja lógica</strong><p>Para desactivar o reactivar al cliente utiliza la acción de estado. No se elimina su historial.</p></div></div>`:""}
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit"><i data-lucide="${editing?"save":"building-2"}"></i> ${editing?"Guardar cambios":"Crear cliente"}</button></div></div>
    </form>`);
    const form=$("#clientCreateForm");
    form?.addEventListener("submit",async e=>{e.preventDefault();const submit=form.querySelector('button[type="submit"]');submit.disabled=true;try{const body=Object.fromEntries(new FormData(form).entries());const result=await api(editing?`/api/clientes/${id}`:"/api/clientes",{method:editing?"PATCH":"POST",body});showToast(result.message||(editing?"Cliente actualizado.":"Cliente registrado correctamente."));closeModal();state.userAdmin.catalogos=null;state.catalogs={};await renderClientes();}catch(err){showToast(err.message,"error");}finally{submit.disabled=false;}});
    window.lucide?.createIcons();
  }

  function confirmClientState(id, activate, name){
    openModal(activate?"Reactivar cliente":"Desactivar cliente",`<div class="confirm-card ${activate?"":"danger"}"><div class="confirm-icon"><i data-lucide="${activate?"circle-check-big":"triangle-alert"}"></i></div><div><h3>${activate?"¿Reactivar este cliente?":"¿Desactivar este cliente?"}</h3><p>${activate?"La empresa volverá a estar disponible. Después activa manualmente las cuentas que deban recuperar acceso.":"Se conserva su historial. Todas sus cuentas de usuario se desactivarán y las sesiones abiertas se cerrarán."}</p><strong>${esc(name||"Cliente")}</strong></div></div><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn ${activate?"primary":"danger"}" type="button" data-action="confirmar-toggle-cliente" data-id="${esc(id)}" data-active="${activate?1:0}">${activate?"Reactivar":"Desactivar"}</button></div>`);
    window.lucide?.createIcons();
  }

  // Archivo de carga masiva validado en backend. El servidor revisa de nuevo al confirmar.
  function importarSucursales(clienteId = null){
    const coord=state.role==="COORDINADOR";
    const base=coord?`/api/clientes/${Number(clienteId)}/sedes/importar`:`/api/mis-sedes/importar`;
    if(coord&&!Number(clienteId)){showToast("Seleccioná una empresa.","error");return;}
    openModal("Importar sucursales",`<form id="seImportSitesForm" class="form-grid" enctype="multipart/form-data">
      <div class="field full"><div class="notice-card"><strong>Carga masiva · ${coord?"Coordinación":"Mi empresa"}</strong><p>Hasta 300 sucursales por archivo (4 MB). Se valida código, nombre, dirección, municipio y departamento. Las duplicadas no se agregan. ${coord?"Después asigná las sedes a cada cuenta desde Usuarios.":"Las sedes nuevas quedarán asignadas a tu propia cuenta."}</p></div></div>
      <div class="field full"><label>Archivo Excel, CSV o XML *</label><input type="file" name="archivo" accept=".xlsx,.csv,.xml" required></div>
      <div class="field full"><p><a href="/assets/plantillas/Plantilla_Importacion_Sucursales_SEPRIGUA.xlsx" download>Descargar plantilla de Excel</a> · Para CSV: encabezados iguales, separados por coma o punto y coma. Para XML: raíz &lt;sucursales&gt; con elementos &lt;sucursal&gt;.</p></div>
      <div id="seImportSitesPreview" class="field full"></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit" id="seImportPreviewBtn">Revisar archivo</button><button class="btn primary" type="button" id="seImportConfirmBtn" disabled style="display:none">Confirmar importación</button></div></div>
    </form>`);
    const form=$("#seImportSitesForm"),view=$("#seImportSitesPreview");
    const input=form?.querySelector('input[type="file"]');
    const previewButton=$("#seImportPreviewBtn"),confirmButton=$("#seImportConfirmBtn");
    let confirmedFile=null;
    input?.addEventListener("change",()=>{confirmedFile=null;confirmButton.disabled=true;confirmButton.style.display="none";view.innerHTML="";});
    const formData=file=>{const data=new FormData();data.append("archivo",file,file.name);return data;};
    form?.addEventListener("submit",async e=>{
      e.preventDefault();const file=input?.files?.[0];if(!file)return showToast("Seleccioná un archivo.","error");
      previewButton.disabled=true;
      try{
        const result=await api(`${base}/preview`,{method:"POST",body:formData(file)});
        const stats=result.resumen||{};
        const invalid=(result.items||[]).filter(x=>x.estado!=="NUEVA");
        const shown=(invalid.length?invalid:(result.items||[])).slice(0,25);
        const rows=shown.map(x=>`<tr><td>${esc(x.fila)}</td><td>${esc(x.codigo||"—")}</td><td>${esc(x.nombre||"—")}</td><td>${esc(displayEnumText(x.estado))}</td><td>${esc((x.errores||[]).join("; ")||"—")}</td></tr>`);
        view.innerHTML=`<div class="notice-card"><strong>Resultado de la revisión: ${esc(stats.total||0)} filas</strong><p>Nuevas: ${esc(stats.nuevas||0)} · Duplicadas: ${esc(stats.duplicadas||0)} · Errores: ${esc(stats.errores||0)}</p></div>${rows.length?`<div style="max-height:250px;overflow:auto;margin-top:8px">${table(["Fila","Código","Sucursal","Resultado","Observaciones"],rows,"")}</div>`:""}<p class="muted">${invalid.length?"Se muestran primero las incidencias.":"Se muestran hasta 25 registros."} Solo se agregarán las filas nuevas.</p>`;
        confirmedFile=file;
        confirmButton.style.display="";
        confirmButton.disabled=!(stats.nuevas>0&&!stats.errores);
        if(stats.errores)showToast("El archivo tiene errores. Corregí esas filas para importar.","error");
      }catch(error){confirmedFile=null;confirmButton.style.display="none";view.innerHTML="";showToast(error.message,"error");}
      finally{previewButton.disabled=false;}
    });
    confirmButton?.addEventListener("click",async()=>{
      if(!confirmedFile)return;
      confirmButton.disabled=true;
      try{
        const result=await api(base,{method:"POST",body:formData(confirmedFile)});
        showToast(result.message||"Importación completada.");
        state.catalogs={};state.userAdmin.catalogos=null;
        return coord?openSedes(clienteId):renderMisSedes();
      }catch(error){showToast(error.message,"error");confirmButton.disabled=false;}
    });
    window.lucide?.createIcons();
  }

  // Coordinación administra las sedes desde la empresa sin crear una cuenta Cliente.
  async function adminSedeForm(clienteId, sedeId = null, options = {}){
    if(!clienteId){showToast("Seleccioná primero una empresa cliente.","error");return;}
    let current=null;
    if(sedeId){
      const response=await api(`/api/clientes/${clienteId}/sedes`);
      current=(response.items||[]).find(x=>String(x.id)===String(sedeId));
      if(!current){showToast("No se encontró la sede en esta empresa.","error");return;}
    }
    const editing=!!current;
    openModal(editing?"Editar sucursal":"Agregar sucursal a la empresa",`<form id="coordSiteForm" class="form-grid se-sede-form" autocomplete="off">
      <div class="se-sede-form-heading full"><i data-lucide="store"></i><div><strong>Datos de la sucursal</strong><p>${options.clientName?`La sucursal se registrará para ${esc(options.clientName)}.`:"Registrá la sucursal en esta empresa."}</p></div></div>
      <div class="field full"><label>Nombre de la sede / tienda <span class="se-required">*</span></label><input name="nombre" maxlength="180" required placeholder="Ej. Restaurante Zona 10" value="${esc(current?.nombre||options.siteName||"")}"></div>
      <div class="field"><label>Código interno</label><input name="codigo" maxlength="30" placeholder="Ej. Z10-01" value="${esc(current?.codigo||"")}"></div>
      <div class="field"><label>Teléfono</label><input name="telefono" maxlength="20" inputmode="tel" placeholder="Ej. 2424-0000" value="${esc(current?.telefono||"")}"></div>
      <div class="se-sede-form-section full"><i data-lucide="map-pin"></i><strong>Ubicación</strong></div>
      <div class="field"><label>Municipio <span class="se-required">*</span></label><input name="municipio" maxlength="100" required placeholder="Ej. Guatemala" value="${esc(current?.municipio||"")}"></div>
      <div class="field"><label>Departamento <span class="se-required">*</span></label><input name="departamento" maxlength="100" required value="${esc(current?.departamento||"Guatemala")}"></div>
      <div class="field full"><label>Dirección completa <span class="se-required">*</span></label><textarea name="direccion" maxlength="450" rows="2" required placeholder="Avenida, calle, zona, local o centro comercial">${esc(current?.direccion||"")}</textarea></div>
      <div class="field full"><label>Referencia para llegar</label><textarea name="referencia_llegada" maxlength="400" rows="2" placeholder="Entrada, nivel, local o punto de referencia">${esc(current?.referencia_llegada||"")}</textarea></div>
      <div class="field full"><label>Observaciones</label><textarea name="observaciones" maxlength="500" rows="2" placeholder="Indicaciones adicionales (opcional)">${esc(current?.observaciones||"")}</textarea></div>
      <div class="se-sede-form-footer full"><span>* Campos obligatorios</span><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">${editing?"Guardar cambios":"Crear sucursal"}</button></div></div>
    </form>`);
    const form=$("#coordSiteForm");
    form?.addEventListener("submit",async e=>{
      e.preventDefault();const submit=form.querySelector('button[type="submit"]');
      if(submit.disabled)return;submit.disabled=true;
      try{
        const body=Object.fromEntries(new FormData(form).entries());
        const result=await api(editing?`/api/clientes/${clienteId}/sedes/${sedeId}`:`/api/clientes/${clienteId}/sedes`,{method:editing?"PATCH":"POST",body});
        showToast(result.message||(editing?"Sucursal actualizada.":"Sucursal creada."));
        state.userAdmin.catalogos=null;state.catalogs={};
        if(options.onSaved){
          if(form.isConnected)closeModal();
          await options.onSaved(result,body);
          return;
        }
        return openSedes(clienteId);
      }catch(error){showToast(error.message,"error");}
      finally{submit.disabled=false;}
    });
    window.lucide?.createIcons();
  }

  function adminSedeCambiarEstado(clienteId,sedeId,activar){
    openModal(activar?"Activar sucursal":"Desactivar sucursal",`<div class="confirm-card ${activar?"":"danger"}"><div class="confirm-icon"><i data-lucide="${activar?"circle-check-big":"triangle-alert"}"></i></div><div><h3>¿${activar?"Activar":"Desactivar"} esta sucursal?</h3><p>${activar?"Estará disponible para nuevas asignaciones y solicitudes.":"No podrá utilizarse para nuevas solicitudes; se conservará su historial."}</p></div></div><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn ${activar?"primary":"danger"}" type="button" data-action="confirmar-estado-sede-empresa" data-cliente-id="${esc(clienteId)}" data-id="${esc(sedeId)}" data-active="${activar?"1":"0"}">${activar?"Activar":"Desactivar"}</button></div>`);
    window.lucide?.createIcons();
  }

  async function openSedes(id){
    const d=await api(`/api/clientes/${id}/sedes`);
    const all=d.items||[];
    let q="",status="TODOS",page=1,size=10;
    openModal("Sedes del cliente",`<div class="modal-list-shell"><div class="form-actions" style="margin:0 0 14px;justify-content:flex-end"><button class="btn" type="button" data-action="importar-sedes-empresa" data-id="${esc(id)}"><i data-lucide="file-up"></i> Importar Excel / CSV / XML</button><button class="btn primary" type="button" data-action="nueva-sede-empresa" data-id="${esc(id)}"><i data-lucide="plus"></i> Agregar sucursal</button></div><div class="modal-list-tools"><div class="field modal-list-search"><label>Buscar</label><div class="input-with-icon"><i data-lucide="search"></i><input id="clientSitesModalSearch" type="search" placeholder="Código, sede, dirección o municipio"></div></div><div class="field"><label>Estado</label><select id="clientSitesModalStatus"><option value="TODOS">Todos</option><option value="ACTIVO">Activas</option><option value="INACTIVO">Inactivas</option></select></div><div class="field"><label>Por página</label><select id="clientSitesModalSize"><option>5</option><option selected>10</option><option>20</option><option>50</option></select></div></div><div id="clientSitesModalHost"></div></div>`);
    const paint=()=>{
      const host=$("#clientSitesModalHost");if(!host)return;
      let items=all.filter(x=>{
        const active=!!(x.Activo??x.activo);
        if(status!=="TODOS"&&(status==="ACTIVO")!==active)return false;
        if(!smartText(q))return true;
        return [x.codigo,x.CodigoSucursal,x.Nombre,x.nombre,x.Telefono,x.telefono,x.Direccion,x.direccion,x.Municipio,x.municipio,x.Departamento,x.departamento].some(v=>smartText(v).includes(smartText(q)));
      });
      items.sort((a,b)=>String(a.Nombre||a.nombre||"").localeCompare(String(b.Nombre||b.nombre||""),"es",{sensitivity:"base",numeric:true}));
      const total=items.length,pages=Math.max(1,Math.ceil(total/size));page=Math.min(page,pages);const shown=items.slice((page-1)*size,page*size);
      const rows=shown.map(x=>`<tr><td>${esc(x.codigo||x.CodigoSucursal||"—")}</td><td>${esc(x.Nombre||x.nombre||"—")}</td><td>${esc(x.Telefono||x.telefono||"—")}</td><td>${esc(x.Direccion||x.direccion||"—")}</td><td>${esc(x.Municipio||x.municipio||"—")}</td><td>${badge((x.Activo??x.activo)?"ACTIVA":"INACTIVA")}</td><td><div class="inline-actions"><button class="btn small" type="button" data-action="editar-sede-empresa" data-cliente-id="${esc(id)}" data-id="${esc(x.id)}">Editar</button><button class="btn small" type="button" data-action="estado-sede-empresa" data-cliente-id="${esc(id)}" data-id="${esc(x.id)}" data-active="${(x.Activo??x.activo)?"0":"1"}">${(x.Activo??x.activo)?"Desactivar":"Activar"}</button></div></td></tr>`);
      host.innerHTML=`${table(["Código","Sede","Teléfono","Dirección","Municipio","Estado","Acciones"],rows,"Este cliente no tiene sedes que coincidan con los filtros.")}${smartPager("modal-sedes",{pagina:page,paginas:pages,total,tamano:size})}`;
      $$("[data-list-key='modal-sedes']",host).forEach(btn=>{btn.removeAttribute("data-action");btn.addEventListener("click",()=>{if(btn.disabled)return;page=Math.max(1,Number(btn.dataset.page||1));paint();});});
      window.lucide?.createIcons();
    };
    $("#clientSitesModalSearch")?.addEventListener("input",e=>{q=e.currentTarget.value;page=1;paint();});
    $("#clientSitesModalStatus")?.addEventListener("change",e=>{status=e.currentTarget.value;page=1;paint();});
    $("#clientSitesModalSize")?.addEventListener("change",e=>{size=Number(e.currentTarget.value||10);page=1;paint();});
    paint();window.lucide?.createIcons();
  }


  const personnelAvailabilityOptions = ["DISPONIBLE","ASIGNADO","VACACIONES","NO_DISPONIBLE","INACTIVO"];
  const personnelAvailabilityPending = new Set();

  async function savePersonalAvailability(select) {
    const {id, savedValue} = select.dataset;
    if (personnelAvailabilityPending.has(id) || !select.value || select.value === savedValue) return;
    const value = select.value;
    let confirmedValue = savedValue;
    personnelAvailabilityPending.add(id);
    select.disabled = true;
    try {
      const result = await api(`/api/personal/${id}/disponibilidad`, {method:"PATCH", body:{disponibilidad:value}});
      confirmedValue = value;
      showToast(result.message || "Disponibilidad actualizada.");
    } catch (error) {
      showToast(error.message, "error");
      return;
    } finally {
      personnelAvailabilityPending.delete(id);
      const rendered = content.querySelector(`select[data-personnel-availability][data-id="${CSS.escape(id)}"]`);
      if (rendered) {
        rendered.value = confirmedValue;
        rendered.dataset.savedValue = confirmedValue;
        rendered.disabled = false;
      }
    }
    if (state.current === "personal") {
      await rerenderSmartList("personal");
    }
  }

  async function renderPersonal(isCurrent = () => true){
    setHeading("Clientes y personal", "Administra clientes, sedes, colaboradores y accesos del sistema.");
    const all=(await loadAllPaged("personal","/api/personal", false, isCurrent)).items;
    state.peopleCounts.personal=listCount("personal","total",all.length);
    await ensurePeopleCounts("personal");
    if (!isCurrent()) return;
    const jobs=smartUnique(all,x=>x.puesto||"");
    const states=smartUnique(all,x=>String(x.estado||"").toUpperCase());
    const availability=smartUnique(all,x=>String(x.disponibilidad||"").toUpperCase());
    const activeCount=listCount("personal","activos",all.filter(x=>/ACTIVO/.test(String(x.estado||"").toUpperCase())&&!/INACTIVO/.test(String(x.estado||"").toUpperCase())).length);
    const availableCount=listCount("personal","disponibles",all.filter(x=>String(x.disponibilidad||"").toUpperCase()==="DISPONIBLE").length);
    const assignedCount=listCount("personal","asignados",all.filter(x=>String(x.disponibilidad||"").toUpperCase()==="ASIGNADO").length);
    const vacationCount=listCount("personal","vacaciones",all.filter(x=>String(x.disponibilidad||"").toUpperCase()==="VACACIONES").length);
    const missingAvailability=all.filter(x=>!String(x.disponibilidad||"").trim()).length;
    const prefs=smartPrefs("personal",{orden:"nombre",direccion:"ASC",filtros:{peopleQuick:["TODOS"]}});
    const quickValues=normalizeSmartQuickValues(prefs.filtros?.peopleQuick);
    const quickSet=new Set(quickValues);
    let source=[...all];
    if(quickValues.length) source=source.filter(x=>quickValues.some(quick=>quick==="DISPONIBLES"?String(x.disponibilidad||"").toUpperCase()==="DISPONIBLE":quick==="ASIGNADOS"?String(x.disponibilidad||"").toUpperCase()==="ASIGNADO":quick==="VACACIONES"?String(x.disponibilidad||"").toUpperCase()==="VACACIONES":quick==="INACTIVOS"?(/INACTIVO/.test(String(x.estado||"").toUpperCase())||String(x.disponibilidad||"").toUpperCase()==="INACTIVO"):true));
    const result=smartListData("personal",source,{
      defaults:{orden:"nombre",direccion:"ASC",filtros:{peopleQuick:"TODOS"}},
      search:x=>[x.codigo,x.nombre,x.puesto,x.estado,x.disponibilidad,x.telefono,x.correo],
      filters:{estado:x=>String(x.estado||"").toUpperCase(),disponibilidad:x=>String(x.disponibilidad||"").toUpperCase(),puesto:x=>x.puesto||""},
      sort:{nombre:x=>x.nombre||"",codigo:x=>x.codigo||"",puesto:x=>x.puesto||"",estado:x=>x.estado||"",disponibilidad:x=>x.disponibilidad||""}
    });
    const rows=result.items.map(x=>{
      const menu=peopleActionMenu([
        {label:"Detalle",icon:"user-round",action:"detalle-personal",id:x.id},{label:"Historial de trabajos",icon:"history",action:"historial-personal",id:x.id}
      ]);
      const storedAvailability = String(x.disponibilidad || "").toUpperCase();
      const currentAvailability = personnelAvailabilityOptions.includes(storedAvailability) ? storedAvailability : "";
      return `<tr>
        <td>${entityAvatarLink(x.nombre||"Empleado",{entity:x,subtitle:x.codigo||"Empleado",className:"people-employee-identity"},"detalle-personal",x.id)}</td>
        <td><div class="people-primary-cell"><strong>${esc(formatDisplayLabel(x.puesto||"Sin cargo registrado"))}</strong></div></td>
        <td><div class="people-contact-cell">${x.telefono?`<strong>${esc(x.telefono)}</strong>`:""}${x.correo?`<span class="people-contact-detail" title="${esc(x.correo)}">${esc(x.correo)}</span>`:""}${!x.telefono&&!x.correo?`<span class="people-muted">Sin contacto registrado</span>`:""}</div></td>
        <td><select class="people-availability" data-personnel-availability data-id="${esc(x.id)}" data-saved-value="${esc(currentAvailability)}" aria-label="Disponibilidad de ${esc(x.nombre||"empleado")}. Se guarda al cambiarla." ${personnelAvailabilityPending.has(String(x.id))?"disabled":""}>${!currentAvailability?'<option value="" selected disabled>Sin registrar</option>':""}${personnelAvailabilityOptions.map(v=>`<option value="${v}" ${currentAvailability===v?"selected":""}>${esc(formatDisplayLabel(v))}</option>`).join("")}</select></td>
        <td>${peopleStatusBadge(x.estado||"INACTIVO")}</td>
        <td><div class="people-row-actions">${menu}</div></td>
      </tr>`;
    });
    const quicks=`<div class="people-quick-row"><span>Filtros rápidos:</span><div class="people-quick-list">${peopleQuickButton("personal","TODOS","Todos",listCount("personal","total",all.length),quickValues.length===0)}${peopleQuickButton("personal","DISPONIBLES","Disponibles",availableCount,quickSet.has("DISPONIBLES"))}${peopleQuickButton("personal","ASIGNADOS","Asignados",assignedCount,quickSet.has("ASIGNADOS"))}${peopleQuickButton("personal","VACACIONES","Vacaciones",vacationCount,quickSet.has("VACACIONES"))}${peopleQuickButton("personal","INACTIVOS","Inactivos",listCount("personal","total",all.length)-activeCount,quickSet.has("INACTIVOS"))}</div><span class="people-quick-hint">Puedes combinar varios.</span></div>${quickValues.length?`<div class="people-active-quick"><span>${quickValues.length} filtro${quickValues.length===1?"":"s"} activo${quickValues.length===1?"":"s"}</span><div>${quickValues.map(value=>`<button class="smart-quick-active" type="button" data-action="people-quick-filter" data-list-key="personal" data-value="${esc(value)}"><span>${esc(value.charAt(0)+value.slice(1).toLowerCase())}</span><i data-lucide="x"></i></button>`).join("")}</div></div>`:""}`;
    const p=smartPrefs("personal");
    const filters=`<section class="people-filter-section"><div class="people-filter-grid people-filter-grid-personal">
      <label class="people-field people-search"><span>Buscar</span><div><i data-lucide="search"></i><input type="search" data-smart-q="personal" value="${esc(p.q)}" placeholder="Buscar empleado, cargo o teléfono..." autocomplete="off"></div></label>
      <label class="people-field"><span>Estado</span><select data-smart-filter="estado" data-smart-key="personal">${smartOptions(states,p.filtros?.estado,"Todos")}</select></label>
      <label class="people-field"><span>Cargo</span><select data-smart-filter="puesto" data-smart-key="personal">${smartOptions(jobs,p.filtros?.puesto,"Todos")}</select></label>
      <label class="people-field"><span>Disponibilidad</span><select data-smart-filter="disponibilidad" data-smart-key="personal">${smartOptions(availability,p.filtros?.disponibilidad,"Todos")}</select></label>
      <label class="people-field"><span>Ordenar por</span><select data-smart-sort data-smart-key="personal"><option value="nombre" ${p.orden==="nombre"?"selected":""}>Nombre</option><option value="puesto" ${p.orden==="puesto"?"selected":""}>Cargo</option><option value="estado" ${p.orden==="estado"?"selected":""}>Estado</option><option value="disponibilidad" ${p.orden==="disponibilidad"?"selected":""}>Disponibilidad</option></select></label>
      <label class="people-field"><span>Dirección</span><select data-smart-direction data-smart-key="personal"><option value="ASC" ${p.direccion==="ASC"?"selected":""}>Ascendente</option><option value="DESC" ${p.direccion==="DESC"?"selected":""}>Descendente</option></select></label>
      <label class="people-field people-size"><span>Por página</span><select data-smart-size data-smart-key="personal">${[5,10,20,50].map(n=>`<option value="${n}" ${Number(p.tamano)===n?"selected":""}>${n}</option>`).join("")}</select></label>
      <div class="people-clear-wrap"><span>&nbsp;</span><button class="people-clear" type="button" data-action="smart-reset" data-list-key="personal"><i data-lucide="rotate-ccw"></i><span>Limpiar filtros</span></button></div>
    </div>${quicks}</section>`;
    const alert=missingAvailability?`<div class="people-inline-alert"><i data-lucide="triangle-alert"></i><span><strong>${missingAvailability}</strong> empleado${missingAvailability===1?"":"s"} no ${missingAvailability===1?"tiene":"tienen"} disponibilidad registrada.</span></div>`:"";
    content.innerHTML=`<div class="people-workspace">${peopleWorkspaceHeader("personal")}
      <section class="people-metrics">${peopleMetric("Personal activo",activeCount,"Colaboradores habilitados")}${peopleMetric("Disponibles",availableCount,"Disponibilidad actual")}${peopleMetric("Asignados",assignedCount,"Con trabajo asignado")}</section>
      <section class="people-context"><div><h2>Personal</h2><p>Administra colaboradores, cargos y disponibilidad.</p></div></section>
      ${filters}${alert}
      ${peopleTableShell("Personal",result,["Empleado","Cargo","Contacto","Disponibilidad","Estado","Acciones"],rows,smartPager("personal",result),"personal")}
    </div>`;
    window.lucide?.createIcons();
  }


  async function employeeForm(){
    const catalogs=await api("/api/personal/catalogos");
    const puestos=(catalogs.puestos||[]).map(x=>`<option value="${esc(x.id)}">${esc(x.nombre)}</option>`).join("");
    const today=new Date().toISOString().slice(0,10);
    openModal("Crear empleado",`<form id="employeeCreateForm" class="form-grid" autocomplete="off">
      <div class="field"><label>Código de empleado</label><input name="codigo_empleado" maxlength="20" placeholder="Ej. EMP-001" required></div>
      <div class="field"><label>Puesto</label><select name="puesto_id" required><option value="">Seleccionar puesto</option>${puestos}</select></div>
      <div class="field"><label>Nombres</label><input name="nombres" maxlength="100" required></div>
      <div class="field"><label>Apellidos</label><input name="apellidos" maxlength="100" required></div>
      <div class="field"><label>DPI</label><input name="dpi" maxlength="13" inputmode="numeric" placeholder="13 dígitos"></div>
      <div class="field"><label>NIT</label><input name="nit" maxlength="20"></div>
      <div class="field"><label>Fecha de nacimiento</label><input type="date" name="fecha_nacimiento"></div>
      <div class="field"><label>Fecha de ingreso</label><input type="date" name="fecha_ingreso" value="${today}" required></div>
      <div class="field"><label>Teléfono principal</label><input name="telefono_principal" maxlength="20" required></div>
      <div class="field"><label>Teléfono alterno</label><input name="telefono_alterno" maxlength="20"></div>
      <div class="field full"><label>Correo</label><input type="email" name="correo" maxlength="160"></div>
      <div class="field full"><label>Dirección de residencia</label><textarea name="direccion_residencia" maxlength="350" required></textarea></div>
      <div class="field"><label>Tipo de contratación</label><select name="tipo_contratacion" required><option value="FIJO">Fijo</option><option value="TEMPORAL">Temporal</option><option value="POR_SERVICIO">Por servicio</option><option value="OTRO">Otro</option></select></div>
      <div class="field"><label>Disponibilidad inicial</label><select name="disponibilidad"><option value="DISPONIBLE">Disponible</option><option value="NO_DISPONIBLE">No disponible</option><option value="VACACIONES">Vacaciones</option></select></div>
      <div class="field full"><label>Forma de pago</label><input name="forma_pago" maxlength="120" placeholder="Opcional"></div>
      <div class="field"><label>Contacto de emergencia</label><input name="contacto_emergencia_nombre" maxlength="160"></div>
      <div class="field"><label>Teléfono de emergencia</label><input name="contacto_emergencia_telefono" maxlength="20"></div>
      <div class="field full"><label>Observaciones</label><textarea name="observaciones" maxlength="700"></textarea></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit"><i data-lucide="user-round-plus"></i> Crear empleado</button></div></div>
    </form>`);
    const form=$("#employeeCreateForm");
    form?.addEventListener("submit",async e=>{e.preventDefault();const submit=form.querySelector('button[type="submit"]');submit.disabled=true;try{const body=Object.fromEntries(new FormData(form).entries());const result=await api("/api/personal",{method:"POST",body});showToast(result.message||"Empleado registrado correctamente.");closeModal();state.userAdmin.catalogos=null;await renderPersonal();}catch(err){showToast(err.message,"error");}finally{submit.disabled=false;}});
    window.lucide?.createIcons();
  }


  function userStatusView(x){
    const status=String(x.estado||"").toUpperCase();
    if(status==="BLOQUEADO") return `<span class="user-status user-status-blocked"><i data-lucide="lock-keyhole"></i> Bloqueado</span>`;
    if(status==="ACTIVO") return `<span class="user-status user-status-active"><i data-lucide="circle-check-big"></i> Activo</span>`;
    return `<span class="user-status user-status-inactive"><i data-lucide="circle-pause"></i> Inactivo</span>`;
  }

  function userPagination(meta){
    const page=Number(meta.pagina||1), pages=Math.max(1,Number(meta.paginas||1)), total=Number(meta.total||0);
    const start=total?((page-1)*Number(meta.tamano||10))+1:0;
    const end=Math.min(total,page*Number(meta.tamano||10));
    const nums=[];
    for(let p=Math.max(1,page-2);p<=Math.min(pages,page+2);p++) nums.push(p);
    return `<div class="user-pagination"><div class="user-pagination-copy">Mostrando <strong>${start}-${end}</strong> de <strong>${total}</strong></div><div class="pager-buttons">
      <button type="button" class="pager-button" data-action="usuario-pagina" data-page="1" ${page<=1?"disabled":""} aria-label="Primera página"><i data-lucide="chevrons-left"></i></button>
      <button type="button" class="pager-button" data-action="usuario-pagina" data-page="${page-1}" ${page<=1?"disabled":""} aria-label="Página anterior"><i data-lucide="chevron-left"></i></button>
      ${nums.map(n=>`<button type="button" class="pager-button ${n===page?"active":""}" data-action="usuario-pagina" data-page="${n}">${n}</button>`).join("")}
      <button type="button" class="pager-button" data-action="usuario-pagina" data-page="${page+1}" ${page>=pages?"disabled":""} aria-label="Página siguiente"><i data-lucide="chevron-right"></i></button>
      <button type="button" class="pager-button" data-action="usuario-pagina" data-page="${pages}" ${page>=pages?"disabled":""} aria-label="Última página"><i data-lucide="chevrons-right"></i></button>
    </div></div>`;
  }

  function userReportParams(){
    const f=state.userAdmin,q=new URLSearchParams();
    if(f.q)q.set("q",f.q);if(f.rol_id)q.set("rol_id",f.rol_id);if(f.estado)q.set("estado",f.estado);if(f.fecha_desde)q.set("fecha_desde",f.fecha_desde);if(f.fecha_hasta)q.set("fecha_hasta",f.fecha_hasta);
    q.set("pagina",String(f.pagina));q.set("tamano",String(f.tamano));q.set("orden",f.orden);q.set("direccion",f.direccion);
    return q.toString();
  }

  async function ensureUserCatalogs(force=false){
    if(!state.userAdmin.catalogos||force) state.userAdmin.catalogos=await api("/api/usuarios/catalogos");
    return state.userAdmin.catalogos;
  }

  const clientVisibilityLabels = {
    ENCARGADO: "Encargado / Supervisor",
    SUPERVISOR: "Gerente"
  };

  async function renderUsuarios(isCurrent){
    if (!isCurrent) {
      const revision = ++filterRevision;
      const module = state.current;
      isCurrent = () => revision === filterRevision && module === state.current;
    }
    if(state.role!=="COORDINADOR") throw new Error("Solo Coordinación puede administrar usuarios.");
    setHeading("Clientes y personal", "Administra clientes, sedes, colaboradores y accesos del sistema.");
    const f=state.userAdmin;
    const [d,catalogs]=await Promise.all([api(`/api/usuarios?${userReportParams()}`),ensureUserCatalogs()]);
    if (!isCurrent()) return;
    f.total=d.pagination?.total||0;f.paginas=d.pagination?.paginas||1;f.pagina=d.pagination?.pagina||1;
    const s=d.summary||{};
    state.peopleCounts.usuarios=normalizeNumber(s.total||d.pagination?.total);
    await ensurePeopleCounts("usuarios");
    if (!isCurrent()) return;
    const roles=(catalogs.roles||[]).map(x=>`<option value="${esc(x.id)}" ${String(f.rol_id)===String(x.id)?"selected":""}>${esc(x.nombre)}</option>`).join("");
    const rows=(d.items||[]).map(x=>{
      const blocked=String(x.estado||"").toUpperCase()==="BLOQUEADO";
      const menu=peopleActionMenu([
        x.visibilidad?{label:"Visibilidad de cliente",icon:"shield-check",action:"visibilidad-usuario",id:x.id,attrs:`data-visibility="${esc(x.visibilidad)}"`}:null,
        {label:"Editar usuario",icon:"pencil",action:"editar-usuario",id:x.id},
        {label:"Restablecer contraseña",icon:"key-round",action:"restablecer-usuario",id:x.id},
        blocked?{label:"Desbloquear acceso",icon:"unlock-keyhole",action:"desbloquear-usuario",id:x.id}:null,
        {separator:true},
        {label:x.activo?"Desactivar acceso":"Activar acceso",icon:x.activo?"user-round-x":"user-round-check",action:"cambiar-estado-usuario",id:x.id,danger:!!x.activo,attrs:`data-active="${x.activo?"0":"1"}" data-name="${esc(x.usuario||"")}"`}
      ]);
      return `<tr>
        <td>${entityAvatarLink(x.nombre||x.usuario||"Usuario",{entity:x,subtitle:x.usuario?`@${x.usuario}`:"Usuario del sistema",className:"people-user-identity"},"ver-usuario",x.id)}</td>
        <td><span class="people-role-badge">${esc(formatDisplayLabel(x.rol||"—"))}</span></td>
        <td data-label="Autorización">${x.visibilidad
          ? `<span class="people-role-badge user-visibility-badge">${esc(clientVisibilityLabels[x.visibilidad] || "Sin especificar")}</span>`
          : '<span class="people-muted">No aplica</span>'}</td>
        <td><div class="people-contact-cell"><span class="people-contact-detail" title="${esc(x.correo||"Sin correo registrado")}">${esc(x.correo||"Sin correo registrado")}</span></div></td>
        <td><div class="people-date-cell">${x.ultimo_acceso?fmt(x.ultimo_acceso):`<span class="people-muted">Sin acceso reciente</span>`}</div></td>
        <td>${userStatusView(x)}</td>
        <td><div class="people-row-actions"><button class="people-outline-action" type="button" data-action="ver-usuario" data-id="${esc(x.id)}"><i data-lucide="eye"></i><span>Ver detalle</span></button>${menu}</div></td>
      </tr>`;
    });
    const quicks=`<div class="people-quick-row"><span>Filtros rápidos:</span><button class="people-quick ${!f.estado?"active":""}" type="button" data-action="usuario-filtro-estado" data-status=""><span>Todos</span><b>${normalizeNumber(s.total)}</b></button><button class="people-quick ${f.estado==="ACTIVO"?"active":""}" type="button" data-action="usuario-filtro-estado" data-status="ACTIVO"><span>Activos</span><b>${normalizeNumber(s.activos)}</b></button><button class="people-quick ${f.estado==="INACTIVO"?"active":""}" type="button" data-action="usuario-filtro-estado" data-status="INACTIVO"><span>Inactivos</span><b>${normalizeNumber(s.inactivos)}</b></button><button class="people-quick ${f.estado==="BLOQUEADO"?"active":""}" type="button" data-action="usuario-filtro-estado" data-status="BLOQUEADO"><span>Bloqueados</span><b>${normalizeNumber(s.bloqueados)}</b></button></div>`;
    const filters=`<section class="people-filter-section users-filter-section"><form id="userReportFilters" class="people-filter-grid people-filter-grid-users">
      <label class="people-field people-search"><span>Buscar</span><div><i data-lucide="search"></i><input type="search" name="q" value="${esc(f.q)}" placeholder="Buscar usuario, correo o rol..." autocomplete="off"></div></label>
      <label class="people-field"><span>Estado</span><select name="estado"><option value="">Todos</option><option value="ACTIVO" ${f.estado==="ACTIVO"?"selected":""}>Activos</option><option value="INACTIVO" ${f.estado==="INACTIVO"?"selected":""}>Inactivos</option><option value="BLOQUEADO" ${f.estado==="BLOQUEADO"?"selected":""}>Bloqueados</option></select></label>
      <label class="people-field"><span>Rol</span><select name="rol_id"><option value="">Todos los roles</option>${roles}</select></label>
      <label class="people-field"><span>Desde</span><input type="date" name="fecha_desde" value="${esc(f.fecha_desde)}"></label>
      <label class="people-field"><span>Hasta</span><input type="date" name="fecha_hasta" value="${esc(f.fecha_hasta)}"></label>
      <label class="people-field"><span>Ordenar por</span><select name="orden"><option value="FECHA" ${f.orden==="FECHA"?"selected":""}>Registro</option><option value="NOMBRE" ${f.orden==="NOMBRE"?"selected":""}>Nombre</option><option value="ROL" ${f.orden==="ROL"?"selected":""}>Rol</option><option value="ESTADO" ${f.orden==="ESTADO"?"selected":""}>Estado</option><option value="ULTIMO_ACCESO" ${f.orden==="ULTIMO_ACCESO"?"selected":""}>Último acceso</option></select></label>
      <label class="people-field"><span>Dirección</span><select name="direccion"><option value="DESC" ${f.direccion==="DESC"?"selected":""}>Descendente</option><option value="ASC" ${f.direccion==="ASC"?"selected":""}>Ascendente</option></select></label>
      <label class="people-field people-size"><span>Por página</span><select name="tamano">${[5,10,20,50].map(n=>`<option value="${n}" ${Number(f.tamano)===n?"selected":""}>${n}</option>`).join("")}</select></label>
      <div class="people-user-filter-actions"><button class="people-clear" type="button" data-action="usuarios-limpiar"><i data-lucide="rotate-ccw"></i><span>Limpiar</span></button><button class="people-apply" type="submit"><i data-lucide="filter"></i><span>Aplicar filtros</span></button></div>
    </form>${quicks}</section>`;
    const alert=normalizeNumber(s.bloqueados)>0?`<div class="people-inline-alert warning"><i data-lucide="lock-keyhole"></i><span><strong>${normalizeNumber(s.bloqueados)}</strong> usuario${normalizeNumber(s.bloqueados)===1?" está":"s están"} bloqueado${normalizeNumber(s.bloqueados)===1?"":"s"}.</span><button type="button" data-action="usuario-filtro-estado" data-status="BLOQUEADO">Ver usuarios</button></div>`:"";
    const portalNote=`<div class="people-portal-note"><i data-lucide="shield-check"></i><div><strong>Portal privado</strong><span>Las cuentas son creadas y administradas por Coordinación.</span></div></div>`;
    const tableResult={total:normalizeNumber(d.pagination?.total),items:d.items||[]};
    content.innerHTML=`<div class="people-workspace">${peopleWorkspaceHeader("usuarios")}
      <section class="people-metrics">${peopleMetric("Usuarios activos",s.activos,"Acceso habilitado")}${peopleMetric("Bloqueados",s.bloqueados,"Requieren revisión")}${peopleMetric("Acceso reciente",s.acceso_30_dias,"Últimos 30 días")}</section>
      <section class="people-context"><div><h2>Usuarios del sistema</h2><p>Gestiona credenciales, roles y acceso al portal.</p></div></section>
      ${portalNote}${filters}${alert}
      <section class="people-table-section"><div class="people-table-toolbar"><div><h3>Usuarios</h3><span>${normalizeNumber(d.pagination?.total)} resultados</span></div></div>${rows.length?`<div class="people-table-scroll se-table-responsive-scope"><table class="people-table se-wide-table users-visibility-table"><thead><tr><th>Usuario</th><th>Rol</th><th>Autorización</th><th>Correo electrónico</th><th>Último acceso</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${rows.join("")}</tbody></table></div>`:`<div class="people-empty"><i data-lucide="users-round"></i><h3>No encontramos usuarios con estos filtros.</h3><p>Prueba cambiando Estado, Rol o el rango de fechas.</p><button class="btn small" type="button" data-action="usuarios-limpiar"><i data-lucide="rotate-ccw"></i><span>Limpiar filtros</span></button></div>`}${userPagination(d.pagination||{})}</section>
    </div>`;
    window.lucide?.createIcons();
    const form=$("#userReportFilters");
    const applyUserFilters = () => {
      clearTimeout(smartSearchTimer);
      const data = Object.fromEntries(new FormData(form).entries());
      Object.assign(f,{q:String(data.q||""),rol_id:String(data.rol_id||""),estado:String(data.estado||""),fecha_desde:String(data.fecha_desde||""),fecha_hasta:String(data.fecha_hasta||""),tamano:Number(data.tamano||10),orden:String(data.orden||f.orden||"FECHA"),direccion:String(data.direccion||f.direccion||"DESC"),pagina:1});
      refreshFilteredView(renderUsuarios, ++filterRevision, state.current).catch(err=>showToast(err.message,"error"));
    };
    form?.addEventListener("submit", event => {
      event.preventDefault();
      applyUserFilters();
    });
    form?.addEventListener("change", event => {
      if (event.target.name !== "q") applyUserFilters();
    });
  }

  function userRolePortalById(id){
    const role=(state.userAdmin.catalogos?.roles||[]).find(x=>String(x.id)===String(id));
    return String(role?.portal||role?.codigo||"").toUpperCase();
  }

  function syncUserOwnerFields(form,currentId=""){
    if(!form)return;
    const role=userRolePortalById(form.rol_id?.value);
    const emp=form.querySelector('[data-owner="empleado"]');
    if(emp)emp.hidden=!(["COORDINADOR","TECNICO"].includes(role));
    form.querySelectorAll('[data-owner="cliente"]').forEach(el=>{el.hidden=role!=="CLIENTE";});
    const empresa=form.elements.namedItem("cliente_id");
    const nombre=form.elements.namedItem("nombre_completo");
    if(empresa)empresa.required=role==="CLIENTE";
    if(nombre)nombre.required=role==="CLIENTE";
    if(role==="CLIENTE"&&form.empleado_id)form.empleado_id.value="";
  }

  function userOwnerOptions(items,currentId,selected,type){
    return (items||[]).map(x=>{const used=x.usuario_id&&String(x.usuario_id)!==String(currentId);const label=type==="empleado"?`${x.codigo||""} · ${x.nombre}${x.puesto?` · ${x.puesto}`:""}`:`${x.cliente} · ${x.nombre}${x.cargo?` · ${x.cargo}`:""}`;return `<option value="${esc(x.id)}" ${String(x.id)===String(selected)?"selected":""} ${used?"disabled":""}>${esc(label)}${used?` · ya vinculado a ${esc(x.usuario||"otro usuario")}`:""}</option>`;}).join("");
  }

  function generateTemporaryPassword(){
    if(!window.crypto?.getRandomValues){showToast("Este navegador no permite generar contraseñas seguras.","error");return null;}
    const chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%";
    const numbers=new Uint32Array(24);window.crypto.getRandomValues(numbers);
    // La cuenta exige mayúscula, minúscula y número; el resto sale de un generador criptográfico.
    return "Se"+String(numbers[0]%10)+Array.from(numbers.slice(1,15),x=>chars[x%chars.length]).join("");
  }
  function wireTemporaryPassword(form){
    const btn=form?.querySelector('[data-generate-password]');if(!btn)return;
    btn.onclick=()=>{const pw=generateTemporaryPassword();if(!pw)return;form.elements.contrasena.value=pw;form.elements.confirmacion.value=pw;form.elements.contrasena.type="text";showToast("Contraseña generada. Guardala de forma segura y compartila por un canal privado.");};
  }

  async function userForm(usuarioId=null){
    const catalogs=await ensureUserCatalogs(true);
    let current=null;
    if(usuarioId){const d=await api(`/api/usuarios/${usuarioId}`);current=d.item;}
    const roleId=current?.rol_id||(catalogs.roles||[])[0]?.id||"";
    const roles=(catalogs.roles||[]).map(x=>`<option value="${esc(x.id)}" ${String(x.id)===String(roleId)?"selected":""}>${esc(x.nombre)}</option>`).join("");
    const empresas=(catalogs.clientes||[]).filter(x=>x.activo||String(x.id)===String(current?.cliente_id)).map(x=>`<option value="${esc(x.id)}" ${String(x.id)===String(current?.cliente_id)?"selected":""}>${esc(x.nombre)}${!x.activo?" (inactiva)":""}</option>`).join("");
    openModal(current?"Editar usuario":"Registrar usuario",`<form id="userAdminForm" class="form-grid user-admin-form" autocomplete="off">
      <div class="user-form-intro full"><span><i data-lucide="${current?"user-round-cog":"user-round-plus"}"></i></span><div><strong>${current?`Editar ${esc(current.usuario)}`:"Nueva cuenta del portal privado"}</strong><p>${current?"Actualiza el rol, vínculo y datos de acceso. La contraseña se administra por separado.":"La cuenta será creada por Coordinación y quedará obligada a cambiar la contraseña temporal al ingresar."}</p></div></div>
      <div class="user-form-section full"><span>01</span><strong>Acceso y datos de la cuenta</strong></div>
      <div class="field"><label>Rol</label><select name="rol_id" required>${roles}</select></div>
      <div class="field"><label>Nombre de usuario</label><input name="usuario" maxlength="60" value="${esc(current?.usuario||"")}" placeholder="ej. jperez" required><small>Letras, números, punto, guion o guion bajo.</small></div>
      <div class="field full"><label>Correo de acceso</label><input type="email" name="correo" maxlength="160" value="${esc(current?.correo||"")}" placeholder="usuario@empresa.com"><small>Opcional, pero debe ser único si se registra.</small></div>
      <div class="field full" data-owner="empleado"><label>Empleado vinculado</label><select name="empleado_id"><option value="">Seleccionar empleado</option>${userOwnerOptions(catalogs.empleados,current?.id,current?.empleado_id,"empleado")}</select><small>Obligatorio para Coordinador y Técnico.</small></div>
      <div class="field full" data-owner="cliente"><label>Empresa a la que pertenece *</label><select name="cliente_id"><option value="">Seleccionar empresa cliente</option>${empresas}</select><small>Elegí la empresa una sola vez. Cada cuenta se vincula internamente a su propio contacto, nunca al contacto principal empresarial.</small></div>
      <div class="field full" data-owner="cliente"><label>Nombre completo de la persona *</label><input name="nombre_completo" maxlength="180" placeholder="Ej. Juan Pérez" value="${esc(current?.nombre_contacto||(userRolePortalById(roleId)==='CLIENTE'?current?.nombre:"")||"")}"></div>
      <div class="field" data-owner="cliente"><label>Cargo de la persona</label><input name="cargo_contacto" maxlength="120" value="${esc(current?.cargo_contacto||"")}" placeholder="Ej. Encargado de mantenimiento"></div>
      <div class="field" data-owner="cliente"><label>Teléfono de la persona</label><input name="telefono_contacto" maxlength="20" value="${esc(current?.telefono_contacto||"")}" placeholder="Ej. +502 5555 5555"></div>
      <div class="field full" data-owner="cliente"><div class="notice-card"><strong>Visibilidad de cliente</strong><p>Las cuentas nuevas ven sus propios registros. Podés cambiar la autorización desde el menú de acciones del usuario.</p></div></div>
      ${current?`<div class="field full"><label class="switch-row"><input type="checkbox" name="activo" ${current.activo?"checked":""}><span>Cuenta activa</span></label><small>Desactivar una cuenta cierra sus sesiones activas.</small></div>`:`<div class="user-form-section full"><span>02</span><strong>Seguridad inicial</strong></div><div class="field"><label>Contraseña temporal</label><div class="password-control"><input type="password" name="contrasena" minlength="8" autocomplete="new-password" required><button type="button" class="password-toggle" data-toggle-password aria-label="Mostrar contraseña"><i data-lucide="eye"></i></button></div><small>Mayúscula, minúscula y número.</small><button class="btn small" type="button" data-generate-password><i data-lucide="wand-sparkles"></i> Generar contraseña segura</button></div><div class="field"><label>Confirmar contraseña</label><div class="password-control"><input type="password" name="confirmacion" minlength="8" autocomplete="new-password" required><button type="button" class="password-toggle" data-toggle-password aria-label="Mostrar contraseña"><i data-lucide="eye"></i></button></div></div>`}
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit"><i data-lucide="save"></i> ${current?"Guardar cambios":"Crear usuario"}</button></div></div>
    </form>`);
    const form=$("#userAdminForm");wireTemporaryPassword(form);syncUserOwnerFields(form,current?.id||"");
    form?.rol_id?.addEventListener("change",()=>syncUserOwnerFields(form,current?.id||""));
    form?.addEventListener("submit",async e=>{e.preventDefault();const submit=form.querySelector('button[type="submit"]');submit.disabled=true;try{const raw=Object.fromEntries(new FormData(form).entries());raw.activo=current?!!form.activo?.checked:true;const result=await api(current?`/api/usuarios/${current.id}`:"/api/usuarios",{method:current?"PATCH":"POST",body:raw});showToast(result.message||"Usuario guardado.");closeModal();state.userAdmin.catalogos=null;state.userAdmin.pagina=1;await renderUsuarios();}catch(err){showToast(err.message,"error");}finally{submit.disabled=false;}});
    window.lucide?.createIcons();
  }

  function manageClientVisibility(usuarioId, currentMode){
    openModal("Visibilidad de cliente", `<form id="clientVisibilityForm" class="form-grid">
      <div class="field full">
        <label for="clientRecordVisibility">Visibilidad de solicitudes y órdenes</label>
        <select id="clientRecordVisibility" name="visibilidad">${optionList([
          ["ENCARGADO", `${clientVisibilityLabels.ENCARGADO} · solo sus registros`],
          ["SUPERVISOR", `${clientVisibilityLabels.SUPERVISOR} · todos los registros de su empresa`]
        ], 0, x => x[1], currentMode || "ENCARGADO")}</select>
      </div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Guardar permisos</button></div></div>
    </form>`);
    const form = $("#clientVisibilityForm");
    form.addEventListener("submit", async event => {
      event.preventDefault();
      const submit = form.querySelector('button[type="submit"]');
      submit.disabled = true;
      try {
        await api(`/api/usuarios/${usuarioId}/visibilidad-cliente`, {
          method: "PATCH", body: {visibilidad: form.elements.visibilidad.value}
        });
      } catch (err) {
        showToast(err.message, "error");
        submit.disabled = false;
        return;
      }
      showToast("Permisos de la cuenta actualizados.");
      closeModal();
      if (state.current === "usuarios") renderUsuarios().catch(err => showToast(err.message, "error"));
    });
  }


  async function openUserDetail(id){
    const d=await api(`/api/usuarios/${id}`),u=d.item||{};
    const sessions=(d.sesiones||[]).map(x=>`<article class="admin-session ${x.activa?"live":""}"><span><i data-lucide="${x.activa?"monitor-check":"monitor-x"}"></i></span><div><strong>${esc(describeAgent(x.agente))}${x.activa?` <em>Activa</em>`:""}</strong><p>${esc(x.ip||"IP no disponible")} · ${fmt(x.iniciada)}</p><small>${x.activa?`Expira ${fmt(x.expira)}`:`Cerrada ${fmt(x.cerrada)}${x.motivo_cierre?` · ${esc(x.motivo_cierre)}`:""}`}</small></div></article>`).join("")||`<div class="empty-state compact">Sin historial de sesiones.</div>`;
    const events=(d.actividad||[]).map(x=>`<li><span>${badge(x.operacion)}</span><div><strong>${esc(x.objeto||"Evento")}</strong><small>${fmt(x.fecha)}${x.observacion?` · ${esc(x.observacion)}`:""}</small></div></li>`).join("")||`<li class="muted">Sin actividad reciente registrada.</li>`;
    openModal(`Usuario · ${u.usuario}`,`<div class="user-detail-hero"><span class="user-detail-avatar"><i data-lucide="user-round"></i></span><div><span>${esc(u.rol||"USUARIO")}</span><h3>${esc(u.nombre||u.usuario)}</h3><p>@${esc(u.usuario)}${u.correo?` · ${esc(u.correo)}`:""}</p></div>${userStatusView({estado:u.bloqueado?"BLOQUEADO":(u.activo?"ACTIVO":"INACTIVO")})}</div>
      <div class="info-grid user-detail-grid">
        <div class="info-item"><span>Tipo de cuenta</span><strong>${esc(u.tipo_cuenta||"—")}</strong></div><div class="info-item"><span>Vínculo</span><strong>${esc(u.codigo_empleado?`${u.codigo_empleado} · ${u.puesto||"Empleado"}`:(u.cliente||"—"))}</strong></div>
        <div class="info-item"><span>Fecha de registro</span><strong>${fmt(u.creado_en)}</strong></div><div class="info-item"><span>Último acceso</span><strong>${fmt(u.ultimo_acceso)}</strong></div>
        <div class="info-item"><span>Intentos fallidos</span><strong>${normalizeNumber(u.intentos_fallidos)}</strong></div><div class="info-item"><span>Cambio de contraseña</span><strong>${u.requiere_cambio_contrasena?"Pendiente":"Al día"}</strong></div>
      </div>
      <div class="user-detail-actions"><a class="btn" href="/api/usuarios/${encodeURIComponent(u.id)}/reporte.pdf" download><i data-lucide="file-down"></i> Descargar PDF</a>${u.cliente_id?`<button class="btn" data-action="visibilidad-usuario" data-id="${esc(u.id)}" data-visibility="${esc(d.visibilidad||"ENCARGADO")}"><i data-lucide="shield-check"></i> Visibilidad de cliente</button>`:""}<button class="btn" data-action="editar-usuario" data-id="${esc(u.id)}"><i data-lucide="pencil"></i> Editar</button><button class="btn" data-action="restablecer-usuario" data-id="${esc(u.id)}"><i data-lucide="key-round"></i> Restablecer contraseña</button>${u.bloqueado?`<button class="btn" data-action="desbloquear-usuario" data-id="${esc(u.id)}"><i data-lucide="unlock-keyhole"></i> Desbloquear</button>`:""}<button class="btn ${u.activo?"danger":"primary"}" data-action="cambiar-estado-usuario" data-id="${esc(u.id)}" data-active="${u.activo?"0":"1"}" data-name="${esc(u.usuario)}"><i data-lucide="${u.activo?"user-round-x":"user-round-check"}"></i> ${u.activo?"Desactivar":"Activar"}</button></div>
      <div class="user-detail-columns"><section><h3 class="section-title">Sesiones recientes</h3><div class="admin-session-list">${sessions}</div></section><section><h3 class="section-title">Actividad de auditoría</h3><ul class="admin-audit-list">${events}</ul></section></div>`);
    window.lucide?.createIcons();
  }

  async function resetUserPassword(id){
    const d=await api(`/api/usuarios/${id}`),u=d.item||{};
    openModal("Restablecer contraseña",`<form id="adminResetPassword" class="form-grid"><div class="security-warning full"><i data-lucide="key-round"></i><div><strong>${esc(u.nombre||u.usuario)}</strong><p>Se cerrarán sus otras sesiones y deberá cambiar la contraseña temporal al volver a ingresar.</p></div></div><div class="field"><label>Contraseña temporal</label><div class="password-control"><input type="password" name="contrasena" minlength="8" autocomplete="new-password" required><button type="button" class="password-toggle" data-toggle-password><i data-lucide="eye"></i></button></div></div><div class="field"><label>Confirmar contraseña</label><div class="password-control"><input type="password" name="confirmacion" minlength="8" autocomplete="new-password" required><button type="button" class="password-toggle" data-toggle-password><i data-lucide="eye"></i></button></div></div><div class="field full"><button class="btn small" type="button" data-generate-password><i data-lucide="wand-sparkles"></i> Generar contraseña segura</button><small>Debe incluir mayúscula, minúscula y número.</small><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Restablecer contraseña</button></div></div></form>`);
    const form=$("#adminResetPassword");wireTemporaryPassword(form);form?.addEventListener("submit",async e=>{e.preventDefault();const body=Object.fromEntries(new FormData(form).entries());if(body.contrasena!==body.confirmacion)return showToast("Las contraseñas no coinciden.","error");const submit=form.querySelector('button[type="submit"]');submit.disabled=true;try{const r=await api(`/api/usuarios/${id}/restablecer-contrasena`,{method:"POST",body});showToast(r.message);closeModal();await renderUsuarios();}catch(err){showToast(err.message,"error");}finally{submit.disabled=false;}});window.lucide?.createIcons();
  }

  function confirmUserState(id,activate,name){
    openModal(activate?"Activar usuario":"Desactivar usuario",`<div class="confirm-state-card ${activate?"activate":"deactivate"}"><span><i data-lucide="${activate?"user-round-check":"user-round-x"}"></i></span><div><h3>${activate?"Habilitar acceso":"Deshabilitar acceso"}</h3><p>${activate?`¿Deseas activar la cuenta <strong>${esc(name||`#${id}`)}</strong>?`:`¿Deseas desactivar la cuenta <strong>${esc(name||`#${id}`)}</strong>? Sus sesiones activas se cerrarán.`}</p></div></div><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn ${activate?"primary":"danger"}" type="button" data-action="confirmar-estado-usuario" data-id="${esc(id)}" data-active="${activate?"1":"0"}">${activate?"Activar usuario":"Desactivar usuario"}</button></div>`);
    window.lucide?.createIcons();
  }

  async function renderEquipos(isCurrent = () => true){
    setHeading("Equipo y mantenimiento", "Inventario técnico, disponibilidad y mantenimiento interno.");
    const all=(await loadAllPaged("equipos","/api/equipos", false, isCurrent)).items;
    if (!isCurrent()) return;
    const categories=listFacet("equipos","categoria",smartUnique(all,x=>x.Categoria||x.categoria||""));
    const states=listFacet(state.current,"estado",smartUnique(all,x=>String(x.Estado||x.estado||"").toUpperCase()));
    const result=smartListData("equipos",all,{
      defaults:{orden:"nombre",direccion:"ASC"},
      search:x=>[x.codigo,x.CodigoEquipo,x.Nombre,x.nombre,x.Categoria,x.categoria,x.Marca,x.marca,x.Modelo,x.modelo,x.Serie,x.serie,x.ubicacion,x.vehiculo_codigo],
      filters:{estado:x=>String(x.Estado||x.estado||"").toUpperCase(),categoria:x=>String(x.Categoria||x.categoria||""),resguardo:x=>String(x.resguardo_tipo||"SIN_DEFINIR")},
      sort:{nombre:x=>x.Nombre||x.nombre||"",codigo:x=>x.codigo||x.CodigoEquipo||"",estado:x=>x.Estado||x.estado||"",ubicacion:x=>x.ubicacion||"",fallas:x=>Number(x.fallas_abiertas||0)}
    });
    const summary=coordinatorCompactMetrics([
      {label:"Total de equipos",value:listCount("equipos","total",all.length),icon:"package-search",tone:"blue"},
      {label:"Disponibles",value:listCount("equipos","disponibles",0),icon:"circle-check-big",tone:"green"},
      {label:"En mantenimiento",value:listCount("equipos","mantenimiento",0),icon:"settings",tone:"amber"},
      {label:"Con fallas",value:listCount("equipos","fallas",0),icon:"triangle-alert",tone:"red"}
    ],"equipment-summary");
    const canManageEquipment=state.role==="COORDINADOR";
    const rows=result.items.map(x=>{
      const current=String(x.Estado||x.estado||"DISPONIBLE").toUpperCase();
      const detail=`<button class="equipment-action-button equipment-detail-action" type="button" data-action="detalle-equipo" data-id="${esc(x.id)}"><i data-lucide="eye"></i><span>Ver detalle</span></button>`;
      const manage=canManageEquipment?`<button class="equipment-action-button equipment-save-action" type="button" data-action="editar-equipo" data-id="${esc(x.id)}"><i data-lucide="pencil"></i><span>Editar</span></button>`:"";
      return `<tr>
        <td><div class="se-cell-stack"><strong>${esc(x.Nombre||x.nombre||"—")}</strong><span class="mono se-cell-muted">${esc(x.codigo||x.CodigoEquipo||"—")}</span>${x.Modelo||x.modelo?`<small class="se-cell-muted">${esc(x.Modelo||x.modelo)}</small>`:""}</div></td>
        <td><div class="se-cell-stack"><strong>${esc(x.Categoria||x.categoria||"—")}</strong><span class="se-cell-muted">${esc(x.Marca||x.marca||"—")}</span></div></td>
        <td><div class="se-cell-stack">${managementBadge(current)}<span class="se-cell-muted">${normalizeNumber(x.fallas_abiertas)} ${normalizeNumber(x.fallas_abiertas)===1?"falla abierta":"fallas abiertas"}</span></div></td>
        <td>${esc(x.ubicacion||"Por definir")}</td>
        <td class="se-table-actions"><div class="equipment-row-actions">${detail}${manage}</div></td>
      </tr>`;
    });
    const equipmentHeaders=["Equipo / código","Categoría / marca","Estado / fallas","Resguardo habitual","Acciones"];
    content.innerHTML=`${equipmentMaintenanceTabs("equipos")}${summary}<section class="panel smart-list-panel equipment-panel coord-data-surface"><div class="panel-header equipment-heading"><div><span class="coord-section-kicker">Inventario</span><h2>Equipo</h2><p class="muted">Estado operativo y resguardo habitual por separado. Los equipos permanecen en su bodega o vehículo registrado hasta que cambies su ficha.</p></div>${canManageEquipment?`<button class="btn primary" type="button" data-action="nuevo-equipo"><i data-lucide="circle-plus"></i> Registrar equipo</button>`:""}</div><div class="panel-body">${smartControls("equipos",{placeholder:"Código, equipo, vehículo, bodega, marca o serie",filters:[{name:"estado",label:"Estado",options:states},{name:"categoria",label:"Categoría",options:categories},{name:"resguardo",label:"Resguardo",options:[["BODEGA","Bodega"],["VEHICULO","Vehículo"],["SIN_DEFINIR","Por definir"]]}],sorts:[["nombre","Equipo"],["codigo","Código"],["estado","Estado"],["ubicacion","Resguardo"],["fallas","Fallas abiertas"]]})}${smartResultsMeta(result,"equipos")}</div>${table(equipmentHeaders,rows,"No hay equipos que coincidan con los filtros.")}${smartPager("equipos",result)}</section>`;
    window.lucide?.createIcons();
  }

  async function renderMantenimientos(isCurrent = () => true){
    setHeading("Equipo y mantenimiento", "Inventario técnico, disponibilidad y mantenimiento interno.");
    const all=(await loadAllPaged("mantenimientos","/api/mantenimientos", false, isCurrent)).items;
    if (!isCurrent()) return;
    const types=smartUnique(all,x=>String(x.tipo||"").toUpperCase());
    const states=listFacet(state.current,"estado",smartUnique(all,x=>String(x.Estado||x.estado||"").toUpperCase()));
    const result=smartListData("mantenimientos",all,{
      defaults:{orden:"programada",direccion:"DESC"},
      search:x=>[x.id,x.codigo_equipo,x.equipo,x.tipo,x.Estado,x.estado,x.Diagnostico,x.diagnostico,x.TrabajoRequerido,x.trabajo_requerido,x.Resultado,x.resultado],
      filters:{tipo:x=>String(x.tipo||"").toUpperCase(),estado:x=>String(x.Estado||x.estado||"").toUpperCase()},
      sort:{programada:x=>smartDateValue(x.programada),equipo:x=>x.equipo||"",estado:x=>x.Estado||x.estado||"",tipo:x=>x.tipo||""}
    });
    const summary=coordinatorCompactMetrics([
      {label:"Programados",value:listCount("mantenimientos","programados",0),icon:"calendar-clock",tone:"blue"},
      {label:"En proceso",value:listCount("mantenimientos","proceso",0),icon:"refresh-cw",tone:"amber"},
      {label:"Finalizados",value:listCount("mantenimientos","finalizados",0),icon:"circle-check-big",tone:"green"},
      {label:"Pendientes / vencidos",value:listCount("mantenimientos","pendientes",0),icon:"triangle-alert",tone:"red"}
    ],"maintenance-summary");
    const rows=result.items.map(x=>`<tr>
      <td><div class="se-cell-stack"><strong class="mono">#${esc(x.id)}</strong><span class="se-cell-muted">${fmt(x.programada)}</span></div></td>
      <td><div class="se-cell-stack"><strong>${esc(x.equipo||"Equipo")}</strong><span class="mono se-cell-muted">${esc(x.codigo_equipo||"—")}</span></div></td>
      <td><div class="se-cell-stack"><span class="se-cell-muted">${esc(displayEnumText(x.tipo||"—"))}</span>${managementBadge(x.Estado||x.estado)}</div></td>
      <td><div class="se-cell-stack"><span class="se-cell-caption">Diagnóstico</span><span class="se-description" title="${esc(x.Diagnostico||x.diagnostico||"—")}">${esc(x.Diagnostico||x.diagnostico||"—")}</span><span class="se-cell-caption">Resultado</span><span class="se-description" title="${esc(x.Resultado||x.resultado||"—")}">${esc(x.Resultado||x.resultado||"—")}</span></div></td>
      <td class="se-table-actions">${button("Ver detalle","detalle-mantenimiento",x.id)}</td>
    </tr>`);
    content.innerHTML=`${equipmentMaintenanceTabs("mantenimientos")}${summary}<section class="panel smart-list-panel maintenance-panel coord-data-surface"><div class="panel-header"><div><span class="coord-section-kicker">Mantenimiento</span><h2>Mantenimiento</h2><p class="muted">Programa y da seguimiento al mantenimiento preventivo y correctivo.</p></div>${state.role==="COORDINADOR"?`<button class="btn primary" type="button" data-action="nuevo-mantenimiento"><i data-lucide="calendar-plus"></i> Programar mantenimiento</button>`:""}</div><div class="panel-body">${smartControls("mantenimientos",{placeholder:"Registro, equipo, diagnóstico o trabajo requerido",filters:[{name:"tipo",label:"Tipo",options:types},{name:"estado",label:"Estado",options:states}],sorts:[["programada","Fecha programada"],["equipo","Equipo"],["tipo","Tipo"],["estado","Estado"]]})}${smartResultsMeta(result,"mantenimientos")}</div>${table(["Registro / fecha","Equipo","Tipo / estado","Diagnóstico / resultado","Acción"],rows,"No hay mantenimientos que coincidan con los filtros.")}${smartPager("mantenimientos",result)}</section>`;
    window.lucide?.createIcons();
  }


  function maintenanceForm(){return portalUI.planMaintenance();}

  async function renderVacaciones(isCurrent = () => true){
    setHeading("Horarios y vacaciones", "Consulta los turnos y las vacaciones de la semana.");
    const all=(await loadAllPaged("vacaciones","/api/vacaciones", false, isCurrent)).items;
    if (!isCurrent()) return;
    const states=listFacet(state.current,"estado",smartUnique(all,x=>String(x.Estado||x.estado||"").toUpperCase()));
    const result=smartListData("vacaciones",all,{
      defaults:{orden:"solicitada",direccion:"DESC"},
      search:x=>[x.empleado,x.Estado,x.estado,x.Motivo,x.motivo,x.Observaciones,x.observaciones],
      filters:{estado:x=>String(x.Estado||x.estado||"").toUpperCase()},
      sort:{solicitada:x=>smartDateValue(x.solicitada),inicio:x=>smartDateValue(x.inicio),empleado:x=>x.empleado||"",estado:x=>x.Estado||x.estado||""}
    });
    const rows=result.items.map(x=>`<tr>
      <td><div class="se-cell-stack"><strong>${esc(x.empleado||"Empleado")}</strong><span class="se-cell-muted">Solicitada: ${fmt(x.solicitada)}</span></div></td>
      <td>${vacationPeriod(x.inicio,x.fin,x.dias)}</td>
      <td>${badge(x.Estado||x.estado)}</td>
      <td><div class="se-description" title="${esc(x.Motivo||x.motivo||"—")}">${esc(x.Motivo||x.motivo||"—")}</div></td>
      <td class="se-table-actions">${button("Abrir","detalle-vacacion",x.id)}</td>
    </tr>`);
    content.innerHTML=`<section class="se-week-panel" data-staff-calendar aria-label="Calendario de horarios y vacaciones"><p class="se-week-empty">Cargando calendario…</p></section><section class="panel smart-list-panel"><div class="panel-header"><div><h2>${state.role==="TECNICO"?"Mis solicitudes de vacaciones":"Solicitudes de vacaciones"}</h2><p class="muted">Busca por empleado o motivo y filtra por estado.</p></div>${state.role==="TECNICO"?button("Solicitar vacaciones","nueva-vacacion"):""}</div><div class="panel-body">${smartControls("vacaciones",{placeholder:"Empleado, motivo u observaciones",filters:[{name:"estado",label:"Estado",options:states.map(value=>[value,formatDisplayLabel(value)])}],sorts:[["solicitada","Fecha de solicitud"],["inicio","Inicio"],["empleado","Empleado"],["estado","Estado"]]})}${smartResultsMeta(result,"solicitudes")}</div>${table(["Empleado / solicitud","Período","Estado","Motivo","Acción"],rows,"No hay vacaciones que coincidan con los filtros.")}${smartPager("vacaciones",result)}</section>`;
    const calendar = content.querySelector("[data-staff-calendar]");
    if (calendar) staffCalendar(calendar);
    window.lucide?.createIcons();
  }


  function catalogPriceView(value) {
    const n = normalizeNumber(value);
    return n > 0 ? money(n, "GTQ") : `<span class="catalog-price-empty">Por definir</span>`;
  }

  function catalogFilteredItems() {
    const result=smartListData("catalogo",state.masterCatalog||[],{
      defaults:{orden:"nombre",direccion:"ASC"},
      search:x=>[x.codigo,x.nombre,x.categoria,x.descripcion,x.unidad,x.origen],
      filters:{categoria:x=>String(x.categoria||""),estado:x=>x.activo?"ACTIVO":"INACTIVO"},
      sort:{nombre:x=>x.nombre||"",codigo:x=>x.codigo||"",categoria:x=>x.categoria||"",precio:x=>Number(x.precio||0),estado:x=>x.activo?1:0}
    });
    return result;
  }


  function paintCatalogRows() {
    const host = $("#catalogTableHost");
    if (!host) return;
    const result = catalogFilteredItems();
    const rows = result.items.map(x => `<tr>
      <td><div class="se-cell-stack"><strong>${esc(x.nombre)}</strong><span class="mono se-cell-muted">${esc(x.codigo)}</span>${x.descripcion ? `<small class="se-description" title="${esc(x.descripcion)}">${esc(x.descripcion)}</small>` : ""}</div></td>
      <td>${esc(x.categoria || "General")}</td>
      <td class="catalog-price-cell"><div class="se-cell-stack">${catalogPriceView(x.precio)}<span class="se-cell-muted">Por ${esc(x.unidad || "servicio")}</span></div></td>
      <td><div class="se-cell-stack">${badge(x.activo ? "ACTIVO" : "INACTIVO")}<span class="catalog-origin ${x.origen === "SISTEMA" ? "db" : "custom"}">${x.origen === "SISTEMA" ? "Servicio base" : "Personalizado"}</span></div></td>
      <td class="se-table-actions"><div class="actions">${button("Editar", "editar-catalogo", x.id)}${button(x.activo ? "Desactivar" : "Activar", "toggle-catalogo", x.id, x.activo ? "danger" : "")}</div></td>
    </tr>`);
    host.innerHTML = `${table(["Trabajo / código","Categoría","Precio / unidad","Estado / origen","Acciones"], rows, "No hay trabajos que coincidan con los filtros.")}${smartPager("catalogo",result)}`;
    const count = $("#catalogVisibleCount"); if (count) count.textContent = String(result.total);
    window.lucide?.createIcons();
  }


  async function renderCatalogoMaestro(isCurrent = () => true){
    setHeading("Catálogo maestro", "Centraliza los trabajos y precios de referencia que coordinación utiliza al preparar cotizaciones.");
    const all=(await loadAllPaged("catalogo","/api/catalogo-maestro")).items;
    if (!isCurrent()) return;
    state.masterCatalog=all;
    const categories=smartUnique(all,x=>x.categoria||"");
    const active=all.filter(x=>x.activo).length,withPrice=all.filter(x=>Number(x.precio||0)>0).length;
    const prefs=smartPrefs("catalogo",{orden:"nombre",direccion:"ASC"});
    content.innerHTML = `<section class="catalog-summary-grid"><article class="catalog-summary-card"><span><i data-lucide="book-open-check"></i></span><div><small>Trabajos registrados</small><strong>${all.length}</strong></div></article><article class="catalog-summary-card"><span><i data-lucide="circle-check-big"></i></span><div><small>Activos</small><strong>${active}</strong></div></article><article class="catalog-summary-card accent"><span><i data-lucide="badge-dollar-sign"></i></span><div><small>Con precio definido</small><strong>${withPrice}</strong></div></article></section>
      <section class="panel catalog-master-panel smart-list-panel"><div class="panel-header catalog-master-header"><div><h2>Listado maestro</h2><p class="muted"><span id="catalogVisibleCount">0</span> resultados según filtros.</p></div><button class="btn primary" type="button" data-action="nuevo-catalogo"><i data-lucide="plus"></i> Nuevo trabajo</button></div><div class="panel-body">${smartControls("catalogo",{placeholder:"Código, trabajo, descripción o unidad",filters:[{name:"categoria",label:"Categoría",options:categories},{name:"estado",label:"Estado",options:[["ACTIVO","Activos"],["INACTIVO","Inactivos"]]}],sorts:[["nombre","Trabajo"],["codigo","Código"],["categoria","Categoría"],["precio","Precio"],["estado","Estado"]]})}</div><div id="catalogTableHost"></div></section>`;
    paintCatalogRows();
    window.lucide?.createIcons();
  }


  function catalogForm(itemId=""){
    const current = (state.masterCatalog || []).find(x=>x.id===itemId);
    const isDb = current?.origen === "SISTEMA";
    const categories = [...new Set((state.masterCatalog || []).map(x=>x.categoria).filter(Boolean))].sort();
    openModal(current ? "Editar trabajo del catálogo" : "Nuevo trabajo del catálogo", `<form id="catalogForm" class="form-grid">
      <div class="field"><label>Código</label><input name="codigo" maxlength="40" value="${esc(current?.codigo||"")}" ${isDb?"readonly":""} placeholder="Ej. DRN-001"></div>
      <div class="field"><label>Estado</label><select name="activo"><option value="true" ${current?.activo!==false?"selected":""}>Activo</option><option value="false" ${current?.activo===false?"selected":""}>Inactivo</option></select></div>
      <div class="field full"><label>Trabajo / servicio</label><input name="nombre" maxlength="160" required value="${esc(current?.nombre||"")}" ${isDb?"readonly":""} placeholder="Nombre comercial del trabajo"></div>
      <div class="field"><label>Categoría</label><input name="categoria" list="catalogCategories" value="${esc(current?.categoria||"General")}" required><datalist id="catalogCategories">${categories.map(x=>`<option value="${esc(x)}"></option>`).join("")}</datalist></div>
      <div class="field"><label>Unidad</label><input name="unidad" value="${esc(current?.unidad||"servicio")}" placeholder="servicio, unidad, hora..."></div>
      <div class="field"><label>Precio base (Q)</label><input name="precio" type="number" min="0" step="0.01" value="${normalizeNumber(current?.precio)}" required></div>
      <div class="field full"><label>Descripción / alcance de referencia</label><textarea name="descripcion" placeholder="Detalle que puede reutilizarse al cotizar">${esc(current?.descripcion||"")}</textarea></div>
      ${isDb?`<div class="field full"><div class="catalog-db-note"><i data-lucide="database"></i><span>Este trabajo pertenece al catálogo base del sistema. Código y nombre se conservan sincronizados; aquí administras precio, categoría y descripción sin alterar la estructura principal.</span></div></div>`:""}
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">${current?"Guardar cambios":"Agregar trabajo"}</button></div></div>
    </form>`);
    $("#catalogForm")?.addEventListener("submit",async e=>{e.preventDefault();const form=e.currentTarget;const body=Object.fromEntries(new FormData(form).entries());body.activo=body.activo==="true";try{await api(current?`/api/catalogo-maestro/${encodeURIComponent(current.id)}`:"/api/catalogo-maestro",{method:current?"PATCH":"POST",body});showToast(current?"Catálogo actualizado.":"Trabajo agregado al catálogo.");closeModal();await renderCatalogoMaestro();}catch(err){showToast(err.message,"error");}});
  }

  const quotePrintSelection={active:false,ids:new Set()};
  async function renderPendingQuotes(root, page=1) {
    root.setAttribute("aria-busy","true");
    try {
      const data=await api(`/api/cotizaciones/ordenes-pendientes?pagina=${page}&tamano=5`,{seCache:"no-store"});
      if(!root.isConnected)return;
      modulePending.ordenes_sin_cotizar=data.total;
      renderNav();
      root.hidden=!data.total;
      if(!data.total)return;
      root.innerHTML=`<div class="se-quote-pending-head"><div><h2 class="se-pending-dot">Órdenes por cotizar · ${data.total}</h2><p>Acción pendiente: realizar la cotización para estas órdenes.</p></div></div>
        <ul class="se-quote-pending-list">${data.items.map(item=>`<li><div><strong>${esc(item.numero)}</strong><small>${esc([item.cliente,item.sede,item.tipo].filter(Boolean).join(" · "))}</small></div>${button("Realizar cotización","cotizar-orden",item.id)}</li>`).join("")}</ul>
        ${data.paginas>1?`<div class="se-quote-pending-pager"><button class="btn small" type="button" data-pending-page="${data.pagina-1}" ${data.pagina<=1?"disabled":""}>Anterior</button><span>${data.pagina} de ${data.paginas}</span><button class="btn small" type="button" data-pending-page="${data.pagina+1}" ${data.pagina>=data.paginas?"disabled":""}>Siguiente</button></div>`:""}`;
      root.querySelectorAll("[data-pending-page]").forEach(button=>button.addEventListener("click",()=>{button.disabled=true;renderPendingQuotes(root,Number(button.dataset.pendingPage));}));
    }catch(error){
      if(!root.isConnected)return;
      root.hidden=false;
      root.innerHTML=`<div class="se-quote-pending-head"><div><h2>Órdenes por cotizar</h2><p>${esc(error.message)}</p></div><button type="button" class="btn">Reintentar</button></div>`;
      root.querySelector("button").onclick=()=>renderPendingQuotes(root,page);
    }finally{
      root.removeAttribute("aria-busy");
    }
  }

  async function renderCotizaciones(isCurrent = () => true){
    setHeading("Cotizaciones", state.role === "CLIENTE" ? "Consulta las cotizaciones de tu empresa, con o sin orden de trabajo." : "Gestiona propuestas, versiones y aprobaciones de clientes.");
    const all=filterSelectedDate("cotizaciones",(await loadAllPaged("cotizaciones","/api/cotizaciones")).items);
    if (!isCurrent()) return;

    if (state.role !== "COORDINADOR") {
      const states=listFacet(state.current,"estado",smartUnique(all,x=>String(x.Estado||x.estado||"").toUpperCase()));
      const result=smartListData("cotizaciones",all,{
        defaults:{orden:"fecha",direccion:"DESC"},
        search:x=>[x.numero,x.cliente,x.orden,x.Estado,x.estado,x.version,x.Total,x.total],
        filters:{estado:x=>String(x.Estado||x.estado||"").toUpperCase()},
        sort:{fecha:x=>smartDateValue(x.emision||x.creada),numero:x=>x.numero||"",cliente:x=>x.cliente||"",total:x=>Number(x.Total||x.total||0),estado:x=>x.Estado||x.estado||""}
      });
      const rows=result.items.map(x=>{const st=String(x.Estado||x.estado||"").toUpperCase();const actions=[button("Ver expediente","ver-expediente-cotizacion",x.id,"primary"),button("Seguimiento y entrega","reporte-trabajo-cotizacion",x.id),`<a class="btn small" href="/api/cotizaciones/${esc(x.id)}/reporte-trabajo.pdf" download>Reporte de trabajo</a>`];return `<tr><td>${esc(x.numero)}</td><td>${renderAvatarIdentity(x.cliente || "Cliente",{entity:x,className:"client-table-identity"})}</td><td>${esc(x.orden||"Sin OT")}</td><td>${badge(st)}</td><td>${esc(x.version||"—")}</td><td>${money(x.Total||x.total,x.Moneda||x.moneda)}</td><td>${fmt(x.emision||x.creada)}</td><td><div class="actions">${actions.join("")}</div></td></tr>`;});
      const intro=`<section class="quote-client-intro"><div><span class="quote-client-intro-icon"><i data-lucide="folder-open"></i></span><div><small>EXPEDIENTE DEL SERVICIO</small><h2>Todo el proceso en un solo lugar</h2><p>Abre una cotización para ver sus servicios, condiciones y PDF. Cuando existe una orden, también puedes consultar sus evidencias.</p></div></div></section>`;
      content.innerHTML=`${intro}<div class="toolbar"><div class="toolbar-left"><h2>Cotizaciones</h2><p class="muted">Solo aparecen cotizaciones disponibles para tu empresa.</p></div></div><section class="panel smart-list-panel"><div class="panel-body">${smartControls("cotizaciones",{placeholder:"Número, cliente u orden",filters:[{name:"estado",label:"Estado",options:states}],sorts:[["fecha","Fecha"],["numero","Número"],["cliente","Cliente"],["total","Total"],["estado","Estado"]]})}${smartResultsMeta(result,"cotizaciones")}</div>${table(["No.","Cliente","Orden","Estado","Versión","Total","Fecha","Acción"],rows,"No hay cotizaciones que coincidan con los filtros.")}${smartPager("cotizaciones",result)}</section>`;
      window.lucide?.createIcons();
      return;
    }

    const defaults={orden:"fecha",direccion:"DESC",tamano:15,filtros:{estado:"TODOS",fecha:"TODAS",tab:"TODAS"}};
    const prefs=smartPrefs("cotizaciones",defaults);
    prefs.filtros=Object.assign({},defaults.filtros,prefs.filtros||{});
    if (!["fecha","total"].includes(prefs.orden)) prefs.orden="fecha";

    const actualStates=smartUnique(all,x=>quoteStateKey(x.Estado||x.estado)).map(value=>[value,quoteStateLabel(value)]);
    const selectedTab=String(prefs.filtros.tab||"TODAS").toUpperCase();
    const tabCounts={
      TODAS:all.length,
      PENDIENTES:all.filter(x=>quoteTabGroup(x.Estado||x.estado)==="PENDIENTES").length,
      ENVIADAS:all.filter(x=>quoteTabGroup(x.Estado||x.estado)==="ENVIADAS").length,
      APROBADAS:all.filter(x=>quoteTabGroup(x.Estado||x.estado)==="APROBADAS").length,
      RECHAZADAS:all.filter(x=>quoteTabGroup(x.Estado||x.estado)==="RECHAZADAS").length,
      BORRADORES:all.filter(x=>quoteTabGroup(x.Estado||x.estado)==="BORRADORES").length
    };
    const tabs=[
      ["TODAS","Todas"],["PENDIENTES","Pendientes"],["ENVIADAS","Enviadas"],["APROBADAS","Aprobadas"],["RECHAZADAS","Rechazadas"],
      ...(tabCounts.BORRADORES ? [["BORRADORES","Por enviar"]] : [])
    ];

    let prepared=all.filter(item=>{
      const group=quoteTabGroup(item.Estado||item.estado);
      if(selectedTab!=="TODAS" && group!==selectedTab) return false;
      if(!quoteDateFilterMatches(item,prefs.filtros.fecha)) return false;
      return true;
    });

    const result=smartListData("cotizaciones",prepared,{
      defaults,
      search:x=>[x.numero,x.nombre,x.cliente,x.sede,x.orden,x.orden_fisica,x.Estado,x.estado,x.version,x.Total,x.total],
      filters:{estado:x=>quoteStateKey(x.Estado||x.estado)},
      sort:{fecha:x=>smartDateValue(x.emision||x.creada),total:x=>Number(x.Total||x.total||0)}
    });

    const rows=result.items.map(x=>{
      const st=quoteStateKey(x.Estado||x.estado);
      const sendable=["BORRADOR","OBSERVADA","CONFIRMADA"].includes(st);
      const quoteMenuId=`quote-actions-${x.id}`;
      const menuActions=[
        `<button class="quote-menu-action quote-menu-detail" type="button" data-action="ver-expediente-cotizacion" data-id="${esc(x.id)}"><i data-lucide="eye"></i><span>Ver detalle</span></button>`,
        `<button class="quote-menu-action quote-menu-followup" type="button" data-action="reporte-trabajo-cotizacion" data-id="${esc(x.id)}"><i data-lucide="history"></i><span>Seguimiento y entrega</span></button>`
      ];
      if(sendable && !x.cliente_nuevo) menuActions.push(`<button class="quote-menu-action" type="button" data-action="enviar-cotizacion" data-id="${esc(x.id)}"><i data-lucide="send"></i><span>Enviar</span></button>`);
      if(x.orden_id) menuActions.push(`<button class="quote-menu-action" type="button" data-action="ver-orden" data-id="${esc(x.orden_id)}"><i data-lucide="external-link"></i><span>Ver OT</span></button>`);
      menuActions.push(`<a class="quote-menu-action" href="/api/cotizaciones/${esc(x.id)}/reporte-trabajo.pdf" download><i data-lucide="file-clock"></i><span>Reporte de trabajo</span></a>`);
      menuActions.push(`<a class="quote-menu-action" href="/api/cotizaciones/${esc(x.id)}/pdf" download><i data-lucide="file-down"></i><span>Cotización PDF</span></a>`);
      const actions=`<button class="quote-action-button quote-action-detail" type="button" data-action="ver-expediente-cotizacion" data-id="${esc(x.id)}"><i data-lucide="eye"></i><span>Ver detalle</span></button>
        <button class="quote-action-button quote-action-followup" type="button" data-action="reporte-trabajo-cotizacion" data-id="${esc(x.id)}"><i data-lucide="history"></i><span>Seguimiento y entrega</span></button>
        <button class="quote-action-more" type="button" popovertarget="${quoteMenuId}" aria-label="Más acciones para ${esc(x.numero||`Cotización #${x.id}`)}" aria-haspopup="true" aria-controls="${quoteMenuId}" aria-expanded="false"><i data-lucide="ellipsis"></i></button>
        <div class="quote-action-menu" id="${quoteMenuId}" popover="auto" role="group" aria-label="Acciones de ${esc(x.numero||`Cotización #${x.id}`)}">${menuActions.join("")}</div>`;
      const client=renderAvatarIdentity(x.cliente||"Cliente",{entity:x,className:"quote-client-identity",subtitle:[x.sede,x.orden||x.orden_fisica].filter(Boolean).join(' · ')||"Sin OT vinculada"});
      return `<tr>
        ${quotePrintSelection.active?`<td data-label="Seleccionar"><input class="quote-print-check" type="checkbox" value="${esc(x.id)}" aria-label="Seleccionar ${esc(x.numero)}" ${quotePrintSelection.ids.has(Number(x.id))?'checked':''}></td>`:''}
        <td data-label="Documento"><div class="quote-document"><strong>${esc(x.numero||`Cotización #${x.id}`)}</strong><div><span>${esc(x.nombre||'Cotización')} · ${quoteDateShort(x.emision||x.creada)} • Versión ${esc(x.version||"—")}</span><em>Actual</em></div></div></td>
        <td data-label="Cliente">${client}</td>
        <td data-label="Finanzas y estado"><div class="quote-finance"><strong>${money(x.Total||x.total,x.Moneda||x.moneda)}</strong>${quoteStatusBadge(st)}</div></td>
        <td data-label="Acciones"><div class="quote-row-actions">${actions}</div></td>
      </tr>`;
    }).join("");

    const tableMarkup=result.total?`<div class="quote-table-scroll"><table class="quote-table ${quotePrintSelection.active?'quote-table--selection':''}"><thead><tr>${quotePrintSelection.active?'<th>Elegir</th>':''}<th>Documento</th><th>Cliente</th><th>Finanzas y estado</th><th>Acciones</th></tr></thead><tbody>${rows}</tbody></table></div>${quotePager(result)}`:`<div class="quote-empty"><span><i data-lucide="receipt-text"></i></span><h3>No encontramos cotizaciones con estos filtros.</h3></div>`;

    const quoteSortValue=prefs.orden==="total"?(prefs.direccion==="ASC"?"TOTAL_ASC":"TOTAL_DESC"):(prefs.direccion==="ASC"?"FECHA_ASC":"FECHA_DESC");
    content.innerHTML=`<section class="quotes-workspace">
      <header class="quotes-page-header">
        <div class="quotes-page-copy"><h2>Cotizaciones</h2><p>Gestiona propuestas, versiones y aprobaciones de clientes.</p></div>
        <div class="quote-header-actions"><button class="btn" type="button" data-action="quote-print-mode"><i data-lucide="printer"></i><span>${quotePrintSelection.active?'Cancelar selección':'Imprimir varias'}</span></button>${quotePrintSelection.active?`<button class="btn primary" type="button" data-action="quote-print-selected"><i data-lucide="files"></i><span>Imprimir seleccionadas (${quotePrintSelection.ids.size})</span></button>`:''}<button class="quotes-create-button" type="button" data-action="nueva-cotizacion" aria-label="Nueva cotización"><i data-lucide="plus"></i><span>Nueva cotización</span></button></div>
      </header>

      <section class="se-quote-pending" data-quotes-pending hidden aria-label="Órdenes por cotizar"></section>
      <div class="quotes-tabs-row">
        <nav class="quotes-tabs" aria-label="Estado de cotizaciones">${tabs.map(([value,label])=>`<button type="button" class="quote-tab ${selectedTab===value?"active":""}" data-action="quote-tab" data-value="${value}"><span>${esc(label)}</span><strong>${tabCounts[value]}</strong></button>`).join("")}</nav>
        <button class="quotes-catalog-link" type="button" data-context-module="catalogo"><i data-lucide="book-open-check"></i><span>Catálogo y precios</span></button>
      </div>

      <section class="quotes-filters" aria-label="Filtros de cotizaciones">
        <label class="quotes-filter quotes-search"><span>Buscar</span><div><i data-lucide="search"></i><input type="search" data-smart-q="cotizaciones" value="${esc(prefs.q||"")}" placeholder="Buscar cotización, cliente u orden..." autocomplete="off"></div></label>
        <label class="quotes-filter"><span>Estado</span><select data-smart-filter="estado" data-smart-key="cotizaciones">${smartOptions(actualStates,prefs.filtros.estado,"Todos")}</select></label>
        <label class="quotes-filter"><span>Fecha</span><select data-smart-filter="fecha" data-smart-key="cotizaciones"><option value="TODAS" ${prefs.filtros.fecha==="TODAS"?"selected":""}>Todas las fechas</option><option value="HOY" ${prefs.filtros.fecha==="HOY"?"selected":""}>Hoy</option><option value="SEMANA" ${prefs.filtros.fecha==="SEMANA"?"selected":""}>Esta semana</option><option value="MES" ${prefs.filtros.fecha==="MES"?"selected":""}>Este mes</option></select></label>
        <button class="quotes-clear" type="button" data-action="smart-reset" data-list-key="cotizaciones"><i data-lucide="rotate-ccw"></i><span>Limpiar</span></button>
      </section>

      <section class="quotes-list-section">
        <div class="quotes-list-toolbar"><div><strong>Cotizaciones</strong><span>${result.total} resultado${result.total===1?"":"s"}</span></div><label><span>Ordenar por</span><select data-quote-sort><option value="FECHA_DESC" ${quoteSortValue==="FECHA_DESC"?"selected":""}>Más recientes</option><option value="FECHA_ASC" ${quoteSortValue==="FECHA_ASC"?"selected":""}>Más antiguas</option><option value="TOTAL_DESC" ${quoteSortValue==="TOTAL_DESC"?"selected":""}>Mayor total</option><option value="TOTAL_ASC" ${quoteSortValue==="TOTAL_ASC"?"selected":""}>Menor total</option></select></label></div>
        ${tableMarkup}
      </section>
    </section>`;
    content.querySelectorAll('.quote-action-menu').forEach(menu=>{
      const trigger=content.querySelector(`[popovertarget="${menu.id}"]`);
      if(!trigger) return;
      menu.addEventListener('toggle',()=>{
        const open=menu.matches(':popover-open');
        trigger.setAttribute('aria-expanded',String(open));
        if(!open) return;
        const rect=trigger.getBoundingClientRect();
        const width=menu.offsetWidth;
        const height=menu.offsetHeight;
        menu.style.left=`${Math.max(8,Math.min(rect.right-width,window.innerWidth-width-8))}px`;
        menu.style.top=`${rect.bottom+height+8<=window.innerHeight?rect.bottom+5:Math.max(8,rect.top-height-5)}px`;
      });
      menu.addEventListener('click',event=>{
        if(event.target.closest('button,a')) menu.hidePopover();
      });
    });
    content.querySelectorAll('.quote-print-check').forEach(input=>input.addEventListener('change',()=>{const id=Number(input.value);if(input.checked){if(quotePrintSelection.ids.size>=30){input.checked=false;return showToast('Puedes imprimir hasta 30 cotizaciones a la vez.','error');}quotePrintSelection.ids.add(id);}else quotePrintSelection.ids.delete(id);const label=content.querySelector('[data-action="quote-print-selected"] span');if(label)label.textContent=`Imprimir seleccionadas (${quotePrintSelection.ids.size})`;}));
    renderPendingQuotes(content.querySelector("[data-quotes-pending]"));
    window.lucide?.createIcons();
  }


  async function openClientQuoteFlow(id){
    if(state.role!=="CLIENTE") return navigate("cotizaciones");
    return window.SepriguaQuoteExpediente(uiContext,id);
  }

  async function quoteForm(preselectedOrderId=""){return portalUI.quoteForm(preselectedOrderId);}

  async function quoteAction(action,id){
    if(action==="enviar-cotizacion"){
      let sent=false;
      try{
        await api(`/api/cotizaciones/${id}/enviar`,{method:"POST",body:{}});sent=true;
        closeModal();await navigate("cotizaciones",{force:true});
        await portalUI.handle("detalle-cotizacion",id);
        showToast("Cotización enviada.");
      }catch(err){showToast(sent?"Cotización enviada, pero no se pudo abrir su detalle: "+err.message:err.message,"error");}
      return;
    }
    if(action==="responder-cotizacion"){
      openModal("Responder cotización",`<form id="quoteResponse" class="form-grid"><div class="field"><label>Respuesta</label><select name="respuesta"><option value="">Seleccionar respuesta...</option><option value="ACEPTADA">Aceptar sin cambios</option><option value="CAMBIOS">Solicitar revisión / cambio de precio</option><option value="RECHAZADA">Rechazar</option></select></div><div class="field full"><label>Observaciones</label><textarea name="observaciones" placeholder="Describe cambios o motivo de rechazo cuando aplique"></textarea></div><div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary">Enviar respuesta</button></div></div></form>`);
      $("#quoteResponse").addEventListener("submit",async e=>{e.preventDefault();const f=e.currentTarget,btn=f.querySelector('button[type="submit"],button.btn.primary');if(f.dataset.sending)return;const body=Object.fromEntries(new FormData(f).entries());if(!body.respuesta)return showToast("Seleccioná una respuesta.","error");if(body.respuesta==="ACEPTADA"&&String(body.observaciones||"").trim())return showToast("Si solicitás cambios elegí 'Solicitar revisión', no 'Aceptar'.","error");if(["CAMBIOS","RECHAZADA"].includes(body.respuesta)&&!String(body.observaciones||"").trim())return showToast("Describí los cambios o el motivo.","error");f.dataset.sending="1";if(btn)btn.disabled=true;try{const result=await api(`/api/cotizaciones/${id}/responder`,{method:"POST",body});showToast(result.message||"Respuesta registrada.");invalidateApiCache(["/api/documentos","/api/cotizaciones"]);invalidateListCache("documentos");closeModal();if(content.querySelector(".qe-expediente")) await openClientQuoteFlow(id); else await navigate("cotizaciones",{force:true});}catch(err){showToast(err.message,"error");}finally{delete f.dataset.sending;if(btn?.isConnected)btn.disabled=false;}});return;
    }
  }

  function documentHubHeader(tab) {
    // Un solo expediente personal: archivos privados sin OT y documentos laborales.
    // Se mantiene la vista de documentos del servicio completamente separada.
    const serviceTab = true
      ? `<button class="document-hub-tab ${tab==="servicio"?"active":""}" type="button" data-action="documentos-tab" data-tab="servicio" aria-selected="${tab==="servicio"}"><i data-lucide="file-check-2"></i><span><strong>Documentos del servicio</strong><small>OT, reportes y entregables</small></span></button>`
      : "";
    const laborTitle = "Expediente personal";
    const laborDetail = state.role==="COORDINADOR" ? "Archivos propios y recibidos · sin OT" : "Documentos compartidos · sin OT";
    const laborTab = `<button class="document-hub-tab ${tab==="laboral"?"active":""}" type="button" data-action="documentos-tab" data-tab="laboral" aria-selected="${tab==="laboral"}"><i data-lucide="folder-user"></i><span><strong>${laborTitle}</strong><small>${laborDetail}</small></span></button>`;
    const heading = state.role === "COORDINADOR" ? "Centro de documentos" : "Mis documentos";
    const note = state.role === "COORDINADOR"
      ? "Consulta los documentos del servicio y los expedientes personales en un solo lugar."
      : "Consulta tu expediente personal y los documentos asociados a servicios.";
    return `<section class="document-hub ${state.role==="CLIENTE"?"client-document-hub":""}"><div class="document-hub-copy"><div><h2>${heading}</h2><p>${note}</p></div></div><div class="document-hub-tabs" role="tablist" aria-label="Tipos de documentos">${serviceTab}${laborTab}</div></section>`;
  }

  // Expediente único. Las cuentas cargan sus propios archivos y el backend
  // garantiza: usuario propietario o cualquier cuenta COORDINADOR.
  // Los documentos laborales antiguos se consultan aquí, sin pestaña ni
  // formulario adicional. No se migra ni elimina el historial existente.
  async function genericDocumentUploadForm(){
    const coordinador=state.role==="COORDINADOR";
    openModal("Subir documento",`<form id="genericDocumentUploadForm" class="form-grid" enctype="multipart/form-data">
      <div class="field full"><div class="document-upload-note"><i data-lucide="shield-check"></i><div><strong>Tu expediente personal, sin vincular a una OT.</strong><span>${coordinador?"Este archivo podrá ser consultado por los coordinadores.":"Tú y Coordinación pueden consultarlo; Coordinación puede compartirlo temporalmente con usuarios autorizados."} Se aceptan PDF, imágenes, Word, Excel, CSV, XML o TXT (máximo 12 MB).</span></div></div></div>
      <div class="field full"><label>Archivo<input type="file" name="archivo" accept=".pdf,.jpg,.jpeg,.png,.webp,.docx,.xlsx,.csv,.xml,.txt" required></label></div>
      <div class="field full"><label>Descripción (opcional)<textarea name="descripcion" maxlength="500" placeholder="Descripción del documento"></textarea></label></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Guardar documento</button></div></div>
    </form>`);
    const form=$("#genericDocumentUploadForm");
    form?.addEventListener("submit",async e=>{
      e.preventDefault();if(form.dataset.sending)return;form.dataset.sending="1";
      const btn=form.querySelector('[type="submit"]');btn.disabled=true;
      try{
        const result=await api("/api/archivos-usuario",{method:"POST",body:new FormData(form)});
        closeModal();showToast(result.message||"Documento guardado.");await renderDocumentos();
      }catch(err){showToast(err.message,"error");}
      finally{delete form.dataset.sending;if(btn.isConnected)btn.disabled=false;}
    });
    window.lucide?.createIcons();
  }

  async function documentShareForm(id){
    const [people, access]=await Promise.all([
      api(`/api/archivos-usuario/destinatarios?archivo_id=${encodeURIComponent(id)}`),
      api(`/api/archivos-usuario/${id}/accesos`)
    ]);
    const active=(access.items||[]).filter(x=>x.vigente);
    const activeIds=new Set(active.map(x=>Number(x.usuario_id)));
    const cards=(people.items||[]).map(x=>`<label class="document-share-person" data-search="${esc(`${x.usuario} ${x.rol}`.toLowerCase())}">
      <input type="checkbox" name="usuario_ids" value="${Number(x.id)}">
      <span class="document-share-avatar">${esc(String(x.usuario||"?").slice(0,2).toUpperCase())}</span>
      <span class="document-share-person-copy"><strong>${esc(x.usuario)}</strong><small>${esc(x.rol)}</small></span>
      ${activeIds.has(Number(x.id))?`<span class="document-share-current">Ya tiene acceso</span>`:""}
    </label>`).join("");
    openModal("Compartir documento",`<form id="documentShareForm" class="document-share-form">
      <div class="document-share-intro"><span><i data-lucide="users-round"></i></span><div><strong>Elige quién puede ver este documento</strong><p>Coordinación administra los accesos por persona y tiempo limitado, incluso para archivos recibidos. Los archivos de una empresa cliente no se comparten con otras empresas.</p></div></div>
      <div class="document-share-toolbar"><label class="document-share-search"><i data-lucide="search"></i><input type="search" id="documentShareSearch" placeholder="Buscar por usuario o rol" autocomplete="off" aria-label="Buscar destinatarios"></label><label class="document-share-duration"><span>Tiempo de acceso</span><select name="horas"><option value="1">1 hora</option><option value="24" selected>24 horas</option><option value="168">7 días</option><option value="720">30 días</option></select></label></div>
      <div class="document-share-pick-head"><strong>Destinatarios</strong><span id="documentShareCount">0 seleccionados</span></div>
      <div class="document-share-people">${cards||`<p class="muted">No hay cuentas activas de cliente o técnico.</p>`}</div>
      <div class="document-share-pick-foot"><button class="btn small" type="button" id="documentShareSelectAll">Seleccionar visibles</button><button class="btn small" type="button" id="documentShareClear">Quitar selección</button></div>
      <section class="document-share-active"><h3>Accesos vigentes <span>${active.length}</span></h3>${active.length?`<div class="document-share-list">${active.map(x=>`<div class="document-share-entry"><span><strong>${esc(x.usuario)}</strong><small>Hasta ${fmt(x.expira)}</small></span><button class="btn small danger" type="button" data-revoke-access="${Number(x.id)}">Revocar</button></div>`).join("")}</div>`:`<p class="muted">Ninguna cuenta tiene acceso temporal.</p>`}</section>
      <div class="form-actions document-share-actions"><button class="btn" type="button" data-close-modal>Cerrar</button><button class="btn primary" type="submit" disabled>Autorizar acceso a 0</button></div>
    </form>`);
    const form=$("#documentShareForm");
    const search=form.querySelector("#documentShareSearch");
    const choices=[...form.querySelectorAll('.document-share-person')];
    const updateSelection=()=>{choices.forEach(card=>card.classList.toggle('selected',card.querySelector('input').checked));const count=form.querySelectorAll('input[name="usuario_ids"]:checked').length;form.querySelector('#documentShareCount').textContent=`${count} seleccionado${count===1?"":"s"}`;const submit=form.querySelector('[type="submit"]');submit.textContent=`Autorizar acceso a ${count}`;submit.disabled=!count;};
    search?.addEventListener("input",()=>{const query=search.value.trim().toLowerCase();choices.forEach(card=>{card.hidden=!card.dataset.search.includes(query);});});
    form.querySelector('#documentShareSelectAll')?.addEventListener("click",()=>{choices.filter(card=>!card.hidden).forEach(card=>{card.querySelector('input').checked=true;});updateSelection();});
    form.querySelector('#documentShareClear')?.addEventListener("click",()=>{choices.forEach(card=>{card.querySelector('input').checked=false;});updateSelection();});
    form.addEventListener("change",event=>{if(event.target.matches('input[name="usuario_ids"]'))updateSelection();});
    form?.addEventListener("submit",async e=>{
      e.preventDefault();if(form.dataset.sending)return;form.dataset.sending="1";
      const submit=form.querySelector('[type="submit"]');submit.disabled=true;
      try{const body={usuario_ids:[...form.querySelectorAll('input[name="usuario_ids"]:checked')].map(input=>Number(input.value)),horas:Number(form.elements.horas.value)};if(!body.usuario_ids.length)throw new Error("Selecciona al menos una cuenta.");const result=await api(`/api/archivos-usuario/${id}/accesos`,{method:"POST",body});showToast(result.message||"Acceso temporal autorizado.");await documentShareForm(id);}
      catch(err){showToast(err.message,"error");}
      finally{delete form.dataset.sending;if(submit.isConnected)submit.disabled=false;}
    });
    form?.querySelectorAll("[data-revoke-access]").forEach(btn=>btn.addEventListener("click",async()=>{
      try{btn.disabled=true;await api(`/api/archivos-usuario/${id}/accesos/${btn.dataset.revokeAccess}`,{method:"DELETE"});showToast("Acceso revocado.");await documentShareForm(id);}
      catch(err){btn.disabled=false;showToast(err.message,"error");}
    }));
  }

  function refreshDocumentLists(){
    invalidateApiCache(["/api/archivos-usuario","/api/documentos-laborales","/api/documentos"]);
    invalidateListCache("documentos");
    invalidateViewCache("documentos");
    return renderDocumentos();
  }

  function documentEditForm(trigger){
    const id=Number(trigger.dataset.id);
    const origin=trigger.dataset.origin;
    const name=trigger.dataset.name||"Documento";
    const description=trigger.dataset.description||"";
    if(!id)return showToast("Documento inválido.","error");
    const labor=origin==="laboral",personal=origin==="usuario",client=origin==="CLIENTE";
    const url=labor?`/api/documentos-laborales/${id}`:personal?`/api/archivos-usuario/${id}`:client?`/api/documentos-cliente/${id}`:`/api/documentos-servicio/${id}`;
    const fileField=(personal||client)?`<div class="field full"><label>Reemplazar archivo (opcional)</label><input type="file" name="archivo" accept="${personal?".pdf,.jpg,.jpeg,.png,.webp,.docx,.xlsx,.csv,.xml,.txt":"application/pdf,image/jpeg,image/png,image/webp"}"><small>Si no elegís un archivo, se conserva el actual.</small></div>`:"";
    const fields=labor?`<div class="field full"><label>Tipo de documento</label><input name="tipo_documento" maxlength="100" value="${esc(name)}" required></div>
      <div class="field"><label>Número</label><input name="numero_documento" maxlength="80" value="${esc(trigger.dataset.number||"")}"></div>
      <div class="field"><label>Fecha de emisión</label><input type="date" name="fecha_emision" value="${esc(trigger.dataset.issued||"")}"></div>
      <div class="field"><label>Fecha de vencimiento</label><input type="date" name="fecha_vencimiento" value="${esc(trigger.dataset.expires||"")}"></div>
      <div class="field full"><label>Observaciones</label><textarea name="observaciones" maxlength="500">${esc(trigger.dataset.notes||"")}</textarea></div>`:
      `<div class="field full"><label>${personal||client?"Descripción":"Observaciones"}</label><textarea name="${personal||client?"descripcion":"observaciones"}" maxlength="${personal?500:client?600:1200}">${esc(description)}</textarea></div>${fileField}`;
    openModal(`Editar ${name}`,`<form id="documentEditForm" class="form-grid" enctype="multipart/form-data">
      <div class="field full"><p class="muted">${labor?"Editá los datos del expediente; el archivo se conserva.":client||personal?"Podés cambiar la descripción y, si hace falta, reemplazar el archivo.":"El documento generado conserva su contenido y número; aquí se actualizan sus observaciones."}</p></div>
      ${fields}<div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Guardar cambios</button></div></div>
    </form>`);
    const form=$("#documentEditForm");
    form?.addEventListener("submit",async event=>{
      event.preventDefault();if(form.dataset.sending)return;form.dataset.sending="1";
      const submit=form.querySelector('[type="submit"]');submit.disabled=true;
      try{
        const body=(labor||(!personal&&!client))?Object.fromEntries(new FormData(form).entries()):new FormData(form);
        const response=await api(url,{method:"PATCH",body});
        closeModal();showToast(response.message||"Documento actualizado.");await refreshDocumentLists();
      }catch(error){showToast(error.message,"error");}
      finally{delete form.dataset.sending;if(submit.isConnected)submit.disabled=false;}
    });
  }

  async function deleteDocumentFromView(trigger){
    const id=Number(trigger.dataset.id),origin=trigger.dataset.origin;
    if(!id)return showToast("Documento inválido.","error");
    const official=origin==="SEPRIGUA";
    const question=official?"¿Eliminar este documento de la vista? Se conservará el historial de anulación.":"¿Eliminar este documento y su archivo? Esta acción no se puede deshacer.";
    if(!confirm(question))return;
    const url=origin==="usuario"?`/api/archivos-usuario/${id}/permanente`:
      origin==="laboral"?`/api/documentos-laborales/${id}`:
      origin==="CLIENTE"?`/api/documentos-cliente/${id}`:`/api/documentos-servicio/${id}`;
    try{
      trigger.disabled=true;
      const response=await api(url,{method:"DELETE"});
      showToast(response.message||"Documento eliminado.");await refreshDocumentLists();
    }catch(error){showToast(error.message,"error");if(trigger.isConnected)trigger.disabled=false;}
  }

  function documentDetailButton(x){
    const snapshot={nombre:x.nombre||x.numero||`Documento #${x.id}`,tipo:x.tipo||x.formato||x.categoria||'Documento',
      estado:x.Estado||x.estado||(x.activo?'Activo':'Archivado'),titular:x.titular||x.cliente||'—',
      fecha:x.creado||x.generado||x.entregado||'',categoria:x.categoria||'—',referencia:x.numero_documento||x.numero||'—',
      orden:x.orden||'—',observaciones:x.observaciones||x.descripcion||''};
    return `<button class="btn small" type="button" data-action="ver-detalle-documento" data-document="${encodeURIComponent(JSON.stringify(snapshot))}"><i data-lucide="eye"></i> Ver</button>`;
  }
  function openDocumentDetail(trigger){
    let x;try{x=JSON.parse(decodeURIComponent(trigger.dataset.document||''));}catch{return;}
    openModal('Detalle del documento',`${window.SepriguaDetail.section('Información del documento',[
      ['Estado',badge(x.estado)],['Titular',esc(x.titular)],['Fecha',x.fecha?fmt(x.fecha):'—'],
      ['Categoría',esc(x.categoria)],['Referencia',esc(x.referencia)],['OT relacionada',esc(x.orden)]
    ],'file-text')}${x.observaciones?window.SepriguaDetail.prose('Observaciones',esc(x.observaciones)):''}`,
    {detailHeader:{kicker:esc(x.tipo),title:x.nombre,meta:[x.titular,x.fecha?fmt(x.fecha):''].filter(Boolean).join(' · '),status:x.estado,icon:'file-text'}});
  }

  async function renderPersonalDocuments(){
    const focused=state.role==="COORDINADOR"?String(state.documentos.empleadoId||""):"";
    const personal=await api("/api/archivos-usuario");
    const all=[];
    if(!focused){
      for(const x of (personal.items||[]).filter(x=>x.activo)){
        all.push({origen:"usuario",id:x.id,nombre:x.nombre||"Documento",descripcion:x.descripcion||"",
          titular:x.usuario||"Mi cuenta",rol:x.rol||state.role,tipo:"Archivo",creado:x.creado,
          usuario_id:x.usuario_id,compartido:!!x.compartido,acceso_expira:x.acceso_expira,
          activo:true,search:[x.usuario,x.rol,x.nombre,x.descripcion].join(" ")});
      }
    }
    let legacyWarning="";
    if(state.role!=="CLIENTE"){
      const suffix=focused?`?empleado_id=${encodeURIComponent(focused)}`:"";
      try{
        const legacy=await api(`/api/documentos-laborales${suffix}`);
        for(const x of legacy.items||[]){
          all.push({origen:"laboral",id:x.id,nombre:x.tipo_documento||"Documento",descripcion:x.numero_documento||x.observaciones||"",
            titular:x.empleado||"Empleado",rol:"TECNICO",tipo:x.tipo_documento||"Documento",
            creado:x.creado,activo:!!x.activo,verificado:!!x.verificado,archivo_url:x.archivo_url||"",
            numero_documento:x.numero_documento||"",observaciones:x.observaciones||"",
            fecha_emision:String(x.fecha_emision||"").slice(0,10),fecha_vencimiento:String(x.fecha_vencimiento||"").slice(0,10),
            empleado_id:x.empleado_id,search:[x.empleado,x.codigo_empleado,x.tipo_documento,x.numero_documento,x.observaciones].join(" ")});
        }
      }catch(err){legacyWarning=`<p class="muted" role="status">Algunos documentos existentes no se pudieron consultar: ${esc(err.message||"Error de lectura")}</p>`;}
    }
    const result=smartListData("expediente-unico",all,{
      defaults:{orden:"creado",direccion:"DESC"},
      search:x=>[x.nombre,x.descripcion,x.titular,x.tipo,x.search],
      filters:{vigencia:x=>x.activo?"ACTIVO":"ARCHIVADO"},
      sort:{creado:x=>smartDateValue(x.creado),nombre:x=>x.nombre||"",titular:x=>x.titular||""}
    });
    const rows=result.items.map(x=>{
      const personalFile=x.origen==="usuario";
      const shared=personalFile&&x.compartido&&state.role!=="COORDINADOR";
      const target=personalFile?`/api/archivos-usuario/${Number(x.id)}/archivo`:x.archivo_url;
      const download=target?`<a class="btn small" href="${esc(target)}${personalFile?'':'?download=1'}" download><i data-lucide="download"></i> Descargar</a>`:"";
      const verify=!personalFile&&state.role==="COORDINADOR"&&x.activo&&!x.verificado?button("Verificar","verificar-documento-laboral",x.id):"";
      const archive=personalFile&&!shared?`<button class="btn small" type="button" data-action="archivar-archivo-usuario" data-id="${Number(x.id)}"><i data-lucide="archive"></i> Archivar</button>`:
        state.role==="COORDINADOR"?button(x.activo?"Archivar":"Reactivar","estado-documento-laboral",x.id):"";
      const canEdit=(personalFile&&!shared) || (!personalFile&&x.activo&&(state.role==="COORDINADOR"||!x.verificado));
      const edit=canEdit?`<button class="btn small" type="button" data-action="editar-documento-personal" data-id="${Number(x.id)}" data-origin="${esc(x.origen)}" data-name="${esc(x.nombre)}" data-description="${esc(x.descripcion)}" data-number="${esc(x.numero_documento||"")}" data-notes="${esc(x.observaciones||"")}" data-issued="${esc(x.fecha_emision||"")}" data-expires="${esc(x.fecha_vencimiento||"")}"><i data-lucide="pencil"></i> Editar</button>`:"";
      const remove=(!shared&&(personalFile || state.role==="COORDINADOR" || !x.verificado))?`<button class="btn small danger" type="button" data-action="eliminar-documento-personal" data-id="${Number(x.id)}" data-origin="${esc(x.origen)}" data-name="${esc(x.nombre)}"><i data-lucide="trash-2"></i> Eliminar</button>`:"";
      const share=personalFile&&x.activo&&state.role==="COORDINADOR"?`<button class="btn small" type="button" data-action="compartir-archivo-usuario" data-id="${Number(x.id)}"><i data-lucide="user-round-check"></i> Compartir</button>`:"";
      return `<tr><td><strong>${esc(x.nombre)}</strong>${shared?`<small class="table-subline">Compartido temporalmente · vence ${fmt(x.acceso_expira)}</small>`:""}${x.descripcion?`<small class="table-subline">${esc(x.descripcion)}</small>`:""}</td>${state.role==="COORDINADOR"?`<td><strong>${esc(x.titular)}</strong><small class="table-subline">${esc(x.rol)}</small></td>`:""}<td>${fmt(x.creado)}</td><td>${x.activo?`<span class="badge green">ACTIVO</span>`:`<span class="badge">ARCHIVADO</span>`}</td><td><div class="actions compact">${documentDetailButton(x)}${download}${share}${edit}${verify}${archive}${remove}</div></td></tr>`;
    });
    const columns=state.role==="COORDINADOR"?["Documento","Titular","Fecha","Estado","Acciones"]:["Documento","Fecha","Estado","Acciones"];
    const focusedNote=focused?`<div class="document-upload-note"><i data-lucide="user-round"></i><div><strong>Expediente de empleado seleccionado</strong><span>Los documentos existentes del colaborador se consultan aquí. Para volver a tu expediente y al listado general, presioná «Ver todos».</span></div></div>`:"";
    return `<section class="panel smart-list-panel personal-documents-panel"><div class="panel-header"><div><h2>Expediente personal</h2><p class="muted">Un solo expediente para tus documentos, sin necesidad de una orden de trabajo. El titular y Coordinación pueden consultarlos; los demás solo si reciben acceso temporal.</p></div><div class="actions">${focused?`<button class="btn" type="button" data-action="limpiar-expediente-personal">Ver todos</button>`:`<button class="btn primary" type="button" data-action="subir-archivo-general"><i data-lucide="file-up"></i> Subir documento</button>`}</div></div>${focusedNote}${legacyWarning}<div class="panel-body">${smartControls("expediente-unico",{placeholder:"Buscar por documento o titular",filters:[{name:"vigencia",label:"Estado",options:[["ACTIVO","Activo"],["ARCHIVADO","Archivado"]]}],sorts:[["creado","Fecha"],["nombre","Documento"],["titular","Titular"]]})}${smartResultsMeta(result,"documentos")}</div>${table(columns,rows,"Todavía no hay documentos en este expediente.")}${smartPager("expediente-unico",result)}</section>`;
  }

  async function clientDocumentUploadForm(){
    const orders=(await loadAllPaged("client-document-orders","/api/ordenes")).items
      .filter(x=>String(x.estado_codigo||x.estado||"").toUpperCase()!=="CANCELADA")
      .sort((a,b)=>smartDateValue(b.finalizada||b.programada||b.creada)-smartDateValue(a.finalizada||a.programada||a.creada));
    if(!orders.length){
      showToast("Todavía no tienes un servicio disponible para asociar el documento.","error");
      return;
    }
    const options=orders.map(x=>`<option value="${esc(x.id)}">${esc(x.numero||`OT #${x.id}`)} · ${esc(x.tipo||"Servicio")}${x.sede?` · ${esc(x.sede)}`:""}</option>`).join("");
    openModal("Subir documento",`<form id="clientDocumentUploadForm" class="form-grid client-document-upload-form">
      <div class="field full"><div class="document-upload-note"><i data-lucide="shield-check"></i><div><strong>Este archivo quedará en tu expediente de documentos.</strong><span>Selecciona el servicio relacionado. Puedes enviar PDF o imágenes JPG, PNG y WebP.</span></div></div></div>
      <div class="field full"><label>Servicio relacionado</label><select name="orden_id" required>${options}</select></div>
      <div class="field full"><label>Archivo</label><input type="file" name="archivo" accept="application/pdf,image/jpeg,image/png,image/webp" required><small>PDF o imagen. Las imágenes se optimizan automáticamente.</small></div>
      <div class="field full"><label>Descripción <small>(opcional)</small></label><textarea name="descripcion" maxlength="600" placeholder="Ej. autorización, orden de compra, constancia o documento de respaldo"></textarea></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit"><i data-lucide="cloud-upload"></i> Enviar documento</button></div></div>
    </form>`);
    const form=$("#clientDocumentUploadForm");
    form?.addEventListener("submit",async e=>{
      e.preventDefault();
      const submit=form.querySelector('button[type="submit"]');
      submit.disabled=true;
      try{
        const result=await api("/api/documentos",{method:"POST",body:new FormData(form)});
        showToast(result.message||"Documento enviado.");
        closeModal();
        invalidateListCache("documentos");
        invalidateViewCache("documentos");
        await renderDocumentos();
      }catch(err){
        showToast(err.message,"error");
        submit.disabled=false;
      }
    });
    window.lucide?.createIcons();
  }

  function documentDownloadLink(item){
    if(!item?.ruta) return "—";
    const origin=String(item.origen||"").toUpperCase();
    const suffix=origin==="CLIENTE" && !String(item.ruta).includes("?") ? "?download=1" : "";
    return `<a class="document-download-button" href="${esc(item.ruta)}${suffix}" download><i data-lucide="download"></i><span>Descargar</span></a>`;
  }

  function documentServiceActions(item){
    const clientUpload=String(item.origen||"").toUpperCase()==="CLIENTE";
    if(["COTIZACION_PDF","REPORTE_OT_PDF"].includes(String(item.tipo_registro||"").toUpperCase()))return "";
    if(state.role!=="COORDINADOR" && !(state.role==="CLIENTE" && clientUpload))return "";
    const attrs=`data-id="${Number(item.id)}" data-origin="${clientUpload?"CLIENTE":"SEPRIGUA"}" data-name="${esc(item.numero||"Documento")}" data-description="${esc(item.descripcion||"")}"`;
    return `<button class="btn small" type="button" data-action="editar-documento-servicio" ${attrs}><i data-lucide="pencil"></i> Editar</button><button class="btn small danger" type="button" data-action="eliminar-documento-servicio" ${attrs}><i data-lucide="trash-2"></i> Eliminar</button>`;
  }

  async function renderServiceDocuments() {
    // Expediente documental permanente: NO filtrar por la fecha elegida en el calendario global.
    const all=(await loadAllPaged("documentos","/api/documentos")).items;
    const states=smartUnique(all,x=>String(x.Estado||x.estado||"").toUpperCase());
    const categories=smartUnique(all,x=>String(x.categoria||"").toUpperCase());
    const origins=smartUnique(all,x=>String(x.origen||"").toUpperCase());
    const result=smartListData("documentos",all,{
      defaults:{orden:"generado",direccion:"DESC"},
      search:x=>[x.numero,x.formato,x.categoria,x.orden,x.cliente,x.Estado,x.estado,x.origen],
      filters:{estado:x=>String(x.Estado||x.estado||"").toUpperCase(),categoria:x=>String(x.categoria||"").toUpperCase(),origen:x=>String(x.origen||"").toUpperCase()},
      sort:{generado:x=>smartDateValue(x.generado||x.entregado),documento:x=>x.numero||"",cliente:x=>x.cliente||"",formato:x=>x.formato||"",estado:x=>x.Estado||x.estado||""}
    });

    if(state.role==="CLIENTE"){
      // Una tarjeta por OT. Documentos previos o sin OT permanecen accesibles.
      // No inventar entregables: solo mostrar archivos que entrega /api/documentos.
      const groups=new Map();
      for(const x of result.items){
        const key=String(x.orden||'').trim()||'SIN_OT';
        if(!groups.has(key))groups.set(key,[]);
        groups.get(key).push(x);
      }
      const cards=[...groups.entries()].map(([order,files])=>{
        const quote=files.find(x=>String(x.tipo_registro||'').toUpperCase()==='COTIZACION_PDF');
        const report=files.find(x=>String(x.tipo_registro||'').toUpperCase()==='REPORTE_OT_PDF');
        const quoteId=quote&&Number(quote.id)<0?Math.abs(Number(quote.id)):0;
        const quoteAction=quoteId?`<button class="btn small" type="button" data-action="ver-expediente-cotizacion" data-id="${quoteId}"><i data-lucide="eye"></i> Ver cotización</button>`:'';
        const filesHtml=files.map(x=>{
          const kind=String(x.tipo_registro||'').toUpperCase();
          const filename=String(x.numero||'Documento');
          const source=String(x.ruta||'');
          const validUrl=/^\/api\/[a-z0-9/_?.=&%-]+$/i.test(source);
          const href=validUrl?esc(source):'';
          const status=String(x.estado||x.Estado||'DISPONIBLE');
          const fileIcon=kind==='COTIZACION_PDF'?'file-text':kind==='REPORTE_OT_PDF'?'clipboard-check':'file';
          const action=validUrl?`<a class="btn small" href="${href}" target="_blank" rel="noopener noreferrer" aria-label="Ver ${esc(filename)}"><i data-lucide="eye"></i> Ver</a><a class="btn small" href="${href}" download aria-label="Descargar ${esc(filename)}"><i data-lucide="download"></i> Descargar</a>`:'';
          return `<div class="se-service-archive__file"><span class="se-service-archive__file-icon"><i data-lucide="${fileIcon}"></i></span><div class="se-service-archive__file-copy"><strong>${esc(x.formato||filename)}</strong><small>${esc(filename)} · ${fmt(x.generado||x.entregado)}</small></div><span class="se-service-archive__file-status">${esc(displayEnumText(status))}</span><div class="se-service-archive__file-actions">${action}${documentServiceActions(x)}</div></div>`;
        }).join('');
        const stages=[['1','Solicitud',order!=='SIN_OT'],['2','Orden de trabajo',order!=='SIN_OT'],['3','Cotización',!!quote],['4','Entregables',!!report]];
        return `<article class="se-service-archive__item"><div class="se-service-archive__head"><span class="se-service-archive__icon"><i data-lucide="folder-check"></i></span><div class="se-service-archive__copy"><small>${order==='SIN_OT'?'DOCUMENTOS INDEPENDIENTES':'ORDEN DE TRABAJO'}</small><strong>${esc(order==='SIN_OT'?'Sin OT vinculada':order)} · ${files.length} documento${files.length===1?'':'s'}</strong></div><div class="se-service-archive__head-actions">${quoteAction}</div></div><div class="se-service-archive__stages">${stages.map(([number,label,done])=>`<div class="se-service-archive__stage ${done?'is-ready':''}"><b>${done?'✓':number}</b><span>${label}</span></div>`).join('')}</div><div class="se-service-archive__files">${filesHtml}</div></article>`;
      }).join('');
      const empty=`<section class="panel"><div class="panel-body"><div class="empty-state"><i data-lucide="folder-open"></i><h3>Todavía no hay documentos disponibles</h3><p>Las cotizaciones aceptadas y los reportes finales aparecerán aquí cuando correspondan a servicios de tus sedes autorizadas. Los documentos personales se encuentran en la otra pestaña.</p></div></div></section>`;
      return `<section class="panel smart-list-panel client-documents-panel"><div class="panel-header"><div><h2>Documentos de mis servicios</h2><p class="muted">Descarga cotizaciones aceptadas, reportes y documentos vinculados a tus órdenes, sin perderlos al cambiar la fecha del calendario.</p></div></div><div class="panel-body">${smartControls("documentos",{placeholder:"Buscar por documento, OT o servicio",filters:[{name:"origen",label:"Origen",options:origins},{name:"estado",label:"Estado",options:states}],sorts:[["generado","Fecha"],["documento","Documento"],["estado","Estado"]]})}${smartResultsMeta(result,"documentos")}</div>${cards?`<div class="panel-body"><div class="se-service-archive">${cards}</div></div>`:empty}${smartPager("documentos",result)}</section>`;
    }

    const rows=result.items.map(x=>`<tr>
      <td><div class="se-cell-stack"><div class="document-name-cell"><strong>${esc(x.numero||`#${x.id}`)}</strong><small>${esc(x.descripcion||x.formato||"Documento")}</small></div><span class="document-origin-badge ${String(x.origen||"").toUpperCase()==="CLIENTE"?"client":"seprigua"}">${esc(String(x.origen||"SEPRIGUA").replaceAll("_"," "))}</span></div></td>
      <td><div class="se-cell-stack"><strong class="mono">${esc(x.orden)}</strong><span class="se-cell-muted">${esc(x.cliente)}</span></div></td>
      <td><div class="se-cell-stack">${managementBadge(x.Estado||x.estado)}<span class="se-cell-muted">${fmt(x.generado)}</span></div></td>
      <td class="se-table-actions"><div class="actions compact">${documentDetailButton(x)}${documentDownloadLink(x)}${documentServiceActions(x)}</div></td>
    </tr>`);
    return `<section class="panel smart-list-panel"><div class="panel-header"><div><h2>Documentos del servicio</h2><p class="muted">Cotizaciones aceptadas, reportes de OT finalizadas y archivos de servicio. Los PDF se generan con la información vigente, sin duplicarlos.</p></div></div><div class="panel-body">${smartControls("documentos",{placeholder:"Documento, formato, OT o cliente",filters:[{name:"origen",label:"Origen",options:origins},{name:"estado",label:"Estado",options:states},{name:"categoria",label:"Categoría",options:categories}],sorts:[["generado","Fecha"],["documento","Documento"],["cliente","Cliente"],["formato","Formato"],["estado","Estado"]]})}${smartResultsMeta(result,"documentos")}</div>${table(["Documento / origen","Orden / cliente","Estado / fecha","Acciones"],rows,"No hay documentos que coincidan con los filtros.",true)}${smartPager("documentos",result)}</section>`;
  }


  async function renderDocumentos(isCurrent = () => true){
    if(!["servicio","laboral"].includes(state.documentos.tab))state.documentos.tab="laboral";
    // Los técnicos ven documentos de las OT que tienen asignadas.
    setHeading(state.role==="COORDINADOR"?"Documentos":"Mis documentos","Documentos del servicio y expediente personal, cada uno con sus permisos.");
    const hub=documentHubHeader(state.documentos.tab);
    const body=state.documentos.tab==="servicio"?await renderServiceDocuments():await renderPersonalDocuments();
    if (!isCurrent()) return;
    content.innerHTML=hub+body;
    window.lucide?.createIcons();
  }

  function groupNotificationItems(source) {
    const grouped = new Map();
    for (const notice of source || []) {
      const key = notice.entidad && notice.entidad_id != null
        ? `${String(notice.entidad).toLowerCase()}:${notice.entidad_id}`
        : `aviso:${notice.id}`;
      if (!grouped.has(key)) grouped.set(key, {...notice, _items: []});
      grouped.get(key)._items.push(notice);
    }
    return [...grouped.values()].map(group => {
      group._items.sort((a,b) => smartDateValue(b.creada)-smartDateValue(a.creada));
      const latest = group._items[0];
      return {...latest, _items: group._items, leida: group._items.every(item => Boolean(item.leida))};
    });
  }

  function notificationGroupLabel(group) {
    const kind = String(group.entidad || "").toLowerCase();
    const labels = {ordentrabajo:"Orden de trabajo",solicitudservicio:"Solicitud de servicio",
      cotizacion:"Cotización",cancelacion:"Cancelación",vacaciones:"Vacaciones",
      equipo:"Equipo",mantenimientoequipo:"Mantenimiento de equipo",agendaoperativa:"Agenda operativa"};
    return group.entidad_id != null ? `${labels[kind] || "Asunto"} #${group.entidad_id}` : "Aviso individual";
  }

  function paintNotificationList() {
    const host = $("#notificationList");
    if (!host) return;
    const source = (state.notifications || []).filter(x=>!state.hideReadNotifications||!x.leida);
    const groups = groupNotificationItems(source);
    const result=smartListData("notificaciones",groups,{
      defaults:{orden:"fecha",direccion:"DESC"},
      search:x=>x._items.flatMap(item=>[item.titulo,item.mensaje,item.tipo,item.canal,item.entidad]),
      filters:{lectura:x=>x.leida?"LEIDAS":"NO_LEIDAS",tipo:x=>String(x.tipo||"").toUpperCase()},
      sort:{fecha:x=>smartDateValue(x.creada),titulo:x=>x.titulo||"",tipo:x=>x.tipo||"",lectura:x=>x.leida?1:0}
    });
    if (!result.items.length) {
      host.innerHTML = `<div class="notification-empty"><span><i data-lucide="bell-off"></i></span><h3>No hay notificaciones</h3><p>No hay avisos que coincidan con los filtros actuales.</p></div>${smartPager("notificaciones",result)}`;
      window.lucide?.createIcons(); return;
    }
    const noticeCard = (x, isHistory = false) => { const display = notificationDisplay(x); return `<article class="notification-card ${x.leida ? "is-read" : "is-unread"} ${isHistory ? "notification-history-item" : ""}"><div class="notification-card-icon"><i data-lucide="${notificationIcon(x.tipo)}"></i></div><div class="notification-card-copy"><div class="notification-card-title"><strong>${esc(display.title)}</strong>${x.leida ? `<span class="read-label">Leída</span>` : `<span class="unread-label">Sin leer</span>`}</div><p>${esc(display.message)}</p>${[x.referencia,x.sede_aviso,x.servicio_aviso].some(Boolean)?`<div class="se-notice-context">${[...new Set([x.referencia,x.sede_aviso,x.servicio_aviso].filter(Boolean))].map(value=>`<span>${esc(value)}</span>`).join(" · ")}</div>`:""}<div class="notification-card-meta"><span>${esc(notificationReadableText(x.tipo || "Aviso"))}</span><span>•</span><time>${fmt(x.creada)}</time>${x.canal ? `<span>•</span><span>${esc(notificationReadableText(x.canal))}</span>` : ""}</div></div><div class="notification-card-actions">${notificationTargetButton(x)}${!x.leida ? button("Marcar como leída", "leer-notificacion", x.id) : ""}</div></article>`; };
    host.innerHTML = result.items.map(group => {
      const head = group._items[0], count = group._items.length;
      const label = notificationGroupLabel(group);
      return `<section class="notification-group"><div class="notification-group-heading"><strong>${esc(label)}</strong><span>${count} ${count === 1 ? "aviso" : "avisos"}</span></div>${noticeCard(head)}${count > 1 ? `<details class="notification-group-history"><summary>Ver ${count-1} ${count === 2 ? "aviso anterior" : "avisos anteriores"}</summary>${group._items.slice(1).map(item=>noticeCard(item,true)).join("")}</details>` : ""}</section>`;
    }).join("") + smartPager("notificaciones",result);
    window.lucide?.createIcons();
  }


  async function renderNotificaciones(isCurrent = () => true){
    setHeading("Notificaciones", "Avisos de solicitudes, asignaciones, órdenes, cambios de alcance y cotizaciones.");
    let loaded=await loadAllPaged("notificaciones","/api/notificaciones?filtro=TODAS",true);
    if(await syncCancellationNotifications(loaded.items||[])) loaded=await loadAllPaged("notificaciones","/api/notificaciones?filtro=TODAS",true);
    if (!isCurrent()) return;
    state.notifications=filterSelectedDate("notificaciones",loaded.items||[]);
    const unread=state.notifications.filter(x=>!x.leida).length,total=state.notifications.length,read=total-unread;
    state.unreadNotifications=unread;
    const types=smartUnique(state.notifications,x=>String(x.tipo||"").toUpperCase());
    const grouped = groupNotificationItems(state.notifications.filter(x=>!state.hideReadNotifications||!x.leida));
    const result=smartListData("notificaciones",grouped,{defaults:{orden:"fecha",direccion:"DESC"},search:x=>x._items.flatMap(item=>[item.titulo,item.mensaje,item.tipo,item.canal,item.entidad]),filters:{lectura:x=>x.leida?"LEIDAS":"NO_LEIDAS",tipo:x=>String(x.tipo||"").toUpperCase()},sort:{fecha:x=>smartDateValue(x.creada),titulo:x=>x.titulo||"",tipo:x=>x.tipo||"",lectura:x=>x.leida?1:0}});
    content.innerHTML=`<section class="notification-summary-grid"><article class="notification-summary-card"><span class="summary-icon"><i data-lucide="bell-ring"></i></span><div><small>Total de avisos</small><strong>${total}</strong></div></article><article class="notification-summary-card accent"><span class="summary-icon"><i data-lucide="circle-alert"></i></span><div><small>Pendientes de leer</small><strong>${unread}</strong></div></article><article class="notification-summary-card"><span class="summary-icon"><i data-lucide="circle-check-big"></i></span><div><small>Revisadas</small><strong>${read}</strong></div></article></section><section class="panel notification-center smart-list-panel"><div class="panel-header notification-center-header"><div><h2>Centro de notificaciones</h2><p class="muted">Cada usuario ve únicamente los avisos asociados a su cuenta.</p></div><div class="actions"><button class="btn small" type="button" data-action="alternar-leidas"><i data-lucide="${state.hideReadNotifications?"eye":"eye-off"}"></i> ${state.hideReadNotifications?"Mostrar leídas":"Ocultar leídas"}</button><button class="btn small" type="button" data-action="refrescar-notificaciones"><i data-lucide="refresh-cw"></i> Actualizar</button><button class="btn small primary" type="button" data-action="leer-todas-notificaciones" ${unread?"":"disabled"}>Marcar todas leídas</button></div></div><div class="panel-body">${smartControls("notificaciones",{placeholder:"Título, mensaje o tipo",filters:[{name:"lectura",label:"Lectura",options:[["NO_LEIDAS","No leídas"],["LEIDAS","Leídas"]]},{name:"tipo",label:"Tipo",options:types}],sorts:[["fecha","Fecha"],["titulo","Título"],["tipo","Tipo"],["lectura","Lectura"]]})}${smartResultsMeta(result,"asuntos")}</div><div class="notification-list" id="notificationList"></div></section>`;
    paintNotificationList();refreshNotificationBadge().catch(()=>{});window.lucide?.createIcons();
  }


  function accountValue(label, value, icon="info") {
    return `<div class="account-data-item"><span class="account-data-icon"><i data-lucide="${icon}"></i></span><div><small>${esc(label)}</small><strong>${esc(value || "—")}</strong></div></div>`;
  }

  function describeAgent(agent) {
    const a=String(agent||"");
    const os=/Windows/i.test(a)?"Windows":/Android/i.test(a)?"Android":/iPhone|iPad/i.test(a)?"iPhone / iPad":/Macintosh/i.test(a)?"macOS":"Dispositivo";
    const browser=/Edg\//.test(a)?"Edge":/Chrome\//.test(a)?"Chrome":/Firefox\//.test(a)?"Firefox":/Safari\//.test(a)?"Safari":"Navegador";
    return `${os} · ${browser}`;
  }

  function rolePortalLabel(portal){
    return ({COORDINADOR:"Coordinación",TECNICO:"Técnico",CLIENTE:"Cliente"})[String(portal||"").toUpperCase()]||"Sin definir";
  }

  function roleAccessForm(role=null){
    const data=state.rolesAccess.data||{};
    const modules=data.modulos||[];
    const currentPortal=String(role?.portal||"COORDINADOR").toUpperCase();
    const selected=new Set(role?.modulos||["dashboard","cuenta"]);
    const groups=[...new Set(modules.map(m=>m.grupo))];
    const portalOptions=(data.portales||[]).map(p=>`<option value="${esc(p.codigo)}" ${String(p.codigo)===currentPortal?"selected":""}>${esc(p.nombre)}</option>`).join("");
    const checks=groups.map(group=>`<fieldset class="role-module-group"><legend>${esc(group)}</legend><div class="role-module-grid">${modules.filter(m=>m.grupo===group).map(m=>`<label class="role-module-option" data-portals="${esc((m.portales||[]).join(','))}"><input type="checkbox" name="modulos" value="${esc(m.key)}" ${selected.has(m.key)||m.obligatorio?"checked":""} ${m.obligatorio||role?.protegido?"disabled":""}><span class="role-module-check"><i data-lucide="check"></i></span><span><strong>${esc(m.nombre)}</strong><small>${m.obligatorio?"Acceso básico obligatorio":`Disponible para ${esc((m.portales||[]).map(rolePortalLabel).join(', '))}`}</small></span></label>`).join("")}</div></fieldset>`).join("");
    openModal(role?`Editar rol · ${role.nombre}`:"Crear nuevo rol",`<form id="roleAccessForm" class="form-grid role-access-form">
      <div class="role-form-intro full"><span><i data-lucide="shield-user"></i></span><div><strong>${role?"Configura el acceso del rol":"Nuevo perfil de acceso"}</strong><p>El tipo de portal define la experiencia base y los módulos determinan qué apartados podrá abrir.</p></div></div>
      <div class="field"><label>Nombre del rol</label><input name="nombre" maxlength="60" value="${esc(role?.nombre||"")}" ${role?.sistema?"readonly":""} required placeholder="Ej. Supervisor, RRHH, Ventas"></div>
      <div class="field"><label>Tipo de portal</label><select name="portal" ${role?.sistema?"disabled":""} required>${portalOptions}</select>${role?.sistema?`<input type="hidden" name="portal" value="${esc(currentPortal)}">`:""}<small>Define la lógica base que heredará el rol.</small></div>
      <div class="field full"><label>Descripción</label><textarea name="descripcion" maxlength="300" placeholder="Responsabilidad principal de este rol...">${esc(role?.descripcion||"")}</textarea></div>
      <div class="field full"><label class="switch-row"><input type="checkbox" name="activo" ${role?.activo!==false?"checked":""} ${role?.sistema?"disabled":""}><span>Rol activo</span></label>${role?.sistema?`<small>Los roles base permanecen activos; puedes ajustar sus módulos sin desactivarlos.</small>`:""}</div>
      <div class="field full role-modules-field"><div class="role-modules-heading"><div><label>Módulos permitidos</label><small>Selecciona únicamente los apartados que este rol podrá abrir.</small></div><button class="btn small" type="button" data-role-select-compatible>Seleccionar compatibles</button></div>${checks}</div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit"><i data-lucide="save"></i> ${role?"Guardar accesos":"Crear rol"}</button></div></div>
    </form>`,{locked:false});
    const form=$("#roleAccessForm");
    const portalSelect=form.querySelector('select[name="portal"]');
    const portalValue=()=>String(portalSelect?.value||form.querySelector('input[name="portal"]')?.value||currentPortal).toUpperCase();
    const sync=()=>{
      const portal=portalValue();
      form.querySelectorAll(".role-module-option").forEach(label=>{
        const allowed=String(label.dataset.portals||"").split(",").includes(portal);
        const input=label.querySelector('input[name="modulos"]');
        label.classList.toggle("disabled",!allowed);
        if(!allowed){ input.checked=false; input.disabled=true; }
        else if(!input.dataset.coreLocked && !role?.protegido){
          const mod=(data.modulos||[]).find(m=>m.key===input.value);
          input.disabled=Boolean(mod?.obligatorio);
          if(mod?.obligatorio) input.checked=true;
        }
      });
    };
    form.querySelectorAll('input[name="modulos"]').forEach(input=>{if(input.disabled)input.dataset.coreLocked="1";});
    portalSelect?.addEventListener("change",sync);
    form.querySelector("[data-role-select-compatible]")?.addEventListener("click",()=>{
      const portal=portalValue();
      form.querySelectorAll(".role-module-option").forEach(label=>{
        const input=label.querySelector('input[name="modulos"]');
        const allowed=String(label.dataset.portals||"").split(",").includes(portal);
        if(allowed)input.checked=true;
      });
    });
    sync();
    form.addEventListener("submit",async e=>{
      e.preventDefault();
      const payload={
        nombre:form.nombre.value.trim(),
        portal:portalValue(),
        descripcion:form.descripcion.value.trim(),
        activo:role?.sistema?true:Boolean(form.activo?.checked),
        modulos:[...form.querySelectorAll('input[name="modulos"]:checked')].map(x=>x.value)
      };
      const submit=form.querySelector('button[type="submit"]');submit.disabled=true;
      try{
        const r=await api(role?`/api/roles-accesos/${role.id}`:"/api/roles-accesos",{method:role?"PATCH":"POST",body:payload});
        showToast(r.message||"Rol actualizado.");closeModal();state.rolesAccess.data=null;state.userAdmin.catalogos=null;await renderRolesAccess();
      }catch(err){showToast(err.message,"error");submit.disabled=false;}
    });
    window.lucide?.createIcons();
  }

  async function renderRolesAccess(){
    if(!state.isMasterCoordinator) throw new Error("Solo el Coordinador principal puede administrar roles y módulos.");
    setHeading("Roles y accesos", "Crea perfiles y decide exactamente qué módulos puede abrir cada rol del sistema.");
    const data=await api("/api/roles-accesos");state.rolesAccess.data=data;
    const roles=data.roles||[];
    const custom=roles.filter(r=>!r.sistema).length;
    const assigned=roles.reduce((sum,r)=>sum+Number(r.usuarios||0),0);
    const rows=roles.map(r=>{
      const portal=rolePortalLabel(r.portal);
      const tone=String(r.portal||r.nombre||"").toLowerCase().includes("coord")?"coordinator":String(r.portal||r.nombre||"").toLowerCase().includes("tec")?"technician":String(r.portal||r.nombre||"").toLowerCase().includes("client")?"client":"custom";
      const modules=(r.modulos||[]).map(key=>{const m=(data.modulos||[]).find(x=>x.key===key);return m?`<span>${esc(m.nombre)}</span>`:"";}).join("")||'<span class="empty">Sin módulos asignados</span>';
      return `<article class="role-access-card role-tone-${tone} ${r.activo?"":"inactive"}">
        <div class="role-access-card-top"><div class="role-access-main"><span class="role-access-icon"><i data-lucide="${r.protegido?"shield-check":"shield-user"}"></i></span><div class="role-access-heading"><div class="role-access-title"><h3>${esc(r.nombre)}</h3>${r.sistema?'<span class="role-system-pill">ROL BASE</span>':''}${!r.activo?'<span class="role-inactive-pill">INACTIVO</span>':''}</div><p>${esc(r.descripcion||"Sin descripción")}</p></div></div><span class="role-status-dot ${r.activo?"is-active":"is-inactive"}"><i data-lucide="${r.activo?"circle-check":"circle-pause"}"></i>${r.activo?"Activo":"Inactivo"}</span></div>
        <div class="role-access-stats"><div><span class="role-stat-icon"><i data-lucide="panels-top-left"></i></span><span><small>Portal</small><strong>${esc(portal)}</strong></span></div><div><span class="role-stat-icon"><i data-lucide="users"></i></span><span><small>Usuarios</small><strong>${normalizeNumber(r.usuarios)}</strong></span></div><div><span class="role-stat-icon"><i data-lucide="blocks"></i></span><span><small>Módulos</small><strong>${normalizeNumber((r.modulos||[]).length)}</strong></span></div></div>
        <div class="role-access-modules"><div class="role-access-modules-head"><span>Módulos habilitados</span><strong>${normalizeNumber((r.modulos||[]).length)}</strong></div><div class="role-module-chips">${modules}</div></div>
        <div class="role-access-actions">${r.protegido?'<span class="protected-role-note"><i data-lucide="lock-keyhole"></i><span><strong>Acceso total protegido</strong><small>Este rol conserva acceso completo al sistema.</small></span></span>':`<button class="btn small role-edit-button" type="button" data-role-edit="${esc(r.id)}"><i data-lucide="pencil"></i><span>Editar rol y módulos</span><i data-lucide="arrow-right"></i></button>`}</div>
      </article>`;
    }).join("");
    content.innerHTML=`<section class="roles-access-hero"><div class="roles-access-hero-main"><div><h2>Permisos por rol y por módulo</h2><p>Administra quién puede entrar a cada área del portal sin alterar la operación del sistema.</p></div></div><button class="btn primary roles-create-button" type="button" id="newRoleAccess"><i data-lucide="shield-plus"></i><span>Crear rol</span></button></section>
      <section class="roles-access-summary"><article class="role-summary-card role-summary-blue"><span><i data-lucide="shield-user"></i></span><div><small>Roles registrados</small><strong>${roles.length}</strong><p>Perfiles disponibles en el portal</p></div></article><article class="role-summary-card role-summary-cyan"><span><i data-lucide="sparkles"></i></span><div><small>Personalizados</small><strong>${custom}</strong><p>Roles creados por Coordinación</p></div></article><article class="role-summary-card role-summary-green"><span><i data-lucide="users-round"></i></span><div><small>Cuentas vinculadas</small><strong>${assigned}</strong><p>Usuarios asignados a roles</p></div></article></section>
      <section class="panel roles-access-panel"><div class="panel-header roles-access-panel-head"><div><span class="section-kicker">ROLES DEL SISTEMA</span><h2>Perfiles y permisos</h2><p class="muted">Coordinador mantiene acceso total; Técnico y Cliente pueden ajustarse por módulos.</p></div><span class="roles-security-pill"><i data-lucide="lock-keyhole"></i> Acceso protegido</span></div><div class="panel-body roles-access-list">${rows||'<div class="empty-state">No hay roles registrados.</div>'}</div></section>`;
    $("#newRoleAccess")?.addEventListener("click",()=>roleAccessForm());
    content.querySelectorAll("[data-role-edit]").forEach(btn=>btn.addEventListener("click",()=>{const role=roles.find(r=>String(r.id)===String(btn.dataset.roleEdit));if(role)roleAccessForm(role);}));
    window.lucide?.createIcons();
  }

  function openOwnProfileEditor(){
    const p=state.account||{};
    const isClient=state.role==="CLIENTE";
    const fields=isClient?`
      <div class="field full"><label>Nombre completo</label><input name="nombre" maxlength="180" value="${esc(p.contacto_nombre||p.nombre||"")}" required></div>
      <div class="field"><label>Cargo <small>(opcional)</small></label><input name="cargo" maxlength="120" value="${esc(p.contacto_cargo||"")}" placeholder="Ej. Encargado de mantenimiento"></div>
      <div class="field"><label>Teléfono</label><input name="telefono" maxlength="20" value="${esc(p.contacto_telefono||"")}" inputmode="tel"></div>
      <div class="field full"><label>Correo de contacto</label><input type="email" name="correo" maxlength="160" value="${esc(p.contacto_correo||"")}" autocomplete="email"></div>`:`
      <div class="field"><label>Nombres</label><input name="nombres" maxlength="100" value="${esc(p.nombres||"")}" required></div>
      <div class="field"><label>Apellidos</label><input name="apellidos" maxlength="100" value="${esc(p.apellidos||"")}" required></div>
      <div class="field"><label>Teléfono principal</label><input name="telefono" maxlength="20" value="${esc(p.telefono||"")}" inputmode="tel" required></div>
      <div class="field"><label>Teléfono alterno <small>(opcional)</small></label><input name="telefono_alterno" maxlength="20" value="${esc(p.telefono_alterno||"")}" inputmode="tel"></div>
      <div class="field full"><label>Correo personal / laboral</label><input type="email" name="correo" maxlength="160" value="${esc(p.correo_personal||"")}" autocomplete="email"></div>
      <div class="field full"><label>Dirección de residencia</label><input name="direccion" maxlength="350" value="${esc(p.direccion||"")}" required></div>
      <div class="field"><label>Contacto de emergencia <small>(opcional)</small></label><input name="contacto_emergencia" maxlength="160" value="${esc(p.contacto_emergencia||"")}"></div>
      <div class="field"><label>Teléfono de emergencia <small>(opcional)</small></label><input name="contacto_emergencia_telefono" maxlength="20" value="${esc(p.contacto_emergencia_telefono||"")}" inputmode="tel"></div>`;
    openModal("Editar mi información",`<form id="ownProfileForm" class="form-grid own-profile-form">
      <div class="field full"><div class="profile-edit-note"><i data-lucide="user-round-check"></i><div><strong>Esta información sí la puedes actualizar tú.</strong><span>Tu usuario, rol, permisos y estado de acceso siguen protegidos y se administran desde Coordinación.</span></div></div></div>
      ${fields}
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit"><i data-lucide="save"></i> Guardar cambios</button></div></div>
    </form>`);
    const form=$("#ownProfileForm");
    form?.addEventListener("submit",async e=>{
      e.preventDefault();
      const submit=form.querySelector('button[type="submit"]');
      submit.disabled=true;
      try{
        const result=await api("/api/cuenta",{method:"PATCH",body:Object.fromEntries(new FormData(form).entries())});
        state.account=result.item||state.account;
        const me=await api("/api/auth/me",{seCache:"reload"});
        if(me?.user){state.user=me.user;state.role=me.user.rol||state.role;state.roleName=me.user.rol_nombre||state.roleName;}
        syncPrototypeChrome();
        closeModal();
        invalidateViewCache("cuenta");
        showToast(result.message||"Información actualizada.");
        await renderCuenta();
      }catch(err){
        showToast(err.message,"error");
        submit.disabled=false;
      }
    });
    window.lucide?.createIcons();
  }

  function openAccessEmailEditor(){
    const current=state.account?.correo_acceso||"";
    openModal("Editar correo de acceso",`<form id="accessEmailForm" class="form-grid own-profile-form">
      <div class="field full"><label for="accessEmailInput">Correo de acceso al portal</label><input id="accessEmailInput" type="email" name="correo_acceso" maxlength="160" value="${esc(current)}" autocomplete="email" required><small>Podrás ingresar al portal con este correo. Tu nombre de usuario no cambiará.</small></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit"><i data-lucide="save"></i> Guardar correo</button></div></div>
    </form>`);
    const form=$("#accessEmailForm");
    form?.addEventListener("submit",async e=>{
      e.preventDefault();
      const submit=form.querySelector('button[type="submit"]');
      submit.disabled=true;
      try{
        const correo_acceso=form.elements.correo_acceso.value.trim();
        const result=await api("/api/cuenta/correo-acceso",{method:"PATCH",body:{correo_acceso}});
        state.account=result.item||state.account;
        closeModal();
        invalidateViewCache("cuenta");
        showToast(result.message||"Correo de acceso actualizado.");
        await renderCuenta();
      }catch(err){
        showToast(err.message,"error");
        submit.disabled=false;
      }
    });
    window.lucide?.createIcons();
    form?.elements.correo_acceso?.focus();
  }

  async function renderCuenta(){
    setHeading("Mi cuenta", "Actualiza tu información personal, protege tu contraseña y administra tus sesiones.");
    const endpointHash = await currentPushEndpointHash().catch(() => "");
    const [profileData, sessionsData, pushConfig, pushDevices, recoveryData]=await Promise.all([
      api("/api/cuenta"),
      api("/api/cuenta/sesiones").catch(()=>({items:[]})),
      getPushConfig().catch(()=>({enabled:false})),
      api(`/api/push/dispositivos${endpointHash ? `?endpoint_hash=${endpointHash}` : ""}`).catch(()=>({items:[]})),
      api("/api/cuenta/recuperacion").catch(()=>({configured:false}))
    ]);
    const p=profileData.item||{}; state.account=p;
    const isClient=state.role==="CLIENTE";
    const roleDetails=isClient
      ? `${accountValue("Empresa",p.cliente,"building-2")}${accountValue("Código de cliente",p.cliente_codigo,"badge-check")}${accountValue("Cargo",p.contacto_cargo,"briefcase-business")}${accountValue("Teléfono de contacto",p.contacto_telefono,"phone")}${accountValue("Correo de contacto",p.contacto_correo,"mail")}${accountValue("NIT de empresa",p.cliente_nit,"hash")}${accountValue("Teléfono de empresa",p.cliente_telefono,"phone-call")}${accountValue("Correo de empresa",p.cliente_correo,"mail-check")}`
      : `${accountValue("Código de empleado",p.empleado_codigo,"badge-check")}${accountValue("Puesto",p.puesto,"briefcase-business")}${accountValue("Disponibilidad",p.disponibilidad,"activity")}${accountValue("Teléfono",p.telefono,"phone")}${accountValue("Teléfono alterno",p.telefono_alterno,"phone-call")}${accountValue("Correo",p.correo_personal,"mail")}`;
    const sessions=(sessionsData.items||[]).map(x=>`<article class="session-card ${x.actual?"current":""}"><span class="session-device"><i data-lucide="monitor-smartphone"></i></span><div class="session-copy"><div><strong>${esc(describeAgent(x.agente))}</strong>${x.actual?`<span class="session-current">Sesión actual</span>`:""}</div><p>${esc(x.ip||"IP no disponible")} · inició ${fmt(x.iniciada)}</p><small>Expira ${fmt(x.expira)}</small></div></article>`).join("")||`<div class="empty-state">No hay sesiones activas para mostrar.</div>`;
    content.innerHTML=`
      <div class="account-grid">
        <section class="panel account-panel photo-profile-panel"><div class="panel-header"><div><h2>Fotografía de perfil</h2><p class="muted">La imagen se guarda en la base de datos y se comparte en tus avatares.</p></div></div><div class="panel-body profile-photo-controls"><div class="profile-photo-preview-frame"><img class="account-profile-photo profile-photo-preview" src="${esc(p.foto_url||"")}" alt="Vista previa de tu fotografía" ${p.foto_url?"":"hidden"}><div class="profile-photo-placeholder" ${p.foto_url?"hidden":""}><i data-lucide="camera"></i><strong>Mi perfil</strong></div></div><div class="profile-photo-form"><label for="profilePhotoInput">Selecciona una imagen JPG, PNG o WEBP</label><input id="profilePhotoInput" type="file" accept="image/jpeg,image/png,image/webp" ${p.foto_cambio_bloqueado?"disabled":""}><small class="profile-photo-help">Recorta y ajusta tu imagen antes de guardarla. Primera carga libre; después, un cambio cada 30 días. Máximo 5 MB.</small>${p.foto_cambio_bloqueado?`<small class="profile-photo-cooldown">Podrás cambiarla nuevamente el ${esc(new Date(p.foto_cambio_disponible_en).toLocaleDateString("es-GT"))}.</small>`:""}<button class="btn primary small" type="button" data-action="subir-foto-perfil" ${p.foto_cambio_bloqueado?"disabled":""}>Guardar fotografía</button></div></div></section>
        <section class="panel account-panel"><div class="panel-header account-profile-header"><div><h2>Información del perfil</h2><p class="muted">Tus datos personales y de contacto.</p></div><button class="btn small account-edit-button" type="button" data-action="editar-mi-perfil"><i data-lucide="pencil"></i><span>Editar mi información</span></button></div><div class="panel-body"><div class="account-data-grid">${accountValue("Nombre",p.nombre,"user-round")}${accountValue("Usuario",p.usuario,"at-sign")}${accountValue("Rol",state.role.replaceAll("_"," "),"shield-check")}${accountValue("Último acceso",fmt(p.ultimo_acceso),"clock-3")}${roleDetails}</div></div></section>
        <section class="panel account-panel"><div class="panel-header account-profile-header"><div><h2>Acceso al portal</h2><p class="muted">Tu correo de acceso se puede actualizar aquí.</p></div><button class="btn small account-edit-button" type="button" data-action="editar-correo-acceso"><i data-lucide="pencil"></i><span>Editar correo</span></button></div><div class="panel-body"><div class="account-data-grid">${accountValue("Correo de acceso",p.correo_acceso,"mail")}${accountValue("Usuario",p.usuario,"at-sign")}</div><div class="private-account-note"><i data-lucide="shield-check"></i><span>Solo el correo de acceso es editable en esta sección. El nombre de usuario, rol, permisos y estado de la cuenta continúan bajo administración de Coordinación.</span></div></div></section>
        <section class="panel account-panel password-panel"><div class="panel-header"><div><h2>Seguridad y contraseña</h2><p class="muted">Para cambiarla debes confirmar primero tu contraseña actual.</p></div></div><div class="panel-body"><form id="passwordForm" class="account-form"><div class="field"><label>Contraseña actual</label><div class="password-control"><input type="password" name="actual" autocomplete="current-password" required><button type="button" class="password-toggle" data-toggle-password aria-label="Mostrar contraseña"><i data-lucide="eye"></i></button></div></div><div class="field"><label>Nueva contraseña</label><div class="password-control"><input type="password" name="nueva" autocomplete="new-password" minlength="8" required><button type="button" class="password-toggle" data-toggle-password aria-label="Mostrar contraseña"><i data-lucide="eye"></i></button></div><small>Mínimo 8 caracteres, con mayúscula, minúscula y número.</small></div><div class="field"><label>Confirmar nueva contraseña</label><div class="password-control"><input type="password" name="confirmacion" autocomplete="new-password" minlength="8" required><button type="button" class="password-toggle" data-toggle-password aria-label="Mostrar contraseña"><i data-lucide="eye"></i></button></div></div><div class="form-actions"><button class="btn primary" type="submit">Cambiar contraseña</button></div></form></div></section>
        <section class="panel account-panel"><div class="panel-header"><div><h2>Recuperación personal</h2><p class="muted">${recoveryData.configured?"Tu código de seguridad está configurado.":"Configura un código para restablecer tu contraseña sin ayuda del Coordinador."}</p></div></div><div class="panel-body"><form id="recoverySetupForm" class="account-form"><div class="field"><label>Confirma tu contraseña actual</label><div class="password-control"><input type="password" name="password" autocomplete="current-password" required></div></div><div class="form-actions"><button class="btn primary" type="submit">${recoveryData.configured?"Reemplazar código":"Generar código de seguridad"}</button></div></form><div id="recoveryCodeResult" hidden role="status" aria-live="polite" class="private-account-note" style="margin-top:16px;overflow-wrap:anywhere;flex-direction:column;align-items:flex-start"><strong>Guarda este código en un lugar privado. Solo se muestra ahora y se usa una vez.</strong><p id="recoveryCodeValue" style="font-family:monospace;font-size:1.2rem;letter-spacing:.08em;margin:4px 0"></p><button type="button" class="btn small" id="copyRecoveryCode">Copiar código</button></div></div></section>
        ${pushStatusMarkup(pushDevices.items||[], pushConfig||{})}
        <section class="panel account-panel cursor-preference-panel"><div class="panel-header"><div><h2>Preferencias</h2><p class="muted">Ajustes visuales en este navegador.</p></div></div><div class="panel-body"><label class="se-cursor-preference" for="personalCursorToggle"><span><strong>Cursor personalizado</strong><small>Cursores SEPRIGUA al usar mouse. En pantallas táctiles se conserva el control normal.</small></span><input id="personalCursorToggle" type="checkbox" role="switch" ${window.SEPRIGUACursors?.isEnabled()!==false?"checked":""}></label></div></section>
        <section class="panel account-panel sessions-panel"><div class="panel-header"><div><h2>Sesiones activas</h2><p class="muted">Revisa desde dónde está abierta tu cuenta.</p></div><button class="btn small danger" type="button" data-action="cerrar-otras-sesiones" ${(sessionsData.items||[]).filter(x=>!x.actual).length?"":"disabled"}>Cerrar otras sesiones</button></div><div class="panel-body"><div class="session-list">${sessions}</div></div></section>
      </div>`;
    window.lucide?.createIcons();
    $("#personalCursorToggle")?.addEventListener("change", event => window.SEPRIGUACursors?.setEnabled(event.currentTarget.checked));

    const photoInput = $("#profilePhotoInput");
    let pendingPhotoFile = null;
    photoInput?.addEventListener("change", async () => {
      const file = photoInput.files?.[0];
      const preview = $(".profile-photo-preview");
      if (!file || !preview) return;
      try {
        const cropped = window.SEPRIGUAProfileCrop ? await window.SEPRIGUAProfileCrop.open(file) : file;
        if (!cropped) { photoInput.value = ""; return; }
        pendingPhotoFile = cropped;
        if (preview.dataset.objectUrl) URL.revokeObjectURL(preview.dataset.objectUrl);
        const objectUrl = URL.createObjectURL(cropped);
        preview.dataset.objectUrl = objectUrl;
        preview.src = objectUrl;
        preview.hidden = false;
        const placeholder = $(".profile-photo-placeholder");
        if (placeholder) placeholder.hidden = true;
      } catch (err) { photoInput.value = ""; showToast(err.message || "No se pudo ajustar la fotografía.", "error"); }
    });
    $("[data-action=\"subir-foto-perfil\"]")?.addEventListener("click", async event => {
      const button = event.currentTarget;
      const file = pendingPhotoFile;
      if (!file) return showToast("Selecciona una fotografía primero.", "error");
      const form = new FormData(); form.append("foto", file, file.name || "perfil.webp");
      button.disabled = true;
      try {
        await api("/api/cuenta/foto", {method:"POST", body:form});
        const me = await api("/api/auth/me", {seCache:"reload"});
        if (me?.user) state.user = me.user;
        syncPrototypeChrome();
        invalidateViewCache("cuenta");
        showToast("Fotografía guardada. Podrás cambiarla nuevamente en 30 días.");
        const preview = $(".profile-photo-preview");
        if (preview?.dataset.objectUrl) URL.revokeObjectURL(preview.dataset.objectUrl);
        await renderCuenta();
      } catch (err) { showToast(err.message, "error"); button.disabled = false; }
    });

    $("#passwordForm")?.addEventListener("submit",async e=>{e.preventDefault();const form=e.currentTarget;const data=Object.fromEntries(new FormData(form).entries());if(data.nueva!==data.confirmacion)return showToast("La confirmación de la nueva contraseña no coincide.","error");const submit=form.querySelector('button[type="submit"]');submit.disabled=true;try{await api("/api/cuenta/contrasena",{method:"POST",body:data});form.reset();showToast("Contraseña actualizada correctamente.");refreshNotificationBadge().catch(()=>{});}catch(err){showToast(err.message,"error");}finally{submit.disabled=false;}});
    $("#recoverySetupForm")?.addEventListener("submit",async e=>{e.preventDefault();const form=e.currentTarget;const submit=form.querySelector('button[type="submit"]');submit.disabled=true;try{const result=await api("/api/cuenta/recuperacion",{method:"POST",body:{password:form.elements.password.value}});form.reset();const box=$("#recoveryCodeResult");$("#recoveryCodeValue").textContent=result.code;box.hidden=false;showToast("Código generado. Guárdalo ahora; no volverá a mostrarse.");}catch(err){showToast(err.message,"error");}finally{submit.disabled=false;}});
    $("#copyRecoveryCode")?.addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("#recoveryCodeValue").textContent);showToast("Código copiado. Guárdalo en un lugar privado.");}catch(_err){showToast("Selecciona el código y cópialo manualmente.","error");}});
  }


  // Auditoría utiliza paginación REAL: el navegador nunca descarga todas las páginas.
  // Los contadores se refieren explícitamente a los diez registros visibles.
  async function renderAuditoria(isCurrent = () => true){
    setHeading("Auditoría", "Registro de altas, cambios y bajas realizados dentro del sistema.");
    const prefs=smartPrefs("auditoria",{orden:"fecha",direccion:"DESC",tamano:10});
    prefs.tamano=10;
    const params={
      ligera:1,pagina:prefs.pagina,tamano:10,q:prefs.q,
      orden:prefs.orden||"fecha",direccion:prefs.direccion,
      filtros:JSON.stringify(prefs.filtros||{}),
      fecha_desde:historicalDate()||undefined,fecha_hasta:historicalDate()||undefined
    };
    const data=await api(smartWithParams("/api/auditoria",params),{seCache:"reload"});
    if (!isCurrent()) return;
    const all=Array.isArray(data.items)?data.items:[];
    const page=Math.max(1,Number(data.pagina||1));
    const hasMore=Boolean(data.hay_mas);
    const opOf=x=>String(x.Operacion||x.operacion||"").toUpperCase();
    const summary=coordinatorCompactMetrics([
      {label:"Eventos mostrados",value:all.length,icon:"list-checks",tone:"blue"},
      {label:"De hoy (página)",value:all.filter(x=>gtDateKey(x.fecha)===gtDateKey(new Date())).length,icon:"calendar-days",tone:"green"},
      {label:"Cambios (página)",value:all.filter(x=>/UPDATE|CAMBIO|MODIFIC/.test(opOf(x))).length,icon:"pencil-line",tone:"amber"},
      {label:"Bajas (página)",value:all.filter(x=>/DELETE|BAJA|ELIMIN/.test(opOf(x))).length,icon:"shield-alert",tone:"red"}
    ],"audit-summary");
    const rows=all.map(x=>`<tr><td class="mono">#${esc(x.id)}</td><td>${fmt(x.fecha)}</td><td>${esc(x.Esquema||x.esquema)}.${esc(x.Tabla||x.tabla)}</td><td>${badge(x.Operacion||x.operacion)}</td><td>${esc(x.usuario||"Usuario")}</td><td class="mono">${esc(x.ip||"—")}</td><td>${esc(x.Observacion||x.observacion||"—")}</td></tr>`);
    const filters=`<div class="smart-filter-shell"><div class="smart-list-tools">
      <div class="field smart-list-search"><label>Buscar</label><div class="input-with-icon"><i data-lucide="search"></i><input type="search" data-smart-q="auditoria" value="${esc(prefs.q||"")}" placeholder="Usuario, tabla, IP u observación" autocomplete="off"></div></div>
      <div class="field"><label>Operación</label><input type="search" data-audit-filter="operacion" value="${esc(prefs.filtros?.operacion||"")}" placeholder="Ej. UPDATE" autocomplete="off"></div>
      <div class="field"><label>Tabla</label><input type="search" data-audit-filter="tabla" value="${esc(prefs.filtros?.tabla||"")}" placeholder="Ej. seg.Usuario" autocomplete="off"></div>
      <div class="field"><label>Ordenar por</label><select data-smart-sort data-smart-key="auditoria">${[["fecha","Fecha"],["tabla","Tabla"],["operacion","Operación"],["usuario","Usuario"]].map(([value,label])=>`<option value="${value}" ${String(prefs.orden||"fecha")===value?"selected":""}>${label}</option>`).join("")}</select></div>
      <div class="field"><label>Dirección</label><select data-smart-direction data-smart-key="auditoria"><option value="DESC" ${prefs.direccion==="DESC"?"selected":""}>Descendente</option><option value="ASC" ${prefs.direccion==="ASC"?"selected":""}>Ascendente</option></select></div>
      <div class="field smart-list-size"><label>Por página</label><select disabled><option>10 registros</option></select></div>
      <div class="smart-list-clear"><button class="btn" type="button" data-action="smart-reset" data-list-key="auditoria"><i data-lucide="rotate-ccw"></i> Limpiar</button></div>
    </div></div>`;
    const start=(page-1)*10+1;
    const end=start+all.length-1;
    const pager=`<div class="smart-pagination"><div class="smart-pagination-copy">${all.length?`Mostrando <strong>${start}-${end}</strong>`:"No hay eventos con estos filtros"} · Página <strong>${page}</strong> · 10 por página</div><div class="pager-buttons">
      <button type="button" class="pager-button" data-action="smart-page" data-list-key="auditoria" data-page="${page-1}" ${page<=1?"disabled":""} aria-label="Anterior"><i data-lucide="chevron-left"></i> Anterior</button>
      <button type="button" class="pager-button" data-action="smart-page" data-list-key="auditoria" data-page="${page+1}" ${!hasMore?"disabled":""} aria-label="Siguiente">Siguiente <i data-lucide="chevron-right"></i></button>
    </div></div>`;
    content.innerHTML=`${summary}<section class="panel smart-list-panel audit-panel coord-data-surface"><div class="panel-header"><div><span class="coord-section-kicker">TRAZABILIDAD</span><h2>Eventos del sistema</h2><p class="muted">La búsqueda y los filtros se aplican al historial en SQL Server; solo se descargan 10 registros por página.</p></div><button class="btn primary" type="button" data-action="probar-auditoria"><i data-lucide="shield-check"></i> Probar auditoría</button></div><div class="panel-body">${filters}</div>${table(["Registro","Fecha","Tabla","Operación","Usuario","IP","Observación"],rows,"No hay eventos que coincidan con los filtros.")}${pager}</section>`;
    window.lucide?.createIcons();
  }


  function warrantyCountdownMarkup(seconds) {
    const total=Math.max(0,Number(seconds||0));
    const days=Math.floor(total/86400);
    const hours=Math.floor((total%86400)/3600);
    const minutes=Math.floor((total%3600)/60);
    const secs=Math.floor(total%60);
    const z=n=>String(n).padStart(2,"0");
    return `<span><strong>${days}</strong><small>días</small></span><span><strong>${z(hours)}</strong><small>horas</small></span><span><strong>${z(minutes)}</strong><small>min</small></span><span><strong>${z(secs)}</strong><small>seg</small></span>`;
  }

  function startWarrantyCountdowns(){
    if(state.warrantyTimer)clearInterval(state.warrantyTimer);
    const tick=()=>{
      $$('[data-warranty-seconds]').forEach(el=>{
        let seconds=Math.max(0,Number(el.dataset.warrantySeconds||0));
        el.innerHTML=warrantyCountdownMarkup(seconds);
        if(seconds>0)el.dataset.warrantySeconds=String(seconds-1);
        else{
          const card=el.closest('.warranty-card');
          card?.classList.add('expired');
          const status=card?.querySelector('.warranty-state');
          if(status&&status.dataset.dynamic==='1')status.textContent='VENCIDA';
        }
      });
    };
    tick();
    state.warrantyTimer=setInterval(tick,1000);
  }

  function warrantyStateBadge(x){
    const status=String(x.estado_garantia||'PENDIENTE_CONFIGURACION').toUpperCase();
    const cls=status==='ACTIVA'?'active':status==='VENCIDA'?'expired':status==='ANULADA'?'cancelled':'pending';
    return `<span class="warranty-state ${cls}" data-dynamic="${status==='ACTIVA'?'1':'0'}">${esc(status.replaceAll('_',' '))}</span>`;
  }

  function warrantyCard(x){
    const status=String(x.estado_garantia||'PENDIENTE_CONFIGURACION').toUpperCase();
    const active=status==='ACTIVA';
    const expired=status==='VENCIDA';
    const pending=status==='PENDIENTE_CONFIGURACION';
    const req=String(x.estado_solicitud||'').toUpperCase();
    const reqBadge=req?`<span class="warranty-request-pill ${x.sin_cobro?"no-charge":""}">${x.sin_cobro?"SIN COBRO · ":"Revisión: "}${esc(req.replaceAll('_',' '))}</span>`:'';
    const coord=state.role==='COORDINADOR';
    const countdown=active
      ? `<div class="warranty-countdown-label">Tiempo restante de garantía</div><div class="warranty-countdown" data-warranty-seconds="${esc(x.segundos_restantes||0)}">${warrantyCountdownMarkup(x.segundos_restantes)}</div>`
      : expired
        ? `<div class="warranty-ended"><i data-lucide="clock-alert"></i><div><strong>Garantía finalizada</strong><span>Venció el ${esc(fmt(x.fin_garantia))}.</span></div></div>`
        : pending
          ? `<div class="warranty-ended pending"><i data-lucide="hourglass"></i><div><strong>Plazo pendiente de configurar</strong><span>La OT ya terminó; Coordinación todavía debe definir el período de garantía.</span></div></div>`
          : `<div class="warranty-ended"><i data-lucide="shield-x"></i><div><strong>Garantía anulada</strong><span>Consulta con Coordinación para más información.</span></div></div>`;
    const progress=active?Math.max(0,Math.min(100,Number(x.porcentaje_restante||0))):0;
    const actions=[`<button class="btn small" data-action="ver-orden" data-id="${esc(x.orden_id)}"><i data-lucide="clipboard-list"></i> Ver OT</button>`];
    if(coord)actions.push(`<button class="btn small primary" data-action="configurar-garantia" data-id="${esc(x.orden_id)}"><i data-lucide="calendar-clock"></i> ${x.garantia_id?'Editar plazo':'Configurar garantía'}</button>`);
    const activeReviewStates=['PENDIENTE','EN_REVISION','PENDIENTE_AUTORIZACION','AUTORIZADA_CLIENTE','GARANTIA_APROBADA'];
    if(!coord&&!x.solo_lectura&&active&&!activeReviewStates.includes(req))actions.push(`<button class="btn small primary" data-action="solicitar-revision-garantia" data-id="${esc(x.garantia_id)}"><i data-lucide="shield-question"></i> Solicitar revisión</button>`);
    if(!coord&&!x.solo_lectura&&req==='PENDIENTE_AUTORIZACION'&&x.solicitud_garantia_id)actions.push(`<button class="btn small primary" data-action="decision-garantia-cliente" data-id="${esc(x.solicitud_garantia_id)}"><i data-lucide="circle-dollar-sign"></i> Autorizar o rechazar cobro</button>`);
    if(x.revision_orden_id)actions.push(`<button class="btn small" data-action="ver-orden" data-id="${esc(x.revision_orden_id)}"><i data-lucide="search-check"></i> Ver OT de revisión</button>`);
    if(x.orden_cobro_id)actions.push(`<button class="btn small" data-action="ver-orden" data-id="${esc(x.orden_cobro_id)}"><i data-lucide="clipboard-plus"></i> Ver nueva OT</button>`);
    return `<article class="warranty-card se-detail-warranty ${expired?'expired':''} ${pending?'pending':''}">
      ${window.SepriguaDetail.hero(esc(x.numero_orden||`OT #${x.orden_id}`),esc(x.tipo_servicio||'Servicio'),[x.cliente,x.sede].filter(Boolean).map(esc).join(' · '),warrantyStateBadge(x),'shield-check')}
      ${window.SepriguaDetail.section('Información de la garantía',[
        ['Cliente',esc(x.cliente||'—')],['Sede',esc(x.sede||'—')],['Estado',warrantyStateBadge(x)],
        ['Finalizada',fmt(x.finalizada_en)],['Inicio garantía',x.inicio_garantia?fmt(x.inicio_garantia):'—'],
        ['Vencimiento',x.fin_garantia?fmt(x.fin_garantia):'—'],['Plazo',x.dias_garantia?`${esc(x.dias_garantia)} días`:'—']
      ],'shield-check')}
      ${countdown}
      ${active?`<div class="warranty-progress"><span style="width:${progress}%"></span></div>`:''}
      ${reqBadge}
      <div class="warranty-actions">${actions.join('')}</div>
    </article>`;
  }

  async function warrantyConfigForm(orderId){
    if(state.role!=="COORDINADOR" || !moduleAllowed("garantia")) return;
    const data=await api("/api/garantias",{seCache:"reload"});
    const x=(data.items||[]).find(item=>Number(item.orden_id)===Number(orderId));
    if(!x)return showToast('No se encontró la OT finalizada.','error');
    openModal(`${x.garantia_id?'Editar':'Configurar'} garantía · ${x.numero_orden}`,`<form id="warrantyConfigForm" class="form-grid">
      <div class="field full"><div class="warranty-rule-note"><i data-lucide="timer-reset"></i><div><strong>La garantía siempre cuenta desde la finalización original de la OT.</strong><span>Cambiar el plazo no reinicia el contador desde hoy.</span></div></div></div>
      <div class="field"><label>Días de garantía</label><input type="number" name="dias" min="1" max="3650" value="${esc(x.dias_garantia||'')}" required placeholder="Ej. 30"></div>
      <div class="field"><label>OT finalizada</label><input value="${esc(fmt(x.finalizada_en))}" disabled></div>
      <div class="field full"><label>Observaciones <small>(opcional)</small></label><textarea name="observaciones" maxlength="600" placeholder="Condiciones o alcance de la garantía...">${esc(x.observaciones_garantia||'')}</textarea></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Guardar garantía</button></div></div>
    </form>`);
    $('#warrantyConfigForm').addEventListener('submit',async e=>{e.preventDefault();const submit=e.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;try{const r=await api(`/api/garantias/${orderId}/configurar`,{method:'POST',body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast(r.message||'Garantía configurada.');closeModal();if(state.current==='garantia') await renderGarantia();}catch(err){showToast(err.message,'error');submit.disabled=false;}});
  }

  async function warrantyRequestForm(guaranteeId){
    const x=state.warranties.find(item=>Number(item.garantia_id)===Number(guaranteeId));
    if(!x)return showToast('No se encontró la garantía.','error');
    openModal(`Solicitar revisión · ${x.numero_orden}`,`<form id="warrantyRequestForm" class="form-grid">
      <div class="field full"><div class="warranty-rule-note client"><i data-lucide="link-2"></i><div><strong>Esta revisión queda vinculada al mismo trabajo.</strong><span>No se crea una garantía desde cero: SEPRIGUA recibe la OT original, sede, servicio y plazo vigente.</span></div></div></div>
      <div class="field"><label>Orden</label><input value="${esc(x.numero_orden)}" disabled></div><div class="field"><label>Servicio</label><input value="${esc(x.tipo_servicio)}" disabled></div>
      <div class="field full"><label>¿Qué necesitas que revisemos?</label><textarea name="descripcion" maxlength="1200" required placeholder="Describe qué volvió a ocurrir o qué comportamiento observas..."></textarea></div>
      <div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Enviar revisión de garantía</button></div></div>
    </form>`);
    $('#warrantyRequestForm').addEventListener('submit',async e=>{e.preventDefault();const submit=e.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;try{const r=await api(`/api/garantias/${guaranteeId}/solicitar`,{method:'POST',body:Object.fromEntries(new FormData(e.currentTarget).entries())});showToast(r.message||'Solicitud enviada.');closeModal();await renderGarantia();}catch(err){showToast(err.message,'error');submit.disabled=false;}});
  }

  function warrantyCrewPicker(technicians,prefix){
    return `<div class="warranty-crew-grid" id="${esc(prefix)}Crew">${(technicians||[]).map(t=>{
      const unavailable=["VACACIONES","INACTIVO","NO_DISPONIBLE"].includes(String(t.disponibilidad||"").toUpperCase());
      const initials=String(t.nombre||"?").trim().split(/\s+/).slice(0,2).map(x=>x.charAt(0)).join("").toUpperCase()||"?";
      const operational=String(t.estado_operativo||t.disponibilidad||"DISPONIBLE").replaceAll("_"," ");
      const queue=Number(t.cola_cantidad||0);const detail=String(t.estado_operativo||"").toUpperCase()==="EN_SERVICIO"&&t.orden_activa_numero?`Atendiendo ${t.orden_activa_numero}`:queue?`${queue} trabajo(s) en cola`:"Disponible para asignación";
      return `<article class="warranty-crew-card ${unavailable?"unavailable":""}"><label><input class="warranty-crew-check" type="checkbox" value="${esc(t.id)}" ${unavailable?"disabled":""}><span class="warranty-crew-check-ui"><i data-lucide="check"></i></span><span class="crew-avatar">${esc(initials)}</span><span class="warranty-crew-copy"><strong>${esc(t.nombre)}</strong><small>${esc(t.puesto||"Personal de campo")} · ${esc(operational)}</small><span>${esc(detail)}</span></span></label><select class="warranty-crew-function" data-id="${esc(t.id)}" disabled><option value="ENCARGADO">Encargado</option><option value="TECNICO" selected>Técnico</option><option value="APOYO">Apoyo</option></select></article>`;
    }).join("")||`<div class="empty-state"><h3>Sin personal disponible</h3><p>No hay técnicos o supervisores habilitados para esta asignación.</p></div>`}</div>`;
  }

  function bindWarrantyCrew(prefix){
    $$(`#${CSS.escape(prefix)}Crew .warranty-crew-check`).forEach(ch=>ch.addEventListener("change",()=>{const card=ch.closest(".warranty-crew-card"),sel=card?.querySelector(".warranty-crew-function");if(sel)sel.disabled=!ch.checked;card?.classList.toggle("selected",ch.checked);}));
  }

  function collectWarrantyCrew(prefix){
    return $$(`#${CSS.escape(prefix)}Crew .warranty-crew-check:checked`).map(ch=>({empleado_id:Number(ch.value),funcion:ch.closest(".warranty-crew-card")?.querySelector(".warranty-crew-function")?.value||"TECNICO"}));
  }

  async function refreshWarrantyContext(){
    state.listCache.garantia=null;
    if(state.current==="solicitudes") return renderSolicitudes();
    if(state.current==="dashboard") return renderDashboard();
    return renderGarantia();
  }

  async function warrantyRequestStatusForm(requestId){
    const x=state.warrantyRequests.find(item=>Number(item.solicitud_garantia_id)===Number(requestId));
    if(!x)return showToast('No se encontró la solicitud de revisión.','error');
    const current=String(x.estado||'PENDIENTE').toUpperCase();
    const detail=`<div class="field full"><div class="warranty-request-detail"><div><strong>${esc(x.cliente)} · ${esc(x.sede||'Sede')}</strong><span>${esc(x.numero_orden)} · ${esc(x.tipo_servicio||'Servicio')}</span></div>${badge(current)}</div><p class="warranty-request-description">${esc(x.descripcion||'')}</p>${x.resultado_revision?`<div class="warranty-result-note"><strong>Resultado de la revisión</strong><span>${esc(x.resultado_revision)}</span></div>`:''}</div>`;
    const linked=x.revision_orden_id?`<div class="field full"><div class="warranty-linked-order"><div><small>OT de revisión</small><strong>${esc(x.revision_orden_numero||`OT #${x.revision_orden_id}`)}</strong><span>${esc(String(x.revision_orden_estado||'').replaceAll('_',' '))}</span></div><button class="btn" type="button" data-action="ver-orden" data-id="${esc(x.revision_orden_id)}"><i data-lucide="external-link"></i> Ver OT</button></div></div>`:'';
    if(current==='PENDIENTE'){
      await refreshCatalogs(true);const technicians=state.catalogs.tecnicos||[];
      openModal(`Revisión de garantía · ${x.numero_orden}`,`<form id="warrantyStatusForm" class="form-grid warranty-review-form">${detail}<div class="field full"><div class="warranty-stage-banner"><i data-lucide="calendar-clock"></i><div><strong>Aceptar solicitud y programar visita</strong><span>Al guardar se crea una OT de revisión vinculada a la garantía y se asigna la cuadrilla seleccionada.</span></div></div></div><div class="field"><label>Fecha y hora aproximada</label><input type="datetime-local" name="programada_para" required><small>Es una hora estimada de atención, no una promesa exacta.</small></div><div class="field full"><label>Cuadrilla para revisar la garantía</label>${warrantyCrewPicker(technicians,'warrantyReview')}</div><div class="field full"><label>Observaciones para la visita <small>(opcional)</small></label><textarea name="observaciones" maxlength="600" placeholder="Indicaciones para la revisión..."></textarea></div><div class="field full"><div class="form-actions warranty-decision-actions"><button class="btn danger" type="button" id="warrantyRejectButton"><i data-lucide="x"></i> Rechazar solicitud</button><button class="btn primary" type="submit"><i data-lucide="calendar-check"></i> Programar revisión</button></div></div></form>`);
      bindWarrantyCrew('warrantyReview');
      const submitAction=async action=>{const form=$('#warrantyStatusForm'),submit=form.querySelector('button[type="submit"]');if(submit.disabled)return;const body=Object.fromEntries(new FormData(form).entries());body.accion=action;if(action==='PROGRAMAR_REVISION'){body.integrantes=collectWarrantyCrew('warrantyReview');if(!body.integrantes.length)return showToast('Selecciona la cuadrilla que irá a revisar.','error');if(body.integrantes.filter(m=>m.funcion==='ENCARGADO').length!==1)return showToast('Selecciona exactamente un Encargado para la visita.','error');}if(action==='RECHAZAR'&&!String(body.observaciones||'').trim())return showToast('Escribe el motivo del rechazo en observaciones.','error');submit.disabled=true;try{const r=await api(`/api/garantias/solicitudes/${requestId}/estado`,{method:'POST',body});showToast(r.message||'Revisión actualizada.');closeModal();await refreshWarrantyContext();}catch(err){showToast(err.message,'error');submit.disabled=false;}};
      $('#warrantyStatusForm').addEventListener('submit',e=>{e.preventDefault();submitAction('PROGRAMAR_REVISION');});
      $('#warrantyRejectButton').addEventListener('click',()=>submitAction('RECHAZAR'));window.lucide?.createIcons();return;
    }
    if(current==='EN_REVISION'){
      openModal(`Resultado de revisión · ${x.numero_orden}`,`<form id="warrantyStatusForm" class="form-grid warranty-review-form">${detail}${linked}<div class="field full"><div class="warranty-stage-banner"><i data-lucide="search-check"></i><div><strong>Registrar el resultado de la visita</strong><span>Indica si el problema sí cumple las condiciones de garantía.</span></div></div></div><div class="field"><label>¿Aplica la garantía?</label><select name="aplica_garantia" required><option value="">Seleccione...</option><option value="true">Sí, aplica garantía · SIN COBRO</option><option value="false">No aplica · requiere autorización para cobro</option></select></div><div class="field full"><label>Resultado / observaciones</label><textarea name="observaciones" maxlength="360" required placeholder="Explica lo encontrado en la revisión..."></textarea></div><div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Guardar resultado</button></div></div></form>`);
      $('#warrantyStatusForm').addEventListener('submit',async e=>{e.preventDefault();const form=e.currentTarget,submit=form.querySelector('button[type="submit"]');if(submit.disabled)return;const body=Object.fromEntries(new FormData(form).entries());body.accion='RESULTADO_REVISION';submit.disabled=true;try{const r=await api(`/api/garantias/solicitudes/${requestId}/estado`,{method:'POST',body});showToast(r.message||'Resultado guardado.');closeModal();await refreshWarrantyContext();}catch(err){showToast(err.message,'error');submit.disabled=false;}});window.lucide?.createIcons();return;
    }
    if(current==='AUTORIZADA_CLIENTE'){
      await refreshCatalogs(true);const technicians=state.catalogs.tecnicos||[];
      openModal(`Crear nueva OT con cobro · ${x.numero_orden}`,`<form id="warrantyStatusForm" class="form-grid warranty-review-form">${detail}${linked}<div class="field full"><div class="warranty-stage-banner charge"><i data-lucide="badge-dollar-sign"></i><div><strong>El cliente autorizó continuar con cobro</strong><span>Se creará una nueva solicitud y una nueva OT, separadas del trabajo cubierto por garantía.</span></div></div></div><div class="field"><label>Fecha y hora aproximada</label><input type="datetime-local" name="programada_para" required></div><div class="field full"><label>Cuadrilla para el nuevo trabajo</label>${warrantyCrewPicker(technicians,'warrantyPaid')}</div><div class="field full"><label>Observaciones <small>(opcional)</small></label><textarea name="observaciones" maxlength="600"></textarea></div><div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cancelar</button><button class="btn primary" type="submit">Crear OT con cobro</button></div></div></form>`);
      bindWarrantyCrew('warrantyPaid');
      $('#warrantyStatusForm').addEventListener('submit',async e=>{e.preventDefault();const form=e.currentTarget,submit=form.querySelector('button[type="submit"]');if(submit.disabled)return;const body=Object.fromEntries(new FormData(form).entries());body.accion='CREAR_OT_COBRO';body.integrantes=collectWarrantyCrew('warrantyPaid');if(!body.integrantes.length)return showToast('Selecciona la cuadrilla del nuevo trabajo.','error');if(body.integrantes.filter(m=>m.funcion==='ENCARGADO').length!==1)return showToast('Selecciona exactamente un Encargado.','error');submit.disabled=true;try{const r=await api(`/api/garantias/solicitudes/${requestId}/estado`,{method:'POST',body});showToast(r.message||'Nueva OT creada.');closeModal();state.listCache.ordenes=null;await refreshWarrantyContext();}catch(err){showToast(err.message,'error');submit.disabled=false;}});window.lucide?.createIcons();return;
    }
    if(current==='GARANTIA_APROBADA'){
      openModal(`Garantía aprobada · ${x.numero_orden}`,`<form id="warrantyStatusForm" class="form-grid warranty-review-form">${detail}${linked}<div class="field full"><div class="warranty-no-charge"><i data-lucide="badge-check"></i><div><strong>APLICA GARANTÍA · SIN COBRO</strong><span>La OT de revisión quedó marcada como trabajo cubierto por garantía. Finaliza esa OT cuando el servicio quede atendido.</span></div></div></div><div class="field full"><label>Nota de cierre <small>(opcional)</small></label><textarea name="observaciones" maxlength="600"></textarea></div><div class="field full"><div class="form-actions"><button class="btn" type="button" data-close-modal>Cerrar ventana</button><button class="btn primary" type="submit">Cerrar revisión de garantía</button></div></div></form>`);
      $('#warrantyStatusForm').addEventListener('submit',async e=>{e.preventDefault();const submit=e.currentTarget.querySelector('button[type="submit"]');if(submit.disabled)return;const body=Object.fromEntries(new FormData(e.currentTarget).entries());body.accion='CERRAR_GARANTIA';submit.disabled=true;try{const r=await api(`/api/garantias/solicitudes/${requestId}/estado`,{method:'POST',body});showToast(r.message||'Garantía cerrada.');closeModal();await refreshWarrantyContext();}catch(err){showToast(err.message,'error');submit.disabled=false;}});window.lucide?.createIcons();return;
    }
    const waiting=current==='PENDIENTE_AUTORIZACION';
    const paid=current==='SERVICIO_AUTORIZADO';
    const finalCopy=waiting?'La revisión determinó que no aplica garantía. Se espera que el cliente autorice o rechace un nuevo trabajo con cobro.':paid?'El cliente autorizó el servicio y ya existe una nueva OT con cobro.':current==='NO_AUTORIZADA'?'El cliente decidió no continuar con un trabajo adicional.':current==='RECHAZADA'?'La solicitud fue rechazada por Coordinación.':'La revisión de garantía ya no requiere acciones pendientes.';
    openModal(`Revisión de garantía · ${x.numero_orden}`,`<div class="form-grid warranty-review-form">${detail}${linked}${x.orden_cobro_id?`<div class="field full"><div class="warranty-linked-order charge"><div><small>Nueva OT con cobro</small><strong>${esc(x.orden_cobro_numero||`OT #${x.orden_cobro_id}`)}</strong><span>${esc(String(x.orden_cobro_estado||'').replaceAll('_',' '))}</span></div><button class="btn" type="button" data-action="ver-orden" data-id="${esc(x.orden_cobro_id)}">Ver OT</button></div></div>`:''}<div class="field full"><div class="warranty-stage-banner ${waiting?'waiting':''}"><i data-lucide="${waiting?'clock-3':'circle-check-big'}"></i><div><strong>${esc(current.replaceAll('_',' '))}</strong><span>${esc(finalCopy)}</span></div></div></div><div class="field full"><div class="form-actions"><button class="btn primary" type="button" data-close-modal>Cerrar</button></div></div></div>`);window.lucide?.createIcons();
  }

  async function warrantyClientDecisionForm(requestId){
    const x=state.warrantyRequests.find(item=>Number(item.solicitud_garantia_id)===Number(requestId));
    if(!x)return showToast('No se encontró la revisión de garantía.','error');
    openModal(`Autorizar trabajo · ${x.numero_orden}`,`<div class="form-grid warranty-client-decision"><div class="field full"><div class="warranty-stage-banner charge"><i data-lucide="badge-dollar-sign"></i><div><strong>La revisión determinó que no aplica garantía</strong><span>SEPRIGUA solo abrirá otra OT con cobro si autorizas continuar. Si no autorizas, el caso se cierra y no se realiza trabajo adicional.</span></div></div></div>${x.resultado_revision?`<div class="field full"><div class="warranty-result-note"><strong>Resultado de la revisión</strong><span>${esc(x.resultado_revision)}</span></div></div>`:''}<div class="field full"><label>Observaciones <small>(opcional)</small></label><textarea id="warrantyClientDecisionNote" maxlength="260" placeholder="Puedes agregar una indicación para Coordinación..."></textarea></div><div class="field full"><div class="form-actions warranty-decision-actions"><button class="btn" type="button" id="warrantyClientReject">No autorizar trabajo</button><button class="btn primary" type="button" id="warrantyClientAuthorize">Autorizar trabajo con cobro</button></div></div></div>`);
    const decide=async decision=>{const yes=$('#warrantyClientAuthorize'),no=$('#warrantyClientReject');if(yes.disabled||no.disabled)return;yes.disabled=no.disabled=true;try{const r=await api(`/api/garantias/solicitudes/${requestId}/decision-cliente`,{method:'POST',body:{decision,observaciones:$('#warrantyClientDecisionNote').value}});showToast(r.message||'Decisión registrada.');closeModal();await refreshWarrantyContext();}catch(err){showToast(err.message,'error');yes.disabled=no.disabled=false;}};
    $('#warrantyClientAuthorize').addEventListener('click',()=>decide('AUTORIZAR'));$('#warrantyClientReject').addEventListener('click',()=>decide('NO_AUTORIZAR'));window.lucide?.createIcons();
  }

  async function renderGarantia(isCurrent = () => true){
    const coord=state.role==='COORDINADOR';
    setHeading(coord?'Garantías':'Mi garantía',coord?'Configura el plazo sobre OTs ya finalizadas y da seguimiento a las revisiones del mismo trabajo.':'Consulta tus trabajos finalizados, el tiempo restante y solicita una revisión sobre la OT original.');
    let d=state.listCache.garantia?.meta;
    if(!d){d=await api('/api/garantias');state.listCache.garantia={items:d.items||[],meta:d};}
    if (!isCurrent()) return;
    state.warranties=d.items||[];state.warrantyRequests=d.solicitudes||[];
    const s=d.resumen||{};
    if(coord){modulePending.garantia=warrantyPendingTotal(s);renderNav();}
    const warrantyStates=smartUnique(state.warranties,x=>String(x.estado_garantia||'PENDIENTE_CONFIGURACION').toUpperCase());
    const warrantyResult=smartListData("garantia",state.warranties,{defaults:{orden:"finalizada",direccion:"DESC"},search:x=>[x.numero_orden,x.tipo_servicio,x.cliente,x.sede,x.estado_garantia,x.estado_solicitud],filters:{estado:x=>String(x.estado_garantia||'PENDIENTE_CONFIGURACION').toUpperCase()},sort:{finalizada:x=>smartDateValue(x.finalizada_en),orden:x=>x.numero_orden||"",cliente:x=>x.cliente||"",estado:x=>x.estado_garantia||""}});
    const stats=`<section class="stats-grid warranty-stats"><article class="stat-card stat-blue"><div class="stat-icon"><i data-lucide="clipboard-check"></i></div><div class="stat-copy"><span>OT finalizadas</span><strong>${normalizeNumber(s.finalizadas)}</strong></div></article><article class="stat-card stat-green"><div class="stat-icon"><i data-lucide="shield-check"></i></div><div class="stat-copy"><span>Garantías activas</span><strong>${normalizeNumber(s.activas)}</strong></div></article><article class="stat-card stat-amber"><div class="stat-icon"><i data-lucide="hourglass"></i></div><div class="stat-copy"><span>${coord?'Por configurar':'Pendientes'}</span><strong>${normalizeNumber(s.pendientes_configurar)}</strong></div></article><article class="stat-card stat-red"><div class="stat-icon"><i data-lucide="clock-alert"></i></div><div class="stat-copy"><span>Vencidas</span><strong>${normalizeNumber(s.vencidas)}</strong></div></article></section>`;
    const cards=warrantyResult.items.map(warrantyCard).join('')||`<div class="empty-state"><h3>No hay garantías que coincidan</h3><p>Cambia los filtros para consultar otros trabajos finalizados.</p></div>`;
    let requests="";
    if(coord){
      const reqKey="garantiaSolicitudes";const reqStates=smartUnique(state.warrantyRequests,x=>String(x.estado||"").toUpperCase());
      const reqResult=smartListData(reqKey,state.warrantyRequests,{defaults:{orden:"fecha",direccion:"DESC"},search:x=>[x.numero_orden,x.cliente,x.sede,x.tipo_servicio,x.estado,x.descripcion],filters:{estado:x=>String(x.estado||"").toUpperCase()},sort:{fecha:x=>smartDateValue(x.creado_en),orden:x=>x.numero_orden||"",cliente:x=>x.cliente||"",estado:x=>x.estado||""}});
      const requestRows=reqResult.items.map(x=>`<tr>
        <td><div class="se-cell-stack"><strong class="mono">${esc(x.numero_orden)}</strong><span class="se-cell-muted">${fmt(x.creado_en)}</span></div></td>
        <td><div class="se-cell-stack"><strong>${esc(x.cliente)}</strong><span class="se-cell-muted">${esc(x.sede||'—')}</span></div></td>
        <td>${esc(x.tipo_servicio)}</td>
        <td>${managementBadge(x.estado)}</td>
        <td class="se-table-actions"><button class="btn small" data-action="estado-solicitud-garantia" data-id="${esc(x.solicitud_garantia_id)}">Gestionar</button></td>
      </tr>`);
      requests=`<section class="panel warranty-requests-panel smart-list-panel"><div class="panel-header"><div><h2>Solicitudes de revisión</h2><p class="muted">Reclamos vinculados a una garantía y a su OT original.</p></div></div><div class="panel-body">${smartControls(reqKey,{placeholder:"OT, cliente, sede o servicio",filters:[{name:"estado",label:"Estado",options:reqStates}],sorts:[["fecha","Fecha"],["orden","OT"],["cliente","Cliente"],["estado","Estado"]]})}${smartResultsMeta(reqResult,"solicitudes")}</div>${table(['OT / solicitada','Cliente / sede','Servicio','Estado','Acción'],requestRows,'No hay solicitudes de revisión que coincidan con los filtros.')}${smartPager(reqKey,reqResult)}</section>`;
    }
    content.innerHTML=`<div class="warranty-workspace ${coord?"warranty-workspace-coord":"warranty-workspace-client"}">${stats}<section class="panel warranty-explainer"><div class="panel-body"><div class="warranty-explainer-icon"><i data-lucide="refresh-ccw"></i></div><div><h2>La garantía continúa desde la OT original</h2><p>${coord?'No se crea un registro desde cero. Selecciona una OT COMPLETADA, define su plazo y el sistema calcula el vencimiento usando la fecha real de finalización.':'Cada tarjeta corresponde a un trabajo ya finalizado. Si la garantía está activa, el contador muestra exactamente cuánto tiempo queda para solicitar revisión de ese mismo trabajo.'}</p></div><button class="btn small" data-action="refrescar-garantias"><i data-lucide="refresh-cw"></i> Actualizar</button></div></section><section class="panel smart-list-panel warranty-filter-panel"><div class="panel-body">${smartControls("garantia",{placeholder:"OT, cliente, sede o servicio",filters:[{name:"estado",label:"Estado garantía",options:warrantyStates}],sorts:[["finalizada","Fecha finalización"],["orden","OT"],["cliente","Cliente"],["estado","Estado"]]})}${smartResultsMeta(warrantyResult,"garantías")}</div></section><div class="warranty-grid">${cards}</div>${smartPager("garantia",warrantyResult)}${requests}</div>`;
    window.lucide?.createIcons();startWarrantyCountdowns();
  }

  window.addEventListener("resize",()=>{ if(window.innerWidth>820) closeMobileFilters(); },{passive:true});

  navigator.serviceWorker?.addEventListener?.("message", event => {
    if (event.data?.type === "SEPRIGUA_PUSH") {
      refreshNotificationBadge().catch(()=>{});
      if (state.current === "notificaciones") { invalidateListCache("notificaciones"); renderNotificaciones().catch(()=>{}); }
    }
  });

  function queueFilterSearch(event) {
    const input = event.target.closest(filterSearchSelector);
    if (!input || !content.contains(input)) return;
    clearTimeout(smartSearchTimer);
    const revision = ++filterRevision;
    if (event.isComposing || event.type === "compositionstart") return;
    const module = state.current;
    const key = input.dataset.auditFilter ? "auditoria" : input.dataset.smartQ;
    if (key) {
      const prefs = smartPrefs(key);
      if (input.dataset.auditFilter) {
        prefs.filtros = {...prefs.filtros, [input.dataset.auditFilter]:input.value};
      } else {
        prefs.q = input.value;
      }
      prefs.pagina = 1;
    } else {
      state.userAdmin.q = input.value;
      state.userAdmin.pagina = 1;
    }
    smartSearchTimer = window.setTimeout(() => {
      if (!input.isConnected || revision !== filterRevision || module !== state.current) return;
      const refresh = key ? rerenderSmartList(key, revision) : refreshFilteredView(renderUsuarios, revision, module);
      refresh.catch(err => showToast(err.message, "error"));
    }, 220);
  }

  document.addEventListener("input", queueFilterSearch);
  document.addEventListener("compositionstart", queueFilterSearch);
  document.addEventListener("compositionend", queueFilterSearch);

  document.addEventListener("change", e => {
    const personnelAvailability = e.target.closest("[data-personnel-availability]");
    if (personnelAvailability) {
      savePersonalAvailability(personnelAvailability).catch(error=>showToast(error.message,"error"));
      return;
    }
    if(e.target.id==="weeklyReportDate"){
      state.weeklyReportDate=e.target.value;
      saveViewSnapshot("dashboard");
      return;
    }
    const quoteSort=e.target.closest("[data-quote-sort]");
    if(quoteSort){
      const prefs=smartPrefs("cotizaciones");
      const value=String(quoteSort.value||"FECHA_DESC").toUpperCase();
      prefs.orden=value.startsWith("TOTAL")?"total":"fecha";
      prefs.direccion=value.endsWith("ASC")?"ASC":"DESC";
      prefs.pagina=1;
      rerenderSmartList("cotizaciones").catch(err=>showToast(err.message,"error"));
      return;
    }
    const density=e.target.closest("[data-order-density]");
    if(density){
      const prefs=smartPrefs("ordenes");
      prefs.densidad=String(density.value||"COMODA").toUpperCase();
      rerenderSmartList("ordenes").catch(err=>showToast(err.message,"error"));
      return;
    }
    const orderColumn=e.target.closest("[data-order-column]");
    if(orderColumn){
      const prefs=smartPrefs("ordenes");
      prefs.columnas=Object.assign({supervisor:true,programada:true,cotizacion:true},prefs.columnas||{}, {[orderColumn.dataset.orderColumn]:Boolean(orderColumn.checked)});
      rerenderSmartList("ordenes").catch(err=>showToast(err.message,"error"));
      return;
    }
    const customFrom=e.target.closest("[data-order-date-from]");
    const customTo=e.target.closest("[data-order-date-to]");
    if(customFrom||customTo){
      const prefs=smartPrefs("ordenes");
      if(customFrom) prefs.fechaDesde=customFrom.value||"";
      if(customTo) prefs.fechaHasta=customTo.value||"";
      prefs.pagina=1;
      rerenderSmartList("ordenes").catch(err=>showToast(err.message,"error"));
      return;
    }
    const filter=e.target.closest("[data-smart-filter]");
    if(filter){const key=filter.dataset.smartKey;const prefs=smartPrefs(key);prefs.filtros=Object.assign({},prefs.filtros,{[filter.dataset.smartFilter]:filter.value});prefs.pagina=1;rerenderSmartList(key).catch(err=>showToast(err.message,"error"));return;}
    const size=e.target.closest("[data-smart-size]");
    if(size){const key=size.dataset.smartKey;const prefs=smartPrefs(key);prefs.tamano=Number(size.value||10);prefs.pagina=1;rerenderSmartList(key).catch(err=>showToast(err.message,"error"));return;}
    const sort=e.target.closest("[data-smart-sort]");
    if(sort){const key=sort.dataset.smartKey;const prefs=smartPrefs(key);prefs.orden=sort.value;prefs.pagina=1;rerenderSmartList(key).catch(err=>showToast(err.message,"error"));return;}
    const direction=e.target.closest("[data-smart-direction]");
    if(direction){const key=direction.dataset.smartKey;const prefs=smartPrefs(key);prefs.direccion=direction.value;prefs.pagina=1;rerenderSmartList(key).catch(err=>showToast(err.message,"error"));}
  });

  document.addEventListener("click", event => {
    const menu = event.target.closest(".people-action-menu");
    const action = event.target.closest(".people-action-item");
    for (const openMenu of document.querySelectorAll(".people-action-menu[open]")) {
      if (openMenu === menu && !action) continue;
      if (openMenu === menu) openMenu.querySelector("summary")?.focus();
      openMenu.open = false;
    }
  }, true);

  document.addEventListener("click", async e => {
    const roleNav=e.target.closest("[data-role-nav]");
    const breadcrumbModule=e.target.closest("[data-breadcrumb-module]");
    if(breadcrumbModule){navigate(breadcrumbModule.dataset.breadcrumbModule,{force:true,breadcrumbReset:true});return;}
    const breadcrumbOrder=e.target.closest("[data-breadcrumb-order-id]");
    if(breadcrumbOrder){openOrder(breadcrumbOrder.dataset.breadcrumbOrderId,"resumen",false).catch(err=>showToast(err.message,"error"));return;}
    if(roleNav){navigate(roleNav.dataset.roleNav,{breadcrumbReset:true});return;}
    const contextTab=e.target.closest("[data-context-module]");
    if(contextTab){navigate(contextTab.dataset.contextModule,{breadcrumbReset:true});return;}
    // IMPORTANTE: body usa data-module para estilos de los módulos nuevos.
    // Por eso la navegación se limita a controles reales; usar closest([data-module])
    // hacía que cualquier clic de la página encontrara el BODY y recargara el módulo,
    // bloqueando filtros, botones y acciones internas.
    const moduleBtn=e.target.closest(".nav-button[data-module], .system-brand-home[data-module]");
    if(moduleBtn){
      closeTopPopovers();
      const rootName = moduleRootHeadings.get(state.current);
      const openDetail = Boolean(rootName && title.textContent !== rootName);
      navigate(moduleBtn.dataset.module,{force:openDetail,breadcrumbReset:true});
      setSidebarOpen(false);
      return;
    }
    if(e.target.closest("#appContent [data-action]")) {
      contentNavigationSource = {module:state.current,label:moduleRootHeadings.get(state.current) || title.textContent};
      window.setTimeout(() => { contentNavigationSource = null; }, 0);
    }
    if(e.target.closest("[data-close-modal]")){closeModal();return;}
    if(e.target.closest("[data-close-popover]")){closeTopPopovers();return;}

    const passwordToggle=e.target.closest("[data-toggle-password]");
    if(passwordToggle){
      const input=passwordToggle.closest(".password-control")?.querySelector("input");
      if(input){const show=input.type==="password";input.type=show?"text":"password";passwordToggle.innerHTML=`<i data-lucide="${show?"eye-off":"eye"}"></i>`;window.lucide?.createIcons();}
      return;
    }


    const b=e.target.closest("[data-action]"); if(!b)return; const a=b.dataset.action,id=b.dataset.id;
    try {
      if(a==="ver-expediente-cotizacion"&&state.role==="COORDINADOR")return portalUI.handle("detalle-cotizacion",id);
      if(a==="planificar-agenda")return agendaScheduleForm(id);
      if(a==='documentos-personal'){state.documentos.tab='laboral';state.documentos.empleadoId=String(id);closeModal();return navigate('documentos',{force:true});}
      if(await operationsUI.handle(a,id)||await portalUI.handle(a,id))return;
      if(a==="cancelar-logout"){ closeModal(); return; }
      if(a==="confirmar-logout"){ closeModal(); return performLogout(); }
      if(a==="people-quick-filter") {
        const key=b.dataset.listKey; const prefs=smartPrefs(key); prefs.filtros=Object.assign({},prefs.filtros||{});
        const value=String(b.dataset.value||"TODOS").toUpperCase();
        let selected=normalizeSmartQuickValues(prefs.filtros.peopleQuick);
        if(value==="TODOS") selected=[];
        else selected=selected.includes(value)?selected.filter(item=>item!==value):[...selected,value];
        prefs.filtros.peopleQuick=selected.length?selected:["TODOS"]; prefs.pagina=1; return rerenderSmartList(key);
      }
      if(a==="smart-quick-filter") {
        const key=b.dataset.listKey; const name=b.dataset.filterName; if(!key||!name) return;
        const prefs=smartPrefs(key); prefs.filtros=Object.assign({},prefs.filtros||{});
        const value=String(b.dataset.value||"TODOS").toUpperCase();
        let selected=normalizeSmartQuickValues(prefs.filtros[name]);
        if(value==="TODOS") selected=[];
        else selected=selected.includes(value)?selected.filter(item=>item!==value):[...selected,value];
        prefs.filtros[name]=selected.length?selected:["TODOS"]; prefs.pagina=1; return rerenderSmartList(key);
      }
      if(a==="quote-tab") { const prefs=smartPrefs("cotizaciones"); prefs.filtros=Object.assign({},prefs.filtros||{},{tab:String(b.dataset.value||"TODAS").toUpperCase()}); prefs.pagina=1; return rerenderSmartList("cotizaciones"); }
      if(a==="order-quick-filter") {
        const prefs=smartPrefs("ordenes"); prefs.filtros=Object.assign({},prefs.filtros||{});
        const value=String(b.dataset.value||"TODAS").toUpperCase();
        let selected=normalizeOrderQuickFilters(prefs.filtros.rapidos||"TODAS");
        if(value==="TODAS") selected=["TODAS"];
        else { selected=selected.filter(v=>v!=="TODAS"); selected=selected.includes(value)?selected.filter(v=>v!==value):[...selected,value]; if(!selected.length) selected=["TODAS"]; }
        prefs.filtros.rapidos=selected; prefs.pagina=1; return rerenderSmartList("ordenes");
      }
      if(a==="order-critical-unassigned") {
        const prefs=smartPrefs("ordenes"); prefs.filtros=Object.assign({},prefs.filtros||{},{prioridad:"CRITICA",tecnico:"SIN_ASIGNAR",rapidos:["TODAS"]}); prefs.pagina=1; return rerenderSmartList("ordenes");
      }
      if(a==="request-quick-filter") {
        const key=b.dataset.listKey||"solicitudes"; const prefs=smartPrefs(key); const value=String(b.dataset.value||"TODAS").toUpperCase();
        prefs.filtros=Object.assign({},prefs.filtros||{});
        let selected=normalizeQuickFilters(prefs.filtros.rapidos||prefs.filtros.rapido||"TODAS");
        if(value==="TODAS") selected=["TODAS"];
        else { selected=selected.filter(v=>v!=="TODAS"); if(selected.includes(value)) selected=selected.filter(v=>v!==value); else selected.push(value); if(!selected.length) selected=["TODAS"]; }
        prefs.filtros.rapidos=selected; prefs.filtros.rapido=selected[0]||"TODAS"; prefs.pagina=1; return rerenderSmartList(key);
      }
      if(a==="request-remove-filter") { const key=b.dataset.listKey||"solicitudes"; const prefs=smartPrefs(key); const name=b.dataset.filterName; prefs.filtros=Object.assign({},prefs.filtros||{}); if(name){ if(name==="rapido"||name==="rapidos"){ prefs.filtros.rapidos=["TODAS"]; prefs.filtros.rapido="TODAS"; } else { prefs.filtros[name]="TODOS"; } } prefs.pagina=1; return rerenderSmartList(key); }
      if(a==="request-remove-quick-filter") { const key=b.dataset.listKey||"solicitudes"; const prefs=smartPrefs(key); const quickKey=String(b.dataset.quickKey||"").toUpperCase(); prefs.filtros=Object.assign({},prefs.filtros||{}); let selected=normalizeQuickFilters(prefs.filtros.rapidos||prefs.filtros.rapido||"TODAS").filter(v=>v!==quickKey&&v!=="TODAS"); if(!selected.length) selected=["TODAS"]; prefs.filtros.rapidos=selected; prefs.filtros.rapido=selected[0]||"TODAS"; prefs.pagina=1; return rerenderSmartList(key); }
      if(a==="reintentar-modulo") return navigate(b.dataset.module || state.current, { force: true });
      if(a==="seleccionar-reporte-periodo") return selectQuickReportPeriod(b);
      if(a==="descargar-reporte-semanal") return downloadQuickReport(b);
      if(a==="dashboard-ver-emergencias"||a==="dashboard-ver-solicitudes") return navigate("solicitudes");
      if(a==="dashboard-ver-cotizaciones") return navigate("cotizaciones");
      if(a==="dashboard-ver-garantias") return navigate("garantia");
      if(a==="dashboard-ver-capacidad") return navigate("equipo_mantenimiento");
      if(a==="dashboard-ver-resumen") return navigate("personas");
      if(a==="dashboard-ver-ordenes"||a==="volver-ordenes") return navigate("ordenes",{force:true});
      if(a==="dashboard-period") {
        state.dashboardPeriod=b.dataset.value;
        state.dashboardRecentPage=1;
        return renderDashboard();
      }
      if(a==="dashboard-recent-page") { state.dashboardRecentPage=Math.max(1, Number(b.dataset.page||1)); return renderDashboard(); }
      if(a==="smart-page") { const key=b.dataset.listKey; const prefs=smartPrefs(key); prefs.pagina=Math.max(1,Number(b.dataset.page||1)); return rerenderSmartList(key); }
      if(a==="smart-reset") { const key=b.dataset.listKey; resetSmartPrefs(key); return rerenderSmartList(key); }
      if(a==="importar-mis-sedes") return importarSucursales();
      if(a==="importar-sedes-empresa") return importarSucursales(id);
      if(a==="nueva-sede") return sedeForm();
      if(a==="editar-sede") return sedeForm(id);
      if(a==="toggle-sede") return confirmSedeState(id);
      if(a==="confirmar-toggle-sede") {
        const activate=b.dataset.active==="1";
        const result=await api(`/api/mis-sedes/${id}/estado`,{method:"POST",body:{activo:activate}});
        showToast(result.message||"Estado de sede actualizado.");closeModal();return renderMisSedes();
      }
      if(a==="ir-mis-sedes") {closeModal();return navigate("sedes");}
      if(a==="nueva-sede-empresa") return adminSedeForm(id);
      if(a==="editar-sede-empresa") return adminSedeForm(b.dataset.clienteId,id);
      if(a==="estado-sede-empresa") return adminSedeCambiarEstado(b.dataset.clienteId,id,b.dataset.active==="1");
      if(a==="confirmar-estado-sede-empresa") {
        const clienteId=b.dataset.clienteId;
        try{
          const result=await api(`/api/clientes/${clienteId}/sedes/${id}/estado`,{method:"POST",body:{activo:b.dataset.active==="1"}});
          showToast(result.message||"Estado actualizado.");
          return openSedes(clienteId);
        }catch(error){showToast(error.message,"error");return;}
      }
      if(a==="nuevo-cliente") return clientForm();
      if(a==="ver-cliente") return openClientDetail(id);
      if(a==="editar-cliente") return clientForm(id);
      if(a==="toggle-cliente") return confirmClientState(id,b.dataset.active==="1",b.dataset.name||"");
      if(a==="confirmar-toggle-cliente") {
        const activate=b.dataset.active==="1";
        const result=await api(`/api/clientes/${id}/estado`,{method:"POST",body:{activo:activate}});
        showToast(result.message||"Estado del cliente actualizado.");closeModal();state.userAdmin.catalogos=null;state.catalogs={};return renderClientes();
      }
      if(a==="documentos-tab") { state.documentos.tab=b.dataset.tab||"servicio"; if(state.documentos.tab!=="laboral")state.documentos.empleadoId=""; invalidateApiCache(["/api/documentos","/api/archivos-usuario"]); return renderDocumentos(); }
      if(a==="editar-documento-personal"||a==="editar-documento-servicio") return documentEditForm(b);
      if(a==="compartir-archivo-usuario") return documentShareForm(Number(id));
      if(a==="eliminar-documento-personal"||a==="eliminar-documento-servicio") return deleteDocumentFromView(b);
      if(a==="subir-archivo-general") return genericDocumentUploadForm();
      if(a==="archivar-archivo-usuario"){
        if(!confirm("¿Archivar este documento? No se borrará el historial."))return;
        try{await api(`/api/archivos-usuario/${Number(id)}`,{method:"DELETE"});showToast("Documento archivado.");return renderDocumentos();}
        catch(err){showToast(err.message,"error");}return;
      }
      if(a==="subir-documento-cliente") return clientDocumentUploadForm();
      if(a==="retirar-documento-cliente"){
        if(!confirm("¿Retirar este documento de tus archivos? Esta acción no se puede deshacer."))return;
        try{await api(`/api/documentos-cliente/${Number(id)}`,{method:"DELETE"});showToast("Documento retirado.");invalidateListCache("documentos");invalidateViewCache("documentos");await renderDocumentos();}
        catch(err){showToast(err.message,"error");}return;
      }
      if(a==="ver-expediente-personal") { state.documentos.tab="laboral";state.documentos.empleadoId=String(id||"");return navigate("documentos"); }
      if(a==="limpiar-expediente-personal") { state.documentos.empleadoId="";return renderDocumentos(); }
      if(a==="verificar-documento-laboral") { const r=await api(`/api/documentos-laborales/${id}/verificar`,{method:"POST",body:{}});showToast(r.message||"Documento verificado.");return renderDocumentos(); }
      if(a==="estado-documento-laboral") {
        const row=(await api(`/api/documentos-laborales${state.documentos.empleadoId?`?empleado_id=${encodeURIComponent(state.documentos.empleadoId)}`:""}`)).items?.find(x=>String(x.id)===String(id));
        if(!row)return showToast("No se encontró el documento.","error");
        const r=await api(`/api/documentos-laborales/${id}/estado`,{method:"POST",body:{activo:!row.activo}});showToast(r.message||"Documento actualizado.");return renderDocumentos();
      }
      if(a==="nuevo-empleado") return employeeForm();
      if(a==="nuevo-usuario") return userForm();
      if(a==="ver-usuario") return openUserDetail(id);
      if(a==="editar-usuario") return userForm(id);
      if(a==="visibilidad-usuario") return manageClientVisibility(id,b.dataset.visibility);
      if(a==="restablecer-usuario") return resetUserPassword(id);
      if(a==="cambiar-estado-usuario") return confirmUserState(id,b.dataset.active==="1",b.dataset.name||"");
      if(a==="confirmar-estado-usuario") {
        const activate=b.dataset.active==="1";
        const result=await api(`/api/usuarios/${id}/estado`,{method:"POST",body:{activo:activate}});
        showToast(result.message||"Estado actualizado.");closeModal();state.userAdmin.catalogos=null;state.userAdmin.pagina=1;return renderUsuarios();
      }
      if(a==="desbloquear-usuario") {
        const result=await api(`/api/usuarios/${id}/desbloquear`,{method:"POST",body:{}});
        showToast(result.message||"Usuario desbloqueado.");closeModal();state.userAdmin.pagina=1;return renderUsuarios();
      }
      if(a==="usuario-pagina") {state.userAdmin.pagina=Math.max(1,Number(b.dataset.page||1));return renderUsuarios();}
      if(a==="usuarios-limpiar") {Object.assign(state.userAdmin,{q:"",rol_id:"",estado:"",fecha_desde:"",fecha_hasta:"",pagina:1,tamano:10,orden:"FECHA",direccion:"DESC"});return renderUsuarios();}
      if(a==="usuario-filtro-estado") {state.userAdmin.estado=b.dataset.status||"";state.userAdmin.pagina=1;return renderUsuarios();}
      if(a==="nuevo-equipo") return inventoryUI.form();
      if(a==="ver-vehiculos") return inventoryUI.vehicleList();
      if(a==="nuevo-vehiculo") return inventoryUI.vehicleForm();
      if(a==="editar-vehiculo") return inventoryUI.vehicleForm(id);
      if(a==="volver-inventario") return navigate("equipos",{force:true});
      if(a==="editar-resguardo") return inventoryUI.form(id,true);
      if(a==="mostrar-nuevo-vehiculo") {const block=$("#inventoryInlineVehicle");if(block)block.hidden=!block.hidden;return;}
      if(a==="guardar-vehiculo-en-equipo") return inventoryUI.createVehicleInline();
      if(a==="registrar-uso-equipo") return inventoryUI.usageForm(id);
      if(a==="devolver-equipo") return inventoryUI.returnForm(id,b.dataset.usoId);
      if(a==="nuevo-catalogo") return catalogForm();
      if(a==="editar-catalogo") return catalogForm(id);
      if(a==="toggle-catalogo"){
        const item=(state.masterCatalog||[]).find(x=>x.id===id);if(!item)return;
        await api(`/api/catalogo-maestro/${encodeURIComponent(id)}`,{method:"PATCH",body:{activo:!item.activo}});
        showToast(item.activo?"Trabajo desactivado.":"Trabajo activado.");return renderCatalogoMaestro();
      }
      if(a==="nueva-solicitud") return requestForm(); if(a==="configurar-garantia") return warrantyConfigForm(id); if(a==="solicitar-revision-garantia") return warrantyRequestForm(id); if(a==="estado-solicitud-garantia") return warrantyRequestStatusForm(id); if(a==="decision-garantia-cliente") return warrantyClientDecisionForm(id); if(a==="refrescar-garantias"){invalidateListCache("garantia");return renderGarantia();} if(a==="ver-solicitud") return openRequest(id); if(a==="crear-ot-solicitud"){closeModal();return orderForm(id);} if(a==="nueva-orden") return orderForm();
      if(a==="ver-detalle-documento") return openDocumentDetail(b);
      if(state.current==="agenda"&&state.agenda?.dirty&&["ver-orden","asignar-tecnico","cotizar-orden"].includes(a)){showToast("Guardá o restablecé la planificación antes de abrir otra acción.","error");return;}
      if(a==="ver-orden") return openOrder(id,"resumen",true);
      if(a==="registrar-salida-ot") {await api(`/api/ordenes/${id}/en-camino`,{method:"POST",body:{}});showToast("Salida hacia la sede registrada.");return openOrder(id,"resumen",true);}
      if(a==="registrar-llegada-ot") {await api(`/api/ordenes/${id}/llegada`,{method:"POST",body:{}});showToast("Llegada al sitio registrada.");return openOrder(id,"resumen",true);}
      if(a==="volver-agenda") return renderAgendaOperativa();
      if(a==="volver-ordenes") return navigate("ordenes",{force:true});
      if(a==="orden-paso") return openOrder(id,b.dataset.step||"resumen",false);
      if(a==="suspender-orden") return suspendOrderForm(id);
      if(a==="decidir-reprogramacion") return decideRescheduleForm(id);
      if(["cambiar-estado","iniciar-orden","finalizar-tecnico","asignar-tecnico","actividad","incidencia","resolver-incidencia","cambio-alcance","enviar-cambio","responder-cambio","editar-orden","evidencia","evidencia-solicitud"].includes(a)) return quickAction(a,id);
      if(a==="cotizar-orden") return quoteForm(id);
      if(a==="ir-cotizaciones"){closeModal();return navigate("cotizaciones");}
      if(a==="quote-print-mode"){quotePrintSelection.active=!quotePrintSelection.active;quotePrintSelection.ids.clear();return renderCotizaciones();}
      if(a==="quote-print-selected"){if(!quotePrintSelection.ids.size)return showToast('Selecciona al menos una cotización.','error');window.open('/api/cotizaciones/imprimir-varias.pdf?ids='+Array.from(quotePrintSelection.ids).join(','),'_blank','noopener');return;}
      if(a==="compartir-cotizacion"){
        await window.SepriguaShareQuote(id,b,showToast);
        return;
      }
      if(a==="ver-sedes") return openSedes(id); if(a==="nuevo-mantenimiento") return maintenanceForm(); if(a==="nueva-cotizacion") return quoteForm(); if(a==="ver-expediente-cotizacion") return openClientQuoteFlow(id); if(a==="volver-cotizaciones") return navigate("cotizaciones",{force:true}); if(["enviar-cotizacion","responder-cotizacion"].includes(a)) return quoteAction(a,id);
      if(a==="leer-notificacion"){
        await api(`/api/notificaciones/${id}/leer`,{method:"POST",body:{}});showToast("Notificación leída.");
        resetNotificationViews();
        if(state.current==="notificaciones") return renderNotificaciones();
        return refreshNotificationBadge(true);
      }
      if(a==="leer-todas-notificaciones"){
        const result=await api("/api/notificaciones/leer-todas",{method:"POST",body:{}});showToast(result.message||"Notificaciones actualizadas.");
        resetNotificationViews();
        if(state.current==="notificaciones") return renderNotificaciones();
        return refreshNotificationBadge(true);
      }
      if(a==="alternar-leidas"){state.hideReadNotifications=!state.hideReadNotifications;return renderNotificaciones();}
      if(a==="refrescar-notificaciones"){resetNotificationViews();return renderNotificaciones();}
      if(a==="ver-todas-notificaciones"){closeTopPopovers();return navigate("notificaciones");}
      if(a==="refrescar-preview-notificaciones"){resetNotificationViews();return refreshNotificationBadge(true);}
      if(a==="alternar-sonido-notificaciones"){
        notificationSoundEnabled=!notificationSoundEnabled;
        if(!notificationSoundEnabled) notificationSoundPendingUntil=0;
        try{localStorage.setItem("seprigua_notification_sound",notificationSoundEnabled?"on":"off");}catch(_){}
        updateNotificationSoundToggle();
        if(notificationSoundEnabled){unlockNotificationAudio();playNotificationSound();}
        return;
      }
      if(a==="abrir-notificacion") return openNotificationTarget(b.dataset.entity,b.dataset.entityId,id);
      if(a==="abrir-cuenta"){closeTopPopovers();return navigate("cuenta");}
      if(a==="editar-mi-perfil") return openOwnProfileEditor();
      if(a==="editar-correo-acceso") return openAccessEmailEditor();
      if(a==="activar-push"){try{await syncPushSubscription({prompt:true});showToast("Notificaciones activadas en este dispositivo.");pushClient.config=null;return renderCuenta();}catch(err){showToast(err.message,"error");}return;}
      if(a==="desactivar-push"){try{await disablePushOnThisDevice();showToast("Notificaciones desactivadas en este dispositivo.");return renderCuenta();}catch(err){showToast(err.message,"error");}return;}
      if(a==="probar-push"){try{const d=await api("/api/push/probar",{method:"POST",body:{}});showToast(d.message||"Prueba enviada.");}catch(err){showToast(err.message,"error");}return;}
      if(a==="eliminar-dispositivo-push"){try{await api(`/api/push/dispositivos/${id}`,{method:"DELETE",body:{}});showToast("Dispositivo desactivado.");return renderCuenta();}catch(err){showToast(err.message,"error");}return;}
      if(a==="cerrar-otras-sesiones"){
        const result=await api("/api/cuenta/sesiones/cerrar-otras",{method:"POST",body:{}});showToast(result.message||"Otras sesiones cerradas.");return renderCuenta();
      }
      if(a==="cerrar-sesion") return confirmLogout();
      if(a==="probar-auditoria"){const d=await api("/api/auditoria/prueba",{method:"POST",body:{}});showToast(d.message);return navigate("auditoria");}
    } catch(err){showToast(err.message,"error");}
  });

  document.addEventListener("click", event => {
    const clear = event.target.closest('[data-action="se-clear-date"]');
    if (!clear) return;
    event.preventDefault();
    if (state.agenda?.dirty) { showToast("Guarda o descarta los cambios de agenda antes de cambiar fecha.","error"); return; }
    try { sessionStorage.removeItem("seprigua_fecha_consulta"); } catch (_) {}
    window.SEPRIGUASelectedDate = "";
    document.dispatchEvent(new CustomEvent("seprigua:calendar-date",{detail:{date:""}}));
  });

  document.addEventListener("seprigua:calendar-date", event => {
    if (!state.role) return;
    if (state.agenda?.dirty) {
      showToast("Guarda o descarta los cambios pendientes de agenda antes de cambiar fecha.","error");
      event.preventDefault();
      return;
    }
    state.dashboardRecentPage = 1;
    if (state.current === "dashboard") {
      state.dashboardAnchor=event.detail?.date || "";
      state.dashboardPeriod=event.detail?.date ? "dia" : "actual";
    }
    if (event.detail?.date && state.current === "agenda") state.agenda.fecha = event.detail.date;
    state.viewCache.clear();
    // Reutiliza las consultas originales: la selección de fecha solo filtra registros visibles.
    navigate(state.current,{force:true,loaderDelay:0}).catch(err=>showToast(err.message,"error"));
  });

  notificationButton?.addEventListener("click",async e=>{
    unlockNotificationAudio();
    updateNotificationSoundToggle();
    e.stopPropagation();
    syncPopoverPortal();
    const opening=notificationPopover.hidden;
    closeTopPopovers(opening?notificationPopover:null);
    notificationPopover.hidden=!opening;
    notificationButton.setAttribute("aria-expanded",String(opening));
    if(opening) acknowledgeNotificationsView();
    if(opening){notificationPreview.innerHTML=`<div class="popover-loading">Cargando avisos...</div>`;try{await refreshNotificationBadge(true);}catch(err){notificationPreview.innerHTML=`<div class="popover-empty"><strong>No se pudieron cargar</strong><span>${esc(err.message)}</span></div>`;}window.lucide?.createIcons();}
  });

  userMenuButton?.addEventListener("click",e=>{
    e.stopPropagation();
    syncPopoverPortal();
    const opening=userPopover.hidden;
    closeTopPopovers(opening?userPopover:null);
    userPopover.hidden=!opening;
    userMenuButton.setAttribute("aria-expanded",String(opening));
    syncPrototypeChrome();
  });

  document.addEventListener("click",e=>{
    if(!e.target.closest(".top-action-wrap") && !e.target.closest(".top-popover")) closeTopPopovers();
  });

  $("#modalClose").addEventListener("click", closeModal);
  modalBackdrop.addEventListener("click", e => {
    if (e.target !== modalBackdrop) return;
    if (modalProtection.locked) {
      warnProtectedModal();
      return;
    }
    closeModal();
  });
  menuButton?.addEventListener("click",()=>setSidebarOpen(!sidebar?.classList.contains("open")));
  sidebarScrim?.addEventListener("click",()=>setSidebarOpen(false));
  sidebarCollapseButton?.addEventListener("click",toggleDesktopSidebar);
  window.addEventListener("resize",()=>{syncPopoverPortal();applySidebarPreference();closeTopPopovers();requestAnimationFrame(keepActiveSidebarEntryVisible);});
  $("#logoutButton").addEventListener("click",confirmLogout);
  document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    const rowMenu = document.querySelector(".people-action-menu[open]");
    if (rowMenu) {
      rowMenu.open = false;
      rowMenu.querySelector("summary")?.focus();
      e.preventDefault();
      return;
    }
    if (!modalBackdrop.hidden) {
      if (modalProtection.locked) warnProtectedModal();
      else closeModal();
    }
    closeTopPopovers();
    if (sidebar?.classList.contains("open")) {
      setSidebarOpen(false);
      menuButton?.focus?.({preventScroll:true});
    }
  });
  const uiContext={api,state,esc,fmt,money,badge,button,table,openModal,closeModal,showToast,setHeading,content,navigate,openClientQuoteFlow,openOrder,refreshCancellationNotifications,moduleAllowed,adminSedeForm};
  const inventoryUI=window.SepriguaInventoryUI(uiContext);
  uiContext.inventoryUI=inventoryUI;
  const portalUI=window.SepriguaUI(uiContext),operationsUI=window.SepriguaOperations(uiContext);
  const staffCalendar=window.SepriguaStaffCalendar(uiContext);
  // Otros formularios y acciones también reconstruyen #appContent directamente.
  // Observamos sólo sus hijos inmediatos para recuperar el banner sin interferir
  // con las filas, modales ni los cambios parciales dentro de cada módulo.
  let moduleChromeQueued = false;
  const moduleChromeObserver = new MutationObserver(records => {
    if (!records.some(record => record.target === content && [...record.addedNodes].some(node => node.nodeType === 1))) return;
    if (moduleChromeQueued) return;
    moduleChromeQueued = true;
    queueMicrotask(() => {
      moduleChromeQueued = false;
      if (!content.firstElementChild || content.classList.contains("se-module-switching") ||
          content.dataset.renderedModule !== state.current) return;
      renderRoleModuleHero();
      decorateModuleHeader();
      enhanceRenderedContent();
      saveViewSnapshot(state.current);
    });
  });
  moduleChromeObserver.observe(content, { childList: true });
  window.SEPRIGUATourContext = () => ({module:state.current,role:state.role,orderId:state.openOrderId,orderStep:state.orderStep});
  window.lucide?.createIcons(); init();
})();

