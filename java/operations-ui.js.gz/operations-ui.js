/* Flujos complementarios sobre componentes y permisos del portal existente. */
window.SepriguaOperations=function(c){
 const {api,state,esc,fmt,money,badge,button,table,openModal,closeModal,showToast,setHeading,content,navigate}=c;
 const $=s=>document.querySelector(s);
 const day=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/Guatemala',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 const field=(n,t,v='',type='text')=>`<label>${esc(t)}<input name="${n}" type="${type}" value="${esc(v)}"></label>`;
 const options=(items,v)=>items.map(x=>`<option value="${esc(x)}" ${x===v?'selected':''}>${esc(x||'Todos')}</option>`).join('');
 const footer='<div class="form-actions full"><button class="btn" type="button" data-close-modal>Volver</button><button class="btn primary" type="submit">Guardar</button></div>';
  const pf={desde:'',hasta:'',categoria:'',estado:'',cliente:'',servicio:'',q:'',pagina:1,tamano:20};let employeeId=0,productionSearchTimer=null;
 function setPeriod(which){const today=day(),d=new Date(today+'T12:00:00Z');if(which==='month'){pf.desde=today.slice(0,7)+'-01';d.setUTCMonth(d.getUTCMonth()+1,0);pf.hasta=d.toISOString().slice(0,10);}else{d.setUTCDate(d.getUTCDate()-(d.getUTCDay()+6)%7);pf.desde=d.toISOString().slice(0,10);d.setUTCDate(d.getUTCDate()+6);pf.hasta=d.toISOString().slice(0,10);}pf.pagina=1;}
 setPeriod('week');
 async function production(){
  setHeading(employeeId?'Historial de trabajos':'Resumen semanal','Producción por empleado y categoría para revisar el cálculo externo de pagos.');
  const d=await api('/api/produccion'+(employeeId?'/'+employeeId:'')+'?'+new URLSearchParams(pf));
  const rows=employeeId?d.items.map(x=>`<tr><td>${esc(x.numero)}</td><td>${fmt(x.fecha)}</td><td>${esc(x.cliente)}<small class="table-subline">${esc(x.sede)}</small></td><td>${esc(x.servicio)}</td><td>${badge(x.estado)}${x.estado_participacion==='CANCELADO'?badge('RETIRADO'):''}</td><td>${esc(x.participacion)}</td><td>${x.minutos_servicio==null?'—':(x.minutos_servicio/60).toFixed(2)}</td><td>${button('Ver OT','ver-orden',x.orden_id)}</td></tr>`):d.items.map(x=>`<tr><td>${esc(x.nombre)}<small class="table-subline">${esc(x.puesto)}</small></td><td>${badge(x.categoria)}</td><td>${x.asignadas}</td><td>${x.completadas}</td><td>${x.pendientes}</td><td>${x.canceladas}</td><td>${x.emergencias}</td><td>${x.minutos_servicio==null?'—':(x.minutos_servicio/60).toFixed(2)}</td><td>${button('Historial','historial-personal',x.id)}</td></tr>`);
  content.innerHTML=`<section class="panel operations-workspace"><div class="panel-header"><div><h2>${esc(d.empleado?.nombre||'Resumen semanal')}</h2><p>${esc(d.desde)} al ${esc(d.hasta)} · ${d.resumen.ordenes_unicas||0} OT únicas · ${d.resumen.participaciones||0} participaciones</p></div><div class="actions">${employeeId?button('Todo el personal','produccion-general')+'<button class="btn" data-production-period="all">Todo el historial</button>':''}<button class="btn" data-production-period="week">Esta semana</button><button class="btn" data-production-period="month">Este mes</button></div></div><div class="panel-body"><form id="productionFilters" class="operations-filters">${field('desde','Desde',pf.desde,'date')}${field('hasta','Hasta',pf.hasta,'date')}${field('q','Empleado',pf.q)}${field('cliente','Cliente',pf.cliente)}${field('servicio','Servicio',pf.servicio)}<label>Categoría<select name="categoria">${options(['','OPERARIO','SUPERVISOR'],pf.categoria)}</select></label><label>Estado<select name="estado">${options(['','PENDIENTE','PROGRAMADA','EN_PROCESO','POR_CONFIRMAR','COMPLETADA','CANCELADA'],pf.estado)}</select></label><button class="btn primary">Aplicar</button></form><p class="muted">${esc(d.nota_horas)} Categoría del puesto actual. ${esc(d.criterio_fecha||'')}</p></div>${table(employeeId?['OT','Fecha','Cliente / sede','Servicio','Estado','Participación','Horas de OT','Acción']:['Empleado','Categoría','Asignadas','Completadas','Pendientes','Canceladas','Emergencias','Horas de OT','Acción'],rows,'No hay trabajos en el período seleccionado.')}<div class="operations-pager"><button class="btn" data-production-page="${d.pagina-1}" ${d.pagina<=1?'disabled':''}>Anterior</button><span>Página ${d.pagina} de ${d.paginas} · ${d.total} registros</span><button class="btn" data-production-page="${d.pagina+1}" ${d.pagina>=d.paginas?'disabled':''}>Siguiente</button></div></section>`;
   const filters=$('#productionFilters');
   const applyFilters=async focusName=>{
    const current=focusName?filters.elements.namedItem(focusName):null;
    const caret=current?.selectionStart??null;
    Object.assign(pf,Object.fromEntries(new FormData(filters)),{pagina:1});
    await production();
    if(focusName){const next=$('#productionFilters')?.elements.namedItem(focusName);if(next){next.focus();if(caret!==null)next.setSelectionRange(caret,caret);}}
   };
   filters.onsubmit=e=>{e.preventDefault();clearTimeout(productionSearchTimer);applyFilters().catch(err=>showToast(err.message,'error'));};
   filters.oninput=e=>{
    if(!e.target.matches('input[type="text"],input[type="search"]'))return;
    const name=e.target.name;
    clearTimeout(productionSearchTimer);
    productionSearchTimer=setTimeout(()=>applyFilters(name).catch(err=>showToast(err.message,'error')),220);
   };
   filters.onchange=e=>{
    if(e.target.matches('input[type="text"],input[type="search"]'))return;
    clearTimeout(productionSearchTimer);
    applyFilters().catch(err=>showToast(err.message,'error'));
   };
  content.querySelectorAll('[data-production-period]').forEach(b=>b.onclick=()=>{if(b.dataset.productionPeriod==='all'){pf.desde='';pf.hasta='';pf.pagina=1;}else setPeriod(b.dataset.productionPeriod);production().catch(e=>showToast(e.message,'error'));});
  content.querySelectorAll('[data-production-page]').forEach(b=>b.onclick=()=>{pf.pagina=Number(b.dataset.productionPage);production().catch(e=>showToast(e.message,'error'));});
 }
 let cancellationPage=1,cancellationStatus='PENDIENTE';
 async function cancellations(){
  setHeading('Solicitudes de cancelación',state.role==='CLIENTE'?'Sigue la resolución de tus solicitudes.':'Aprueba o rechaza con una explicación; el historial se conserva.');
  const d=await api('/api/cancelaciones?'+new URLSearchParams({pagina:cancellationPage,tamano:20,estado:cancellationStatus}));
  content.innerHTML=`<section class="panel"><div class="panel-header"><h2>Cancelaciones</h2><label>Estado<select id="cancellationStatus">${options(['PENDIENTE','APROBADA','RECHAZADA',''],cancellationStatus)}</select></label></div>${table(['Registro','Cliente','Solicitada','Motivo','Estado','Resolución','Acción'],d.items.map(x=>`<tr><td>${esc(x.numero)}</td><td>${esc(x.cliente)}</td><td>${fmt(x.solicitada)}</td><td>${esc(x.motivo)}</td><td>${badge(x.estado)}</td><td>${esc(x.resolucion||'Pendiente de revisión')}</td><td>${state.role==='COORDINADOR'&&x.estado==='PENDIENTE'?button('Resolver','resolver-cancelacion',x.id):'—'}</td></tr>`),'No hay solicitudes con este filtro.')}<div class="operations-pager"><button class="btn" id="cancellationPrev" ${d.pagina<=1?'disabled':''}>Anterior</button><span>Página ${d.pagina} de ${d.paginas}</span><button class="btn" id="cancellationNext" ${d.pagina>=d.paginas?'disabled':''}>Siguiente</button></div></section>`;
  $('#cancellationStatus').onchange=e=>{cancellationStatus=e.target.value;cancellationPage=1;cancellations().catch(e=>showToast(e.message,'error'));};$('#cancellationPrev').onclick=()=>{cancellationPage--;cancellations().catch(e=>showToast(e.message,'error'));};$('#cancellationNext').onclick=()=>{cancellationPage++;cancellations().catch(e=>showToast(e.message,'error'));};
 }
 function bind(id,url,method,body,after){$('#'+id).onsubmit=async e=>{e.preventDefault();const f=e.currentTarget,btn=f.querySelector('[type="submit"]');if(btn.disabled)return;btn.disabled=true;try{const d=Object.fromEntries(new FormData(f));const r=await api(url,{method,body:body(d)});showToast(r.message||'Guardado.');closeModal();await after();}catch(err){showToast(err.message,'error');}finally{btn.disabled=false;}};}
 function cancelRequest(value){const [entity,id]=String(value).split(':');openModal('Solicitar cancelación',`<p>Coordinación revisará la solicitud y comunicará su decisión. El servicio continúa vigente hasta su resolución.</p><form id="cancelRequest"><label>Motivo<textarea name="motivo" required minlength="5" maxlength="900"></textarea></label><label class="full"><input type="checkbox" name="confirmacion" required> Confirmo que deseo solicitar la cancelación.</label>${footer}</form>`);bind('cancelRequest','/api/cancelaciones','POST',d=>({...d,entidad:entity,entidad_id:Number(id)}),()=>navigate('cancelaciones'));}
 function cancelResolve(id){openModal('Resolver cancelación',`<form id="cancelResolve"><label>Decisión<select name="estado"><option>APROBADA</option><option>RECHAZADA</option></select></label><label>Explicación<textarea name="observaciones" required minlength="5" maxlength="900"></textarea></label>${footer}</form>`);bind('cancelResolve','/api/cancelaciones/'+Number(id),'PATCH',d=>d,cancellations);}
 function signature(id){
  openModal('Firma de conformidad',`<form id="signatureForm" class="signature-capture-form"><div class="signature-capture-note"><strong>Esta firma quedará visible en la OT.</strong><span>Puede capturarse antes o después del cierre técnico y se almacena como evidencia de conformidad.</span></div><label>Nombre de quien firma<input name="nombre" required maxlength="100" placeholder="Nombre completo"></label><p class="muted">Firma con el dedo, lápiz o ratón dentro del recuadro.</p><canvas id="signatureCanvas" width="900" height="300" aria-label="Área de firma"></canvas><button class="btn" type="button" id="signatureClear">Limpiar firma</button>${footer}</form>`);
  const canvas=$('#signatureCanvas'),ctx=canvas.getContext('2d');let drawing=false,ink=false;ctx.fillStyle='white';ctx.fillRect(0,0,900,300);ctx.strokeStyle='#123862';ctx.lineWidth=3;ctx.lineCap='round';
  const point=e=>{const r=canvas.getBoundingClientRect();return [(e.clientX-r.left)*900/r.width,(e.clientY-r.top)*300/r.height];};
  canvas.onpointerdown=e=>{e.preventDefault();drawing=true;canvas.setPointerCapture(e.pointerId);ctx.beginPath();ctx.moveTo(...point(e));};canvas.onpointermove=e=>{if(drawing){ctx.lineTo(...point(e));ctx.stroke();ink=true;}};canvas.onpointerup=canvas.onpointercancel=()=>drawing=false;
  $('#signatureClear').onclick=()=>{ctx.fillRect(0,0,900,300);ink=false;};
  $('#signatureForm').onsubmit=async e=>{e.preventDefault();if(!ink)return showToast('Dibuja la firma antes de guardar.','error');const f=e.currentTarget,btn=f.querySelector('[type="submit"]');if(btn.disabled)return;btn.disabled=true;try{const blob=await new Promise(r=>canvas.toBlob(r,'image/png'));const data=new FormData();data.append('archivo',blob,'firma.png');data.append('categoria','FIRMA');data.append('etapa','CONFIRMACION');data.append('descripcion','FIRMA: '+f.elements.nombre.value);await api(`/api/ordenes/${Number(id)}/evidencias`,{method:'POST',body:data});closeModal();showToast('Firma guardada.');await c.openOrder(id,'finalizar',true);}catch(err){showToast(err.message,'error');}finally{btn.disabled=false;}};
 }
 async function handle(action,id){if(action==='historial-personal'){employeeId=Number(id);pf.desde='';pf.hasta='';pf.pagina=1;await navigate('produccion',{force:true});return true;}if(action==='produccion-general'){employeeId=0;setPeriod('week');await production();return true;}if(action==='solicitar-cancelacion'){cancelRequest(id);return true;}if(action==='resolver-cancelacion'){cancelResolve(id);return true;}if(action==='firma-orden'){signature(id);return true;}return false;}
 return {production,cancellations,handle};
};
